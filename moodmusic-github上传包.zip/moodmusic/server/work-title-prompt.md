# 任务

你在操作 MoodMusic AI 的阿里云服务器（121.43.42.164）。后端是 Python + FastAPI，systemd 服务名 `moodmusic`。上一次你已经加好了模型 B（`tagger.py`、`/api/tag`）。**这次只加一个很小的接口，其他什么都不要改。**

## 背景

用户在 App 里用中文说剧名，比如“我想听怪奇物语的主题曲”。但 Apple Music 里欧美影视原声只用英文名登记（Stranger Things），用中文搜不到。App 里已经内置了约 200 部常见作品的中英对照，这个接口用来翻译表里没有的作品。

## 要做的事

1. 先备份：`cp -a /opt/moodmusic /opt/moodmusic.bak-$(date +%Y%m%d%H%M)`

2. 新增 `POST /api/work-title`
   - 请求：`{"title": "怪奇物语"}`，title 必填，1～50 个字
   - 响应：`{"en": "Stranger Things"}`
   - 用 DeepSeek（复用现有的密钥和调用方式，可以放在 `tagger.py` 旁边），`response_format={"type":"json_object"}`，temperature 0，超时 8 秒
   - 系统提示词要点：这是一部影视剧、电影、动画或游戏的中文名，返回它在 Apple Music / iTunes 原声专辑里使用的**官方英文名**；如果本来就是中文作品（比如《甄嬛传》），或者你不确定，返回 `{"en": null}`。只输出 JSON。
   - 结果缓存在 `/opt/moodmusic/data/work_titles.json`（中文名 → 英文名，null 也缓存），同一个名字只问一次 AI。写入方式和 `tags.json` 一样：临时文件 + 原子改名 + 文件锁。
   - 大模型超时或出错：返回 200 和 `{"en": null}`，不缓存
   - 限流：每个 IP 每分钟 20 次，超过返回 429，格式和 `/api/understand` 一样
   - 不存任何用户信息，不记录 IP

3. 不要改 `/api/understand`、`/api/recommend`、`/api/songs`、`/api/sources`、`/api/tag`、`/api/tags`、`/api/health` 的行为。不要动宝塔、8888 端口和防火墙，不要打印密钥。

## 做完后

1. `systemctl restart moodmusic`
2. 在服务器本机测试：
   - `curl -s -X POST http://127.0.0.1/api/work-title -H 'Content-Type: application/json' -d '{"title":"行尸走肉"}'` 应返回 `{"en":"The Walking Dead"}`
   - 再调用一次同样的请求，应该直接用缓存（日志里没有新的大模型调用）
   - `{"title":"甄嬛传"}` 应返回 `{"en":null}`
3. 提交改动（git commit），然后用简单的中文告诉我：改了哪些文件、备份在哪、三个测试结果。
