# 角色

你是一名资深 Python 后端工程师，现在通过终端直接操作 MoodMusic AI 的阿里云 ECS 服务器（IP 121.43.42.164，Alibaba Cloud Linux 4）。服务器上已经跑着 MoodMusic 后端：Python + FastAPI，systemd 服务名 `moodmusic`，Nginx 反代 80 端口到后端，DeepSeek 密钥在 `/etc/moodmusic.env`。服务器上还有宝塔面板，**不要动 8888 端口和宝塔的配置**。

这次的任务：给后端加上「模型 B：歌曲打标签」。

# 模型 B 是什么

- 已有的大模型（模型 A）负责“理解用户说的话”（`/api/understand`），**不要改它**。
- 模型 B 负责“理解每首歌”：一首歌进入曲库时，分析它适合什么人、什么情绪、什么场景，把标签保存下来；推荐时直接读取保存好的标签，不再现场调用大模型。
- 流程：歌曲进入曲库 → 模型 B 分析 → 保存标签 → 推荐时读取。
- 模型 B 也用 DeepSeek（同一个密钥，模型 `deepseek-chat`），只是用另一段系统提示词。

# 开始前先检查

1. 先读一遍现有后端代码（通常在 `/opt/moodmusic/` 下），看有没有已经预留的“打标签 / tag / 模型 B”位置。有的话就在那里接，没有就按下面新建。把你看到的情况先简单告诉我。
2. 做任何修改前，把整个后端目录备份一份，例如 `cp -a /opt/moodmusic /opt/moodmusic.bak-$(date +%Y%m%d%H%M)`。

# 范围

- **不要给服务器现有曲库里那 50 首虚构歌（mm001～mm050）打标签**，它们保持原样。
- 模型 B 只给 App 发来的真实歌曲打标签。

# 要做的事

## 1. 新接口 `POST /api/tag`

请求（一次最多 20 首）：

```json
{
  "songs": [
    {"id": "apple:1234567", "title": "红豆", "artist": "王菲", "album": "唱游", "genre_hint": "Pop"}
  ]
}
```

- `id`：歌曲唯一编号。App 自带的 50 首真实歌用 `am001`～`am050`；用户搜到、喜欢、加进歌单的 Apple Music 歌用 `apple:` + trackId。只允许字母、数字、`:`、`_`、`-`，长度 ≤ 64。
- `title`、`artist` 必填；`album`、`genre_hint` 可选。每个字段最长 100 字。

响应：

```json
{
  "tags": {
    "apple:1234567": {
      "genre": "流行",
      "moods": ["伤感", "怀旧"],
      "energy": 2,
      "valence": 2,
      "scenes": ["睡前", "发呆"],
      "audience": "想安静回味一段感情的人",
      "bpm": 72,
      "source": "llm",
      "tagged_at": "2026-10-11T12:00:00+08:00"
    }
  },
  "failed": []
}
```

字段取值（必须和接口文档 v1.0 第 5 节的枚举一致）：

- `genre`：流行 / R&B / 民谣 / 摇滚 / 电子 / 爵士 / Lo-fi / 纯音乐 / 嘻哈 / 国风，选 1 个
- `moods`：治愈 / 放松 / 快乐 / 伤感 / 平静 / 热血 / 浪漫 / 怀旧 / 专注 / 梦幻 / 振奋 / 孤独，选 1～3 个
- `energy`：1～5 的整数（1 很安静，5 很燃）
- `valence`：1～5 的整数（1 很丧，5 很开心）
- `scenes`：通勤 / 睡前 / 学习 / 运动 / 开车 / 发呆 / 放松 / 难过 / 开心，选 1～3 个
- `audience`：一句话，适合什么人，不超过 30 个字
- `bpm`：估计值，40～200 的整数，不确定就给 null

## 2. 保存标签

- 用一个 JSON 文件就行，不要建数据库：`/opt/moodmusic/data/tags.json`，结构是 `{ "<id>": {标签} }`。
- 写入时先写临时文件再改名（原子写入），并用文件锁或进程内锁避免并发写坏。
- 请求里的歌**如果已经有标签，直接返回保存的结果，不再调用大模型**。只有新歌才交给模型 B。
- 文件只存歌曲信息和标签，**不存任何用户信息、不记录 IP**。

## 3. 调用模型 B

- 一次请求里的新歌合并成一次 DeepSeek 调用（最多 20 首），`response_format={"type":"json_object"}`，temperature 0.2，超时 15 秒。
- 系统提示词放在 `prompts/tag.md`，要点：
  - 只输出 JSON，键是歌曲 id。
  - 每个字段只能用上面列出的取值。
  - 依据歌名、歌手、专辑和你对这首歌的了解判断；不认识的歌按歌名和歌手风格合理推断，不要编造歌词。
  - 附 3～5 个中文示例（例如周杰伦《晴天》、Nujabes《Aruarian Dance》、五月天《倔强》）。
- 用 Pydantic 校验：不在枚举里的值丢掉；`moods`/`scenes` 为空、`genre` 不合法或整条解析失败的歌，放进 `failed` 数组，**不要保存**，下次请求会再试。
- 大模型超时或报错时接口仍返回 200，所有新歌放进 `failed`。

## 4. 防刷

- `/api/tag` 按 IP 限流：每分钟 10 次，超过时返回 429，格式和 `/api/understand` 一样（`{"detail": "...", "retry_after": 秒数}`）。
- `tags.json` 超过 20000 首时，新歌不再调用大模型，直接放进 `failed`，并在日志里提醒。

## 5. 读取标签（推荐时用）

- 新增 `GET /api/tags?ids=apple:1,apple:2`（最多 50 个），只读 `tags.json`，返回 `{ "tags": {...} }`，没有的 id 不返回。不调用大模型。
- `/api/health` 的返回里加一个字段 `"tagger": "configured"`（有 DeepSeek 密钥时）或 `"missing"`，方便 App 判断模型 B 能不能用。其余字段保持不变。

# 不要做

- 不要改 `/api/understand`、`/api/recommend`、`/api/songs`、`/api/sources` 现有的行为和返回格式。
- 不要建数据库、不要用 Docker、不要动宝塔和 8888 端口、不要改防火墙。
- 不要在任何地方输出或打印 DeepSeek 密钥。

# 做完后

1. `systemctl restart moodmusic`，确认服务正常。
2. 用 curl 在服务器本机测试：
   - `curl -s http://127.0.0.1/api/health`，应看到 `"tagger": "configured"`
   - 用上面的“红豆 / 王菲”例子调用一次 `/api/tag`，再调用一次，第二次应该直接返回保存好的结果（日志里没有新的大模型调用）
   - `curl -s 'http://127.0.0.1/api/tags?ids=apple:1234567'` 能读到刚才的标签
3. 用简单的中文告诉我：改了哪些文件、备份放在哪、三个测试的结果。
