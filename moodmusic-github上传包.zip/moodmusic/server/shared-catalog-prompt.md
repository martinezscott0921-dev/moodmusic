# 任务

你在操作 MoodMusic AI 的阿里云服务器（121.43.42.164）。后端是 Python + FastAPI，代码在 `/opt/moodmusic/`，systemd 服务名 `moodmusic`。之前已经加好了模型 B（`tagger.py`、`POST /api/tag`、`GET /api/tags`，标签缓存在 `/opt/moodmusic/data/tags.json`）。

这次要加一个**公共曲库**：用户在 App 里搜到并打好标签的 Apple Music 歌曲，汇总到服务器上，所有用户的 App 都能下载，一起参与推荐。**只加下面这些，其他什么都不要改。**

## 开始前

1. 先备份：`cp -a /opt/moodmusic /opt/moodmusic.bak-$(date +%Y%m%d%H%M)`
2. 先读一遍 `tagger.py` 和 `/api/tag` 的代码，简单告诉我现在 `tags.json` 里每条记录存了哪些字段。

## 要做的事

### 1. 保存歌曲信息：`/opt/moodmusic/data/songs.json`

- 结构：`{ "apple:1234567": {"title": "...", "artist": "...", "album": "...", "preview_url": "...", "artwork": "...", "duration_ms": 123000, "storefront": "cn", "added_at": 1729670000} }`
- 只保存 id 以 `apple:` 开头的歌。`am001` 这类 App 内置歌和服务器原有的 `mm001～mm050` **都不要放进来**。
- 写入方式和 `tags.json` 一样：先写临时文件再原子改名，加文件锁。
- 只存歌曲信息，**不存任何用户信息，不记录 IP**。
- 上限 20000 首，超过后不再新增，并在日志里提醒。

### 2. 修改 `POST /api/tag`：请求里的歌也记进 `songs.json`

- 请求里每首歌可以多带这几个**可选**字段：`preview_url`、`artwork`、`duration_ms`、`storefront`（字符串最长 300 字，`preview_url` 和 `artwork` 必须以 `https://` 开头且域名以 `.apple.com` 或 `.mzstatic.com` 结尾，否则丢掉这个字段）。旧版 App 不带这些字段也必须能正常用。
- 只要这首歌**最终有标签**（不管是这次新打的，还是缓存里本来就有的），就把它的信息写进或更新到 `songs.json`。已有的记录只补上缺的字段，`added_at` 保持第一次的时间。
- 打标签失败的歌不要写进去。
- `/api/tag` 原来的请求、响应格式和限流都**保持不变**。

### 3. 新接口 `GET /api/catalog?since=<秒级时间戳>`

- 返回 `songs.json` 里 `added_at > since` 的歌，并附上 `tags.json` 里对应的标签。没有标签的跳过。`since` 不传就当 0。
- 按 `added_at` 从早到晚排序，一次最多 2000 首。
- 响应：
```json
{
  "songs": [
    {"id": "apple:1234567", "title": "红豆", "artist": "王菲", "album": "唱游",
     "preview_url": "https://...", "artwork": "https://...", "duration_ms": 254000, "storefront": "cn",
     "added_at": 1729670000,
     "tags": {"genre": "流行", "moods": ["伤感"], "energy": 2, "valence": 2, "scenes": ["睡前"], "audience": "...", "bpm": 72}}
  ],
  "next_since": 1729670000,
  "has_more": false
}
```
- `next_since` = 这次返回的最后一首的 `added_at`（没有歌时等于请求的 `since`）。`has_more` 表示后面还有没返回的。
- 限流：每个 IP 每分钟 20 次，超过返回 429，格式和 `/api/understand` 一样。
- 只读文件，不调用大模型。

### 4. `/api/health` 加一个字段

加上 `"catalog": <songs.json 里的歌曲数>`，其他字段保持不变。

## 不要做

- 不要改 `/api/understand`、`/api/recommend`、`/api/songs`、`/api/sources`、`/api/tags` 的行为和返回格式。
- 不要动宝塔、8888 端口和防火墙，不要用 Docker，不要打印 DeepSeek 密钥。

## 做完后

1. `systemctl restart moodmusic`，确认服务正常。
2. 在服务器本机测试：
   - 用“红豆 / 王菲”调用一次 `/api/tag`（id 用 `apple:1234567`，带上 `"preview_url": "https://audio-ssl.itunes.apple.com/test.m4a"`）
   - `curl -s 'http://127.0.0.1/api/catalog?since=0'`，应该能看到这首歌和它的标签
   - `curl -s http://127.0.0.1/api/health`，应该看到 `catalog` 字段
   - 测完把测试歌 `apple:1234567` 从 `songs.json` 和 `tags.json` 里删掉
3. 提交改动（git commit），然后用简单的中文告诉我：改了哪些文件、备份放在哪、三个测试的结果。
