#!/usr/bin/env python3
"""把「曲库模板.xlsx」转换成后端用的 songs.json，并检查授权和必填项。

用法：
    python3 build_catalog.py 曲库模板.xlsx songs.json [mp3文件夹]

- 只接受 CC0 / CC BY 3.0 / CC BY 4.0 / 公共领域；其他授权的行会报错并跳过。
- 给了 mp3 文件夹时，会检查每行的 mp3 文件是否存在；装了 mutagen 时还会自动读出时长。
- 音频地址写成 /audio/<文件名>，由 Nginx 提供（见 server-update-prompt.md）。
"""
import json
import os
import sys

from openpyxl import load_workbook

GENRES = ['流行', 'R&B', '民谣', '摇滚', '电子', '爵士', 'Lo-fi', '纯音乐', '嘻哈', '国风']
MOODS = ['治愈', '放松', '快乐', '伤感', '平静', '热血', '浪漫', '怀旧', '专注', '梦幻', '振奋', '孤独']
SCENES = ['通勤', '睡前', '学习', '运动', '开车', '发呆', '放松', '难过', '开心']
LICENSES = {
    'CC0': ('CC0 1.0', 'https://creativecommons.org/publicdomain/zero/1.0/'),
    'CC BY 4.0': ('CC BY 4.0', 'https://creativecommons.org/licenses/by/4.0/'),
    'CC BY 3.0': ('CC BY 3.0', 'https://creativecommons.org/licenses/by/3.0/'),
    '公共领域': ('Public Domain', 'https://creativecommons.org/publicdomain/mark/1.0/'),
}
COLS = ['编号', '歌名', '作者', '来源网站', '网页链接', '授权', 'mp3文件名', '曲风', '情绪1', '情绪2',
        '能量', '情绪正负', '场景1', '场景2', '场景3', 'BPM', '热度', '时长秒']


def mp3_seconds(path):
    try:
        from mutagen.mp3 import MP3
        return int(round(MP3(path).info.length))
    except Exception:
        return None


def to_int(v, lo, hi):
    try:
        n = int(round(float(v)))
    except (TypeError, ValueError):
        return None
    return n if lo <= n <= hi else None


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    src, out = sys.argv[1], sys.argv[2]
    mp3_dir = sys.argv[3] if len(sys.argv) > 3 else None
    ws = load_workbook(src, data_only=True)['曲库']
    header = [str(c.value).strip() if c.value else '' for c in ws[1]]
    idx = {name: header.index(name) for name in COLS if name in header}
    missing = [n for n in COLS if n not in idx]
    if missing:
        sys.exit(f'表头缺少列：{missing}')

    songs, errors = [], []
    for row in ws.iter_rows(min_row=2, values_only=True):
        get = lambda k: row[idx[k]] if idx[k] < len(row) else None
        sid = str(get('编号') or '').strip()
        title = str(get('歌名') or '').strip()
        if not title:
            continue  # 空行
        where = f'{sid}《{title}》'
        artist = str(get('作者') or '').strip()
        link = str(get('网页链接') or '').strip()
        lic = str(get('授权') or '').strip()
        genre = str(get('曲风') or '').strip()
        moods = [m for m in (str(get('情绪1') or '').strip(), str(get('情绪2') or '').strip()) if m]
        scenes = [s for s in (str(get(f'场景{i}') or '').strip() for i in (1, 2, 3)) if s]
        energy = to_int(get('能量'), 1, 5)
        valence = to_int(get('情绪正负'), 1, 5)
        fname = str(get('mp3文件名') or f'{sid}.mp3').strip()

        problems = []
        if lic not in LICENSES:
            problems.append(f'授权「{lic}」不可用（只收 CC0 / CC BY / 公共领域）')
        if not artist:
            problems.append('缺作者')
        if not link.startswith('http'):
            problems.append('缺网页链接')
        if genre not in GENRES:
            problems.append(f'曲风「{genre}」不在列表里')
        if not moods or any(m not in MOODS for m in moods):
            problems.append(f'情绪 {moods} 不对')
        if not scenes or any(s not in SCENES for s in scenes):
            problems.append(f'场景 {scenes} 不对')
        if energy is None or valence is None:
            problems.append('能量 / 情绪正负要填 1–5')
        dur = to_int(get('时长秒'), 5, 3600)
        if mp3_dir:
            path = os.path.join(mp3_dir, fname)
            if not os.path.exists(path):
                problems.append(f'找不到文件 {fname}')
            elif dur is None:
                dur = mp3_seconds(path)
        if dur is None:
            problems.append('缺时长秒（或装 mutagen 并给出 mp3 文件夹自动读取）')
        if problems:
            errors.append(f'{where}：' + '；'.join(problems))
            continue

        bpm = to_int(get('BPM'), 30, 250) or 60 + energy * 16
        pop = to_int(get('热度'), 1, 5) or 2
        lic_name, lic_url = LICENSES[lic]
        songs.append({
            'id': sid, 'title': title, 'artist': artist, 'genre': genre, 'moods': moods,
            'energy': energy, 'valence': valence, 'scenes': scenes, 'bpm': bpm, 'pop': pop, 'dur': dur,
            'sources': [{'provider': 'file', 'url': f'/audio/{fname}'}],
            'license': lic_name, 'license_url': lic_url, 'link': link,
            'site': str(get('来源网站') or '').strip(),
        })

    ids = [s['id'] for s in songs]
    dup = {i for i in ids if ids.count(i) > 1}
    if dup:
        sys.exit(f'编号重复：{sorted(dup)}')
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(songs, f, ensure_ascii=False, indent=2)

    print(f'✅ 写入 {len(songs)} 首 → {out}')
    if errors:
        print(f'⚠️ 跳过 {len(errors)} 行：')
        for e in errors:
            print('  - ' + e)
    for name, vocab, key in (('曲风', GENRES, 'genre'), ('场景', SCENES, 'scenes'), ('情绪', MOODS, 'moods')):
        used = {v for s in songs for v in (s[key] if isinstance(s[key], list) else [s[key]])}
        lack = [v for v in vocab if v not in used]
        if lack:
            print(f'ℹ️ 还没有歌的{name}：{"、".join(lack)}')
    if len(songs) < 5:
        print('❗ 少于 5 首时 App 会继续用内置的示意曲库')


if __name__ == '__main__':
    main()
