# MoodMusic AI 上架指南（App 2.7 · Apple Music 版）

> 更新于 2026-10-26。从「注册开发者账号」一直讲到「提交审核」，每一步都写了点哪里。
> 遇到报错或被拒，把截图或拒信发给 Claude。

---

## 0. 先看结论：分三步走

| 阶段 | 能做什么 | 还差什么 |
|---|---|---|
| ① 自己手机上跑 | **已经做到了** | — |
| ② TestFlight 内测（**建议先做**） | 邀请朋友安装试用，最多 1 万人 | 付费开发者账号（688 元/年） |
| ③ App Store 正式上架 | 所有人都能下载 | 还要解决第 4 节的几件事：HTTPS、App 备案、AI 合规、隐私政策网页 |

**TestFlight 不需要 HTTPS、也不需要备案**，可以先发给朋友用起来，同时去办第 4 节的手续。

---

## 1. 注册付费开发者账号（第②③步都需要）

1. 在 iPhone 的 App Store 下载 **Apple Developer** App。
2. 打开它，登录你的 Apple ID，点「账户」→「现在注册」。
3. 选 **个人**，688 元/年。App Store 上的开发者名称会显示你的真实姓名。如果想显示公司名，就选「组织」，需要先申请邓白氏编码，流程更长。
4. 按提示拍身份证、付款，一般 1～2 天审核通过，会收到邮件。
5. 通过后在 Xcode 里：顶部菜单「Xcode」→「Settings」→「Accounts」，确认 Apple ID 下面出现了带「(Individual)」字样的团队。
6. 以后在 Signing & Capabilities 里选 Team 时，**选这个付费团队**，不要再选免费的「Personal Team」。

---

## 2. 在 App Store Connect 里创建 App

1. 浏览器打开 <https://appstoreconnect.apple.com>，登录。
2. 点「App」，再点左上角蓝色「+」→「新建 App」。
3. 依次填写：
   - 平台：**iOS**
   - 名称：`MoodMusic AI`。整个 App Store 里不能重名，被占用就加个后缀，比如 `MoodMusic AI 心情音乐`
   - 主要语言：**简体中文**
   - 套装 ID：下拉选 `com.mypingrou.moodmusic.trial`。如果下拉里没有，先在 Xcode 里选付费团队、点一次 ▶，Xcode 会自动注册
   - SKU：随便填一个自己认得的编号，比如 `moodmusic001`
   - 用户访问权限：**完全访问**
4. 点「创建」。

> 套装 ID 里的「trial」用户看不到，可以不改。改了的话，你手机上现有的数据会丢，等于装了一个新 App。

---

## 3. 打包上传 → TestFlight 内测

### 3.1 打包上传
1. （可选）想让第一版从 1.0 开始：Xcode 左侧点蓝色 **MoodMusic** →「TARGETS」→「MoodMusic」→「General」，把 **Version** 改成 `1.0`，**Build** 改成 `1`。
2. Xcode 顶部的设备选择框，选 **Any iOS Device (arm64)**。
3. 顶部菜单「Product」→「Archive」，等它打包完成，会自动弹出 **Organizer** 窗口。
4. 选中刚打的包，点右侧「Distribute App」→「App Store Connect」→「Distribute」，一路点默认的下一步。
5. 上传成功后等 10～30 分钟，App Store Connect 里这个 App 的「TestFlight」标签下会出现这个版本。

> 以后每次重新上传，**Build 数字都要加 1**（1 → 2 → 3）。
> 用 Archive 打出来的是正式版：「我的」页面里的模型 B 进度、查歌情况、公共曲库状态都会自动隐藏，用户看不到。

### 3.2 邀请测试者
1. 「TestFlight」标签 → 左侧「外部测试」→「+」，新建一个群组，比如「朋友内测」。
2. 把刚上传的版本加进去，填一句测试说明，提交 Beta 审核（通常一天内通过）。
3. 通过后打开「公开链接」，把链接发给朋友。
4. 朋友在 iPhone 上先装 **TestFlight** App，再点你的链接，就能安装。

> 现在服务器还是 HTTP，TestFlight 里可以正常用。

---

## 4. 正式上架前必须解决的事

### 4.1 服务器换成 HTTPS（必须）
现在 App 连的是 `http://121.43.42.164`。正式审核时，苹果很可能要求解释为什么不用 HTTPS，甚至直接拒绝。

1. 给 `mypingrou.com` 做 ICP 备案（阿里云控制台 →「ICP 备案」）。
2. 备案通过后，把子域名 `music.mypingrou.com` 解析到服务器 IP，并配好 HTTPS 证书。这一步可以让 Claude 写一份提示词，交给服务器 AI 去做。
3. 告诉 Claude，我会把 App 里的服务器地址改成 `https://music.mypingrou.com`，并删掉「允许 HTTP」的设置，再给你新包。

### 4.2 中国大陆区需要「App 备案号」（必须）
在中国大陆 App Store 上架的 App，都要填写工信部的 **App 备案号**。

- 办理入口：阿里云控制台 →「ICP 备案」→「新增 App 备案」，可以和域名备案一起办。
- 需要填写 App 名称、套装 ID（`com.mypingrou.moodmusic.trial`），以及签名证书信息（公钥和 SHA-1）。证书信息可以在付费开发者账号开通后，按阿里云页面的说明获取，不会弄就截图发给 Claude。
- 拿到备案号后，填进 App Store Connect 的「App 信息」里。

想先上架海外区的话，在「定价与销售范围」里取消勾选「中国大陆」，就不用等这一项。

### 4.3 AI 功能合规（中国大陆区要确认）
App 用 DeepSeek 理解用户说的话，并给歌曲打标签。在中国大陆提供生成式 AI 服务，可能需要做相关备案或登记，苹果也下架过没有备案的 AI App。

我们的用法比较轻：大模型只把一句话转成「情绪、场景」这类标签，推荐理由是 App 按模板生成的，不直接展示大模型写的文字。但到底需不需要登记，建议**办 App 备案时问一下阿里云备案客服**。如果需要登记、一时又办不下来，有两个办法：
- 中国大陆区暂时不上架，先上海外区；
- 或者先关掉大模型：把服务器 `/etc/moodmusic.env` 里的 DeepSeek 密钥清空，App 会自动改用本地规则，不用改 App。

### 4.4 隐私政策网页（必须）
已经按现在的功能重写好了：`moodmusic-ios-am/privacy-site/moodmusic/privacy.html`。

1. 用文本编辑器打开，把三处【请填写…】换成你的信息：生效日期、你的姓名或公司名、联系邮箱。
2. 你的 `mypingrou.com` 现在指向 GitHub Pages。把这个 `moodmusic` 文件夹放到那个 GitHub Pages 仓库的根目录，网址就是 `https://mypingrou.com/moodmusic/privacy.html`。App 里「查看隐私政策」按钮已经指向这个网址。
3. 上传后用手机浏览器打开这个网址，确认能看到页面。

---

## 5. App Store Connect 里要填的内容

### 5.1 App 信息
- 类别：主要类别选 **音乐**
- 年龄分级：点「设置」，问题全部选「无」，结果应该是 **4+**。（注意：Apple Music 里有些歌曲带「不良内容」标记，如果审核要求调整，再改成 12+。）
- 内容版权：选「**是，包含第三方内容**」，并确认你有权使用。说明：音乐、封面、试听都通过 Apple 官方的 Apple Music 播放器和公开接口获取，App 本身不存储、不分发任何音频。

### 5.2 App 隐私
- 隐私政策网址：`https://mypingrou.com/moodmusic/privacy.html`
- 「数据收集」选「是」，然后勾选 **其他用户内容**：
  - 用途：**App 功能**
  - 是否与用户身份关联：**否**
  - 是否用于追踪：**否**

  原因是用户说的那句话会发到服务器和 DeepSeek 处理。歌名和歌手属于公开的歌曲信息，不算用户数据。工程里的隐私清单文件已经按这个写好了。

### 5.3 版本页
- **截图**：至少要 6.9 英寸 iPhone 的截图（1320 × 2868）。最简单的办法是在你自己的 iPhone 上截图，Pro Max 机型尺寸正好；不是 Pro Max 的话，用 Xcode 里最大屏的 Pro Max 模拟器运行后按 `Cmd + S` 截图。建议截 5 张：首页、推荐结果、播放页、喜欢列表、搜影视原声的结果。
- **宣传文本**（可以直接用）：
  > 说一句心情，AI 懂你，马上推荐适合这一刻的歌。
- **描述**（可以直接用）：
  > MoodMusic AI 是一款懂情绪的音乐推荐 App。说不清想听什么？告诉它你此刻的心情、在做什么、想听完变成什么样，比如「加班到深夜有点累，想放松一下」，AI 就能听懂，推荐 5 首适合这一刻的歌，并告诉你为什么推荐。
  >
  > · 说一句话就能找歌：按心情和场景推荐，也能直接找某首歌、某位歌手，或用中文剧名找影视原声
  > · 越用越懂你：喜欢、跳过、不喜欢都会让下一次推荐更准，而且不会反复推同样的歌
  > · 不用注册：你的喜欢、歌单和偏好只保存在你自己的手机上
  >
  > 音乐由 Apple Music 提供：已订阅 Apple Music 的用户可以听完整歌曲，未订阅的用户可以试听 30 秒片段。
- **关键词**：`心情,音乐推荐,情绪,场景,歌单,放松,专注,助眠,影视原声,AI`
- **技术支持网址**：可以先填隐私政策的网址
- **版权**：`2026 你的姓名`
- **构建版本**：点「+」，选第 3 节上传的版本

### 5.4 审核信息
- 「需要登录」：取消勾选（App 不需要账号）
- 联系信息：填你的姓名、电话、邮箱
- 备注（可以直接用）：
  > This app does not require an account. It recommends songs based on the user's mood, using Apple Music as the only music source: subscribers hear full songs through the system Apple Music player (MPMusicPlayerController); non-subscribers hear the official 30-second previews from Apple's public iTunes Search API. The app does not store or redistribute any audio. Every song has an "Open in Apple Music" link. To test full playback, please use an Apple ID with an active Apple Music subscription; without a subscription, previews still play. Voice input is optional; users can type instead.

最后点右上角「添加以供审核」→「提交审核」，一般 1～3 天出结果。

---

## 6. 审核可能被问到的地方

| 可能的问题 | 我们的情况 / 应对 |
|---|---|
| 服务器没有用 HTTPS | 第 4.1 节办完就没问题 |
| 用了 Apple Music 的内容 | 只用 Apple 官方播放器和公开接口，每首歌都有「在 Apple Music 中打开」，在备注里说明清楚 |
| 中国大陆区 AI 合规 | 第 4.3 节 |
| 功能太少、像演示版（审核指南 4.2） | 现在有 500 多首真实歌曲、热门榜、找歌、找歌手、找影视原声，风险比第一版小很多 |

被拒的话把拒信原文发给 Claude，一起改。
