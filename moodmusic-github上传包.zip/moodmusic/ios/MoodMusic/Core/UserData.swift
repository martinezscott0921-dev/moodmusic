import Foundation

// MARK: - 本地用户数据（免登录，只存在这台设备上；结构与接口文档 §6.3 一致）

struct TasteProfile: Codable, Equatable {
    var artists: [String] = []
    var songs: [String] = []
    var genres: [String] = []
}

/// 反馈增量权重：名称 → 分值
struct FeedbackWeights: Codable, Equatable {
    var genre: [String: Double] = [:]
    var artist: [String: Double] = [:]
    var mood: [String: Double] = [:]
}

struct SongStats: Codable, Equatable {
    var like = 0
    var dislike = 0
    var fav = 0
    var skip = 0
    var play = 0
    var skippedAt: Double? = nil   // 跳过的时间（秒），跳过后 7 天内不再推荐

    var hasAny: Bool { like != 0 || dislike != 0 || fav != 0 || skip != 0 || play != 0 }
}

struct HistoryEntry: Codable, Equatable {
    var ts: Double          // 毫秒时间戳
    var text: String
    var chip: String?
    var target: String
    var ids: [String]
}

enum Feedback: String {
    case like, fav, dislike, skip, play

    /// 反馈权重累加规则（接口文档 §6.4，与后端算法一致）
    var delta: (genre: Double, artist: Double, mood: Double) {
        switch self {
        case .like: return (0.6, 0.8, 0.3)
        case .fav: return (0.8, 1.0, 0.4)
        case .dislike: return (-0.5, -0.9, -0.2)
        case .skip: return (-0.12, -0.18, 0)
        case .play: return (0.15, 0.2, 0.05)
        }
    }
}

/// 歌单 / "我喜欢的音乐"里的一首歌：demo = 内置曲库里的歌；apple = 搜索找到的 Apple Music 歌曲
struct LibItem: Codable, Equatable, Hashable, Identifiable {
    var kind: String
    var id: String
    var title: String
    var artist: String
    var genre: String? = nil
    var collectionName: String? = nil
    var storefront: String? = nil
    var trackViewUrl: String? = nil
    var previewUrl: String? = nil
    var artwork: String? = nil
    var durationMs: Int? = nil
    var likedAt: Double? = nil

    var key: String { kind + ":" + id }
    var isApple: Bool { kind == "apple" }
}

struct Playlist: Codable, Equatable, Identifiable {
    var id: String
    var name: String
    var items: [LibItem] = []
    var createdAt: Double = 0
    var updatedAt: Double = 0
}

struct UserData: Codable, Equatable {
    var onboarded = true
    var migrated = true
    var profile = TasteProfile()      // 2.0 起不再使用，保留字段只为兼容旧数据
    var fw = FeedbackWeights()
    var stats: [String: SongStats] = [:]
    var fav: [String] = []
    var history: [HistoryEntry] = []
    var likedAt: [String: Double] = [:]          // 内置歌曲点喜欢的时间（排序用）
    var appleLikes: [String: LibItem] = [:]      // "apple:<trackId>" → 歌曲
    var playlists: [Playlist] = []
    var shown: [String] = []                     // 推荐过的歌，最早的在前（不重复推荐用）

    func peek(_ id: String) -> SongStats { stats[id] ?? SongStats() }

    static let skipCooldown: Double = 7 * 24 * 3600

    /// 跳过后 7 天内不再推荐这首歌
    func skipActive(_ id: String, now: Double = Date().timeIntervalSince1970) -> Bool {
        let x = peek(id)
        guard x.skip != 0 else { return false }
        return now - (x.skippedAt ?? now) < Self.skipCooldown
    }

    var hasBehavior: Bool { stats.values.contains { $0.hasAny } }

    /// 最近 3 批推荐过的歌（新鲜度降权用）
    var recentIds: [String] {
        var seen = Set<String>(), out: [String] = []
        for h in history.suffix(3) { for id in h.ids where !seen.contains(id) { seen.insert(id); out.append(id) } }
        return out
    }

    mutating func bump(_ s: Song, _ kind: Feedback, sign: Double = 1) {
        let d = kind.delta
        func add(_ v: inout [String: Double], _ key: String, _ x: Double) {
            v[key] = (((v[key] ?? 0) + x) * 1000).rounded() / 1000
        }
        add(&fw.genre, s.genre, d.genre * sign)
        add(&fw.artist, s.artist, d.artist * sign)
        if d.mood != 0 { for m in s.moods { add(&fw.mood, m, d.mood * sign) } }
    }

    /// 记下这一批推荐过的歌：已有的挪到最后，保证"最早推过的"排在最前
    mutating func markShown(_ ids: [String]) {
        let set = Set(ids)
        shown.removeAll { set.contains($0) }
        shown.append(contentsOf: ids)
        if shown.count > 1000 { shown.removeFirst(shown.count - 1000) }
    }

    mutating func addHistory(_ e: HistoryEntry) {
        history.append(e)
        if history.count > 20 { history.removeFirst(history.count - 20) }
    }

    // MARK: 存取（UserDefaults，数据量很小）

    private static let key = "moodmusic.v1"

    static func load() -> UserData {
        guard let data = UserDefaults.standard.data(forKey: key),
              var d = try? JSONDecoder().decode(UserData.self, from: data) else { return UserData() }
        // 老用户升级到 2.0：只清空旧的"初始偏好"，喜欢 / 不喜欢 / 收藏 / 播放记录都保留
        if !d.migrated {
            d.profile = TasteProfile()
            d.onboarded = true
            d.migrated = true
            d.save()
        }
        // 2.5 以前跳过的歌没有记录时间：从现在开始算 7 天
        let now = Date().timeIntervalSince1970
        var changed = false
        for (k, var x) in d.stats where x.skip != 0 && x.skippedAt == nil {
            x.skippedAt = now; d.stats[k] = x; changed = true
        }
        if changed { d.save() }
        return d
    }

    func save() {
        if let data = try? JSONEncoder().encode(self) { UserDefaults.standard.set(data, forKey: Self.key) }
    }

    static func clear() { UserDefaults.standard.removeObject(forKey: key) }
}

// 旧版本缺字段时也能读出来
extension UserData {
    private enum CodingKeys: String, CodingKey { case onboarded, migrated, profile, fw, stats, fav, history, likedAt, appleLikes, playlists, shown }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        onboarded = (try? c.decode(Bool.self, forKey: .onboarded)) ?? false
        migrated = (try? c.decode(Bool.self, forKey: .migrated)) ?? false
        likedAt = (try? c.decode([String: Double].self, forKey: .likedAt)) ?? [:]
        appleLikes = (try? c.decode([String: LibItem].self, forKey: .appleLikes)) ?? [:]
        playlists = (try? c.decode([Playlist].self, forKey: .playlists)) ?? []
        profile = (try? c.decode(TasteProfile.self, forKey: .profile)) ?? TasteProfile()
        fw = (try? c.decode(FeedbackWeights.self, forKey: .fw)) ?? FeedbackWeights()
        stats = (try? c.decode([String: SongStats].self, forKey: .stats)) ?? [:]
        fav = (try? c.decode([String].self, forKey: .fav)) ?? []
        history = (try? c.decode([HistoryEntry].self, forKey: .history)) ?? []
        // 2.5 以前没有这一项：用最近的推荐记录补上
        shown = (try? c.decode([String].self, forKey: .shown)) ?? []
        if (try? c.decode([String].self, forKey: .shown)) == nil { for h in history { markShown(h.ids) } }
    }
}
