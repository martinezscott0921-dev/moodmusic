import Foundation

// MARK: - 推荐结果（与 /api/recommend 的响应一致）

struct ScoreParts: Codable, Equatable {
    var taste: Double?
    var need: Double?
    var sim: Double?
    var fresh: Double?
    var hist: Double?

    subscript(_ k: String) -> Double? {
        switch k {
        case "taste": return taste
        case "need": return need
        case "sim": return sim
        case "fresh": return fresh
        default: return hist
        }
    }
}

struct Recommendation: Codable, Identifiable, Equatable {
    var id: String
    var slot: String
    var total: Int
    var p: ScoreParts
    var reason: String

    private enum CodingKeys: String, CodingKey { case id, slot, total, p, reason }

    init(id: String, slot: String, total: Int, p: ScoreParts, reason: String) {
        self.id = id; self.slot = slot; self.total = total; self.p = p; self.reason = reason
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        let s = (try? c.decode(String.self, forKey: .slot)) ?? "稳妥"
        slot = Vocab.slots.contains(s) ? s : "稳妥"
        total = Int(((try? c.decode(Double.self, forKey: .total)) ?? 0).rounded())
        p = (try? c.decode(ScoreParts.self, forKey: .p)) ?? ScoreParts()
        reason = (try? c.decode(String.self, forKey: .reason)) ?? ""
    }
}

// MARK: - 本地推荐引擎（离线兜底，算法与网页版 / 后端一致）

enum Scoring {
    static let weights: [String: Double] = ["taste": 0.35, "need": 0.30, "sim": 0.15, "fresh": 0.10, "hist": 0.10]
    static let dims: [(key: String, label: String)] = [("taste", "长期口味"), ("need", "当前需求"), ("sim", "歌曲相似度"), ("fresh", "新鲜度"), ("hist", "历史行为")]
}

/// 口味权重：2.0 取消了首次偏好设置，只来自用户主动反馈（喜欢 / 收藏 / 不喜欢 / 跳过 / 听完）
struct TasteModel {
    let base = FeedbackWeights()
    let fw: FeedbackWeights

    init(user: UserData, catalog: Catalog) {
        fw = user.fw
    }

    func genre(_ x: String) -> Double { (base.genre[x] ?? 0) + (fw.genre[x] ?? 0) }
    func artist(_ x: String) -> Double { (base.artist[x] ?? 0) + (fw.artist[x] ?? 0) }
    func mood(_ x: String) -> Double { (base.mood[x] ?? 0) + (fw.mood[x] ?? 0) }

    func maxGenre(_ keys: [String]) -> Double { max(0, keys.map(genre).max() ?? 0) }
    func maxArtist(_ keys: [String]) -> Double { max(0, keys.map(artist).max() ?? 0) }
    func maxMood(_ keys: [String]) -> Double { max(0, keys.map(mood).max() ?? 0) }
}

struct Recommender {
    let catalog: Catalog
    let user: UserData

    private func clamp(_ x: Double, _ a: Double = 0, _ b: Double = 1) -> Double { min(b, max(a, x)) }

    private func vec(_ s: Song) -> [Double] {
        Vocab.genres.map { $0 == s.genre ? 1 : 0 } + Vocab.moods.map { s.moods.contains($0) ? 0.8 : 0 } + [Double(s.energy) / 5, Double(s.valence) / 5]
    }

    private func cos(_ a: [Double], _ b: [Double]) -> Double {
        var d = 0.0, x = 0.0, y = 0.0
        for i in 0..<a.count { d += a[i] * b[i]; x += a[i] * a[i]; y += b[i] * b[i] }
        let n = x * y
        return d / (n == 0 ? 1 : n).squareRoot()
    }

    private func seedIds() -> [String] {
        var seen = Set<String>(), out: [String] = []
        let liked = user.stats.keys.sorted().filter { user.stats[$0]!.like != 0 || user.stats[$0]!.fav != 0 }
        for id in liked where !seen.contains(id) {
            seen.insert(id)
            if catalog.byId[id] != nil && user.peek(id).dislike == 0 { out.append(id) }
        }
        return out
    }

    func needScore(_ s: Song, _ u: Need) -> Double {
        let t = Targets.spec(u.target)
        let mood: Double = t.moods.isEmpty ? 0.55 : clamp(s.moods.reduce(0.0) { a, m in a + (t.moods[0] == m ? 1 : t.moods.contains(m) ? 0.7 : 0) } / 1.4)
        let scene: Double = (u.scene != nil && u.scene != "随便") ? (s.scenes.contains(u.scene!) ? 1 : 0.2) : 0.55
        let en: Double = u.energy == nil ? 0.6 : 1 - abs(Double(s.energy) - u.energy!) / 4
        let va: Double = t.v == nil ? 0.6 : 1 - abs(Double(s.valence) - t.v!) / 4
        var v = mood * 0.45 + scene * 0.25 + en * 0.2 + va * 0.1
        if !u.genres.isEmpty { v = v * 0.75 + (u.genres.contains(s.genre) ? 1 : 0.25) * 0.25 }
        // 说了想听某位歌手（"想听周杰伦的歌"）：曲库里有这位歌手时优先
        if let a = preferredArtist(u) { v = v * 0.7 + (s.artist == a ? 1 : 0) * 0.3 }
        return clamp(v)
    }

    /// 需求里提到的歌手，对应到曲库里的歌手名
    func preferredArtist(_ u: Need) -> String? {
        guard let p = u.artistPreference?.lowercased().filter({ !$0.isWhitespace }), !p.isEmpty else { return nil }
        return catalog.artists.first { a in
            let n = a.lowercased().filter { !$0.isWhitespace }
            return n == p || n.contains(p) || p.contains(n)
        }
    }

    struct Scored {
        let s: Song
        let p: ScoreParts
        let total: Int
        let nearest: Song?
        var slot = "稳妥"
    }

    /// excludeIds：推荐过的歌，最早的在前。只要还有没推过的歌就不重复；
    /// 不够 5 首时，从最早推过的开始放回来（全部推完后按顺序轮回）
    func scoreAll(_ u: Need, excludeIds: [String]) -> [Scored] {
        let tm = TasteModel(user: user, catalog: catalog)
        let gm = tm.maxGenre(Vocab.genres), am = tm.maxArtist(catalog.artists), mm = tm.maxMood(Vocab.moods)
        let tasteOn = gm > 0 || am > 0
        let seeds = seedIds().compactMap { catalog.byId[$0] }
        let histOn = user.hasBehavior
        let recent = Set(user.history.suffix(3).flatMap { $0.ids })
        let tests = NeedParser.exclusions.filter { u.exclude.contains($0.label) }
        // "少推这个歌手 / 曲风"：这一轮直接排除
        let mutedArtists = Set(u.exclusions.filter { $0.type == "artist" }.map(\.value))
        let mutedGenres = Set(u.exclusions.filter { $0.type == "genre" }.map(\.value))
        func allowed(_ s: Song) -> Bool {
            user.peek(s.id).dislike == 0 && !tests.contains { $0.test(s) } && !mutedArtists.contains(s.artist) && !mutedGenres.contains(s.genre)
        }
        // 跳过的歌 7 天内不推；这一轮已经推过的歌也不再出现
        let now = Date().timeIntervalSince1970
        func fresh(_ s: Song) -> Bool { allowed(s) && !user.skipActive(s.id, now: now) }
        var base = catalog.songs.filter(fresh)
        if base.count < 5 { base = catalog.songs.filter(allowed) }
        if base.count < 5 { base = catalog.songs }
        let inBase = Set(base.map(\.id))
        var ex = excludeIds.filter { inBase.contains($0) }
        var exSet = Set(ex)
        if base.count - exSet.count < 5 {
            let drop = min(ex.count, 5 - (base.count - exSet.count))
            ex.removeFirst(drop); exSet = Set(ex)
        }
        let pool = base.filter { !exSet.contains($0.id) }

        let scored: [Scored] = pool.map { s in
            var p = ScoreParts()
            if tasteOn {
                let g = tm.genre(s.genre), a = tm.artist(s.artist)
                let moodPart = mm > 0 ? s.moods.reduce(0.0) { $0 + max(0, tm.mood($1)) } / Double(max(1, s.moods.count)) / mm : 0
                var v = 0.5 * max(0, g) / (gm == 0 ? 1 : gm) + 0.3 * max(0, a) / (am == 0 ? 1 : am) + 0.2 * moodPart
                if g < 0 { v -= min(0.35, -g * 0.3) }
                if a < 0 { v -= min(0.4, -a * 0.35) }
                p.taste = clamp(0.12 + 0.88 * v)
            }
            p.need = needScore(s, u)
            var nearest: Song? = nil
            if !seeds.isEmpty {
                var best = -1.0
                for x in seeds where x.id != s.id {
                    let c = cos(vec(s), vec(x))
                    if c > best { best = c; nearest = x }
                }
                p.sim = best < 0 ? nil : clamp(best)
            }
            p.fresh = clamp(0.7 * (recent.contains(s.id) ? 0.2 : 1) + 0.3 * (1 - Double(s.pop - 1) / 4))
            if histOn {
                let x = user.peek(s.id)
                p.hist = clamp(0.5 + 0.3 * Double(x.like) + 0.3 * Double(x.fav) + 0.08 * Double(min(x.play, 3)) - 0.25 * Double(min(x.skip, 2)))
            }
            var sum = 0.0, wt = 0.0
            for d in Scoring.dims { if let v = p[d.key] { sum += Scoring.weights[d.key]! * v; wt += Scoring.weights[d.key]! } }
            return Scored(s: s, p: p, total: Int((sum / wt * 100).rounded()), nearest: nearest)
        }
        // 稳定排序：分数相同保持曲库顺序（与 JS 一致）
        return scored.enumerated().sorted { $0.element.total != $1.element.total ? $0.element.total > $1.element.total : $0.offset < $1.offset }.map { $0.element }
    }

    /// 3 首稳妥 + 1 首探索 + 1 首惊喜，同一歌手 / 曲风最多 2 首
    func recommend(_ u: Need, excludeIds: [String]) -> [Recommendation] {
        let scored = scoreAll(u, excludeIds: excludeIds)
        let tm = TasteModel(user: user, catalog: catalog)
        var picked: [Scored] = []
        var ca: [String: Int] = [:], cg: [String: Int] = [:]
        func isPicked(_ x: Scored) -> Bool { picked.contains { $0.s.id == x.s.id } }
        func ok(_ x: Scored) -> Bool { !isPicked(x) && (ca[x.s.artist] ?? 0) < 2 && (cg[x.s.genre] ?? 0) < 2 }
        func add(_ x: Scored, _ slot: String) {
            var y = x; y.slot = slot; picked.append(y)
            ca[x.s.artist, default: 0] += 1; cg[x.s.genre, default: 0] += 1
        }
        func popInv(_ x: Scored) -> Double { 1 - Double(x.s.pop - 1) / 4 }
        func stableMax(_ list: [Scored], by key: (Scored) -> Double) -> Scored? {
            var best: Scored? = nil, bv = -Double.infinity
            for x in list { let v = key(x); if v > bv { bv = v; best = x } }
            return best
        }

        for x in scored { if picked.count >= 3 { break }; if ok(x) { add(x, "稳妥") } }

        let knownA: (String) -> Bool = { tm.artist($0) > 0 }
        if let ex = stableMax(scored.filter { ok($0) && !knownA($0.s.artist) && ($0.p.need ?? 0) >= 0.45 },
                              by: { 0.45 * ($0.p.need ?? 0) + 0.35 * ($0.p.sim ?? 0.5) + 0.2 * popInv($0) }) {
            add(ex, "探索")
        }

        let gm = tm.maxGenre(Vocab.genres)
        if let su = stableMax(scored.filter { x in ok(x) && tm.genre(x.s.genre) <= 0.25 * gm && (x.p.need ?? 0) >= 0.5 && !picked.contains { $0.s.genre == x.s.genre } },
                              by: { 0.7 * ($0.p.need ?? 0) + 0.3 * popInv($0) }) {
            add(su, "惊喜")
        }

        for x in scored { if picked.count >= 5 { break }; if ok(x) { add(x, "稳妥") } }
        for x in scored { if picked.count >= 5 { break }; if !isPicked(x) { add(x, "稳妥") } }

        let order = ["稳妥": 0, "探索": 1, "惊喜": 2]
        let sorted = picked.enumerated()
            .sorted { order[$0.element.slot]! != order[$1.element.slot]! ? order[$0.element.slot]! < order[$1.element.slot]! : $0.offset < $1.offset }
            .map(\.element)
        // 同一批里理由不重复
        var seenReasons = Set<String>()
        return sorted.enumerated().map { i, x in
            var r = reason(x, u, tm, idx: i)
            if seenReasons.contains(r) { r = reason(x, u, tm, idx: i + 1) }
            if seenReasons.contains(r) { r = "\(x.s.artist)《\(x.s.title)》：\(r)" }
            seenReasons.insert(r)
            return Recommendation(id: x.s.id, slot: x.slot, total: x.total, p: x.p, reason: r)
        }
    }

    static let reasonMaxLen = 64

    private func reason(_ x: Scored, _ u: Need, _ tm: TasteModel, idx: Int) -> String {
        let s = x.s, t = Targets.spec(u.target)
        let hit = s.moods.filter { t.moods.contains($0) }
        let moodTxt = (hit.isEmpty ? s.moods : hit).joined(separator: "、")
        let phrase = Targets.phrase[u.target] ?? ""
        let sc = (u.scene != nil && s.scenes.contains(u.scene!)) ? "，很适合\(u.scene == "学习" ? "工作学习" : u.scene!)的时候" : ""
        let energyOk = u.energy != nil && abs(Double(s.energy) - u.energy!) <= 0.6
        let tA = tm.artist(s.artist) > 0, tG = tm.genre(s.genre) > 0
        var body: String
        if x.slot == "探索" {
            if let n = x.nearest, (x.p.sim ?? 0) > 0.55 {
                body = "和你喜欢的《\(n.title)》风格相近，\(s.artist)可能是你还没发现的宝藏；\(moodTxt)的感觉\(phrase)"
            } else {
                body = "\(s.artist)的\(s.genre)，你可能还没听过；\(moodTxt)的感觉\(phrase)\(sc)"
            }
        } else if x.slot == "惊喜" {
            body = "平时你很少听\(s.genre)，但这首的\(moodTxt)\(u.target == "随心" ? "也许会给你一点新鲜感" : "正好" + phrase)\(sc)"
        } else {
            let lead = tA ? "来自你喜欢的\(s.artist)，" : tG ? "是你偏爱的\(s.genre)，" : ""
            switch idx % 3 {
            case 1: body = "\(lead)\(moodTxt)的感觉\(phrase)\(sc)，\(energyOk ? "节奏也刚好合你的口味" : moodTxt + "的氛围很对")"
            case 2: body = "\(lead)它的\(moodTxt)气质\(phrase)\(sc)"
            default: body = "\(lead)\(moodTxt)的感觉\(phrase)\(sc)"
            }
        }
        if let c = u.current, c != u.target { body += "，从\(c)慢慢到\(u.target)" }
        if !u.exclude.isEmpty { body += "，也避开了你不想听的\(u.exclude.joined(separator: "、"))" }
        var r = body + "。"
        if r.count > Self.reasonMaxLen { r = String(r.prefix(Self.reasonMaxLen - 1)) + "。" }
        return r
    }
}
