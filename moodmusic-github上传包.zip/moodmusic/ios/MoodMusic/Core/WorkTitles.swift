import Foundation

// MARK: - 影视作品：中文名 → 英文名
// Apple Music 里欧美影视原声基本只用英文名登记，用中文名搜不到。
// 常见作品先放在这里（不用联网）；这里没有的，再请服务器上的 AI 翻译（/api/work-title）。

enum WorkTitles {
    static let zhToEn: [String: String] = [
        // 美剧 / 英剧
        "怪奇物语": "Stranger Things", "怪奇物語": "Stranger Things", "行尸走肉": "The Walking Dead", "陰屍路": "The Walking Dead",
        "权力的游戏": "Game of Thrones", "权游": "Game of Thrones", "冰与火之歌": "Game of Thrones", "龙之家族": "House of the Dragon",
        "绝命毒师": "Breaking Bad", "风骚律师": "Better Call Saul", "老友记": "Friends", "生活大爆炸": "The Big Bang Theory",
        "越狱": "Prison Break", "神探夏洛克": "Sherlock", "西部世界": "Westworld", "黑镜": "Black Mirror", "纸牌屋": "House of Cards",
        "唐顿庄园": "Downton Abbey", "王冠": "The Crown", "鱿鱼游戏": "Squid Game", "星期三": "Wednesday", "曼达洛人": "The Mandalorian",
        "最后生还者": "The Last of Us", "最后的生还者": "The Last of Us", "继承之战": "Succession", "黑袍纠察队": "The Boys",
        "猎魔人": "The Witcher", "巫师": "The Witcher", "真探": "True Detective", "广告狂人": "Mad Men", "迷失": "Lost",
        "绯闻女孩": "Gossip Girl", "欲望都市": "Sex and the City", "实习医生格蕾": "Grey's Anatomy", "豪斯医生": "House",
        "摩登家庭": "Modern Family", "破产姐妹": "2 Broke Girls", "犯罪心理": "Criminal Minds", "邪恶力量": "Supernatural",
        "吸血鬼日记": "The Vampire Diaries", "使女的故事": "The Handmaid's Tale", "后翼弃兵": "The Queen's Gambit",
        "毒枭": "Narcos", "纸钞屋": "Money Heist", "金钱劫案": "Money Heist", "浴血黑帮": "Peaky Blinders", "英雄联盟：双城之战": "Arcane",
        "双城之战": "Arcane", "瑞克和莫蒂": "Rick and Morty", "辛普森一家": "The Simpsons", "海绵宝宝": "SpongeBob SquarePants",
        "幸存者": "Survivor", "傲骨贤妻": "The Good Wife", "眼泪制造者": "Euphoria", "亢奋": "Euphoria", "白莲花度假村": "The White Lotus",
        "人生切割术": "Severance", "熊家餐馆": "The Bear", "指环王：力量之戒": "The Lord of the Rings: The Rings of Power",
        // 电影
        "泰坦尼克号": "Titanic", "阿凡达": "Avatar", "星际穿越": "Interstellar", "盗梦空间": "Inception", "蝙蝠侠：黑暗骑士": "The Dark Knight",
        "黑暗骑士": "The Dark Knight", "复仇者联盟": "Avengers", "钢铁侠": "Iron Man", "蜘蛛侠": "Spider-Man", "银河护卫队": "Guardians of the Galaxy",
        "星球大战": "Star Wars", "哈利波特": "Harry Potter", "哈利·波特": "Harry Potter", "指环王": "The Lord of the Rings", "霍比特人": "The Hobbit",
        "加勒比海盗": "Pirates of the Caribbean", "侏罗纪公园": "Jurassic Park", "变形金刚": "Transformers", "速度与激情": "Fast & Furious",
        "碟中谍": "Mission: Impossible", "007": "James Bond", "冰雪奇缘": "Frozen", "狮子王": "The Lion King", "疯狂动物城": "Zootopia",
        "寻梦环游记": "Coco", "海洋奇缘": "Moana", "魔法满屋": "Encanto", "小美人鱼": "The Little Mermaid", "美女与野兽": "Beauty and the Beast",
        "阿拉丁": "Aladdin", "玩具总动员": "Toy Story", "头脑特工队": "Inside Out", "飞屋环游记": "Up", "机器人总动员": "WALL-E",
        "怪兽电力公司": "Monsters, Inc.", "海底总动员": "Finding Nemo", "超人总动员": "The Incredibles", "功夫熊猫": "Kung Fu Panda",
        "怪物史莱克": "Shrek", "小黄人": "Minions", "神偷奶爸": "Despicable Me", "爱乐之城": "La La Land", "马戏之王": "The Greatest Showman",
        "波西米亚狂想曲": "Bohemian Rhapsody", "一个明星的诞生": "A Star Is Born", "芭比": "Barbie", "奥本海默": "Oppenheimer",
        "沙丘": "Dune", "壮志凌云": "Top Gun", "壮志凌云：独行侠": "Top Gun: Maverick", "教父": "The Godfather", "肖申克的救赎": "The Shawshank Redemption",
        "阿甘正传": "Forrest Gump", "这个杀手不太冷": "Léon", "黑客帝国": "The Matrix", "终结者": "Terminator", "角斗士": "Gladiator",
        "辛德勒的名单": "Schindler's List", "罗马假日": "Roman Holiday", "音乐之声": "The Sound of Music", "歌剧魅影": "The Phantom of the Opera",
        "悲惨世界": "Les Misérables", "猫": "Cats", "芝加哥": "Chicago", "妈妈咪呀": "Mamma Mia!", "歌舞青春": "High School Musical",
        "暮光之城": "Twilight", "饥饿游戏": "The Hunger Games", "007：无暇赴死": "No Time to Die", "小丑": "Joker", "海王": "Aquaman",
        "神奇女侠": "Wonder Woman", "黑豹": "Black Panther", "雷神": "Thor", "美国队长": "Captain America", "死侍": "Deadpool",
        "银翼杀手": "Blade Runner", "疯狂的麦克斯": "Mad Max", "低俗小说": "Pulp Fiction", "杀死比尔": "Kill Bill", "爆裂鼓手": "Whiplash",
        "美丽心灵": "A Beautiful Mind", "怦然心动": "Flipped", "真爱至上": "Love Actually", "恋恋笔记本": "The Notebook",
        "蒂凡尼的早餐": "Breakfast at Tiffany's", "了不起的盖茨比": "The Great Gatsby", "放牛班的春天": "Les Choristes",
        "天使爱美丽": "Amélie", "海上钢琴师": "The Legend of 1900", "触不可及": "Intouchables", "月光男孩": "Moonlight",
        "请以你的名字呼唤我": "Call Me by Your Name", "绿皮书": "Green Book", "寄生虫": "Parasite", "瞬息全宇宙": "Everything Everywhere All at Once",
        "蜘蛛侠：纵横宇宙": "Spider-Man: Across the Spider-Verse", "蜘蛛侠：平行宇宙": "Spider-Man: Into the Spider-Verse",
        // 日本动画（Apple Music 多用英文或日文名）
        "千与千寻": "Spirited Away", "龙猫": "My Neighbor Totoro", "哈尔的移动城堡": "Howl's Moving Castle", "天空之城": "Castle in the Sky",
        "幽灵公主": "Princess Mononoke", "魔女宅急便": "Kiki's Delivery Service", "悬崖上的金鱼姬": "Ponyo", "起风了": "The Wind Rises",
        "你的名字": "Your Name", "天气之子": "Weathering with You", "铃芽之旅": "Suzume", "灌篮高手": "Slam Dunk", "海贼王": "One Piece",
        "航海王": "One Piece", "火影忍者": "Naruto", "进击的巨人": "Attack on Titan", "鬼灭之刃": "Demon Slayer", "咒术回战": "Jujutsu Kaisen",
        "间谍过家家": "Spy x Family", "名侦探柯南": "Detective Conan", "新世纪福音战士": "Neon Genesis Evangelion", "EVA": "Evangelion",
        "龙珠": "Dragon Ball", "美少女战士": "Sailor Moon", "钢之炼金术师": "Fullmetal Alchemist", "死亡笔记": "Death Note",
        "电锯人": "Chainsaw Man", "排球少年": "Haikyu!!", "我的英雄学院": "My Hero Academia", "四月是你的谎言": "Your Lie in April",
        "紫罗兰永恒花园": "Violet Evergarden", "孤独摇滚": "Bocchi the Rock!", "葬送的芙莉莲": "Frieren",
        // 游戏
        "原神": "Genshin Impact", "塞尔达传说": "The Legend of Zelda", "最终幻想": "Final Fantasy", "我的世界": "Minecraft",
        "巫师3": "The Witcher 3", "艾尔登法环": "Elden Ring", "黑神话：悟空": "Black Myth: Wukong", "黑神话悟空": "Black Myth: Wukong",
    ]

    static func hasCJK(_ s: String) -> Bool {
        s.unicodeScalars.contains { (0x4E00...0x9FFF).contains($0.value) || (0x3400...0x4DBF).contains($0.value) }
    }

    /// 内置表里的英文名（去掉书名号、空格后比对）
    static func english(for title: String) -> String? {
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "《》\"“”"))
        if let e = zhToEn[t] { return e }
        let key = t.replacingOccurrences(of: " ", with: "")
        return zhToEn.first { $0.key.replacingOccurrences(of: " ", with: "") == key }?.value
    }
}
