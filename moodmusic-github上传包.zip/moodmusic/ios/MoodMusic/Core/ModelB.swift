import Foundation

// MARK: - 模型 B：歌曲标签
// 歌曲进入曲库 → 服务器上的模型 B 分析 → 标签存在手机上 → 推荐时直接读取。
// 进入曲库的歌：App 自带的 50 首真实歌曲，以及你搜到、喜欢、加进歌单的 Apple Music 歌曲。

struct SongTags: Codable, Equatable {
    var genre: String
    var moods: [String]
    var energy: Int
    var valence: Int
    var scenes: [String]
    var audience: String?
    var bpm: Int?

    static let sceneVocab = ["通勤", "睡前", "学习", "运动", "开车", "发呆", "放松", "难过", "开心"]

    private enum CodingKeys: String, CodingKey { case genre, moods, energy, valence, scenes, audience, bpm }

    init(genre: String, moods: [String], energy: Int, valence: Int, scenes: [String], audience: String? = nil, bpm: Int? = nil) {
        self.genre = genre; self.moods = moods; self.energy = energy; self.valence = valence
        self.scenes = scenes; self.audience = audience; self.bpm = bpm
    }

    /// 宽松解码 + 校验：不在枚举里的值丢掉，曲风不合法或没有情绪 / 场景就当这首没打好
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        func num(_ k: CodingKeys) -> Int? {
            if let v = try? c.decode(Int.self, forKey: k) { return v }
            if let v = try? c.decode(Double.self, forKey: k) { return Int(v.rounded()) }
            return nil
        }
        let g = (try? c.decode(String.self, forKey: .genre)) ?? ""
        let m = ((try? c.decode([String].self, forKey: .moods)) ?? []).filter { Vocab.moods.contains($0) }
        let s = ((try? c.decode([String].self, forKey: .scenes)) ?? []).filter { Self.sceneVocab.contains($0) }
        guard Vocab.genres.contains(g), !m.isEmpty, !s.isEmpty else {
            throw DecodingError.dataCorruptedError(forKey: .genre, in: c, debugDescription: "标签不完整")
        }
        genre = g
        moods = Array(m.prefix(3))
        scenes = Array(s.prefix(3))
        energy = min(5, max(1, num(.energy) ?? 3))
        valence = min(5, max(1, num(.valence) ?? 3))
        let a = (try? c.decode(String.self, forKey: .audience))?.trimmingCharacters(in: .whitespacesAndNewlines)
        audience = a.flatMap { $0.isEmpty ? nil : String($0.prefix(30)) }
        bpm = num(.bpm).flatMap { (40...200).contains($0) ? $0 : nil }
    }

    /// 把标签套到一首歌上（推荐打分读的就是这些字段）
    func apply(to s: Song) -> Song {
        var x = s
        x.genre = genre; x.moods = moods; x.energy = energy; x.valence = valence; x.scenes = scenes
        if let bpm { x.bpm = bpm }
        return x
    }
}

/// 模型 B 打好的标签，存在这台手机上
struct TagStore: Codable {
    /// 歌曲编号 → 标签。内置歌曲用 am001 这样的编号，Apple Music 歌曲用 apple:<trackId>
    var tags: [String: SongTags] = [:]
    /// 进入曲库的 Apple Music 歌曲（编号 apple:<trackId>）
    var items: [String: LibItem] = [:]

    private static let key = "moodmusic.modelB.v1"

    static func load() -> TagStore {
        guard let d = UserDefaults.standard.data(forKey: key), let s = try? JSONDecoder().decode(TagStore.self, from: d) else { return TagStore() }
        return s
    }

    func save() {
        if let d = try? JSONEncoder().encode(self) { UserDefaults.standard.set(d, forKey: Self.key) }
    }

    // 单首标签解析失败时只丢掉那一首，不影响其余
    private enum CodingKeys: String, CodingKey { case tags, items }
    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        items = (try? c.decode([String: LibItem].self, forKey: .items)) ?? [:]
        let raw = (try? c.decode([String: Lenient<SongTags>].self, forKey: .tags)) ?? [:]
        tags = raw.compactMapValues(\.value)
    }
}

/// 解码失败时得到 nil，而不是让整个字典解码失败
struct Lenient<T: Decodable>: Decodable {
    let value: T?
    init(from decoder: Decoder) throws { value = try? T(from: decoder) }
}
