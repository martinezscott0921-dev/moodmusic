import Foundation

// MARK: - 演示音源：按歌曲的情绪、能量和速度合成 45 秒示意旋律（不是原曲）
// 和网页版 Web Audio 合成的旋律一致：同一首歌每次生成的旋律相同。
// 这里只做纯计算（输出 Float 采样），播放交给 Services/AudioPlayer.swift。

enum SynthComposer {
    static let sampleRate: Double = 32_000

    private enum Wave { case sine, triangle, square }
    private enum NoiseFilter { case highpass, bandpass }

    private struct Plan {
        let root: Int
        let scale: [Int]
        let prog: [Int]
        let dia: [Int]
        let step: Double
        let total: Int
        let motif: [Int]
        let motif2: [Int]
        let e: Int

        func chord(_ deg: Int) -> [Int] {
            [0, 2, 4].map { k in let i = deg + k; return dia[i % 7] + 12 * (i / 7) }
        }
    }

    private static func hz(_ m: Int) -> Double { 440 * pow(2, Double(m - 69) / 12) }

    private static func compose(_ s: Song) -> Plan {
        let n = s.number
        var x = n * 7919 + 13
        func r() -> Double { x = (x * 9301 + 49297) % 233280; return Double(x) / 233280 }
        let major = s.valence >= 3
        let dia = major ? [0, 2, 4, 5, 7, 9, 11] : [0, 2, 3, 5, 7, 8, 10]
        let scale = major ? [0, 2, 4, 7, 9, 12, 14, 16] : [0, 3, 5, 7, 10, 12, 15, 17]
        let progs = major ? [[0, 5, 3, 4], [0, 3, 4, 4], [0, 4, 5, 3], [0, 5, 1, 4]] : [[0, 5, 2, 6], [0, 3, 4, 0], [0, 6, 5, 6], [0, 5, 3, 4]]
        let step = 60 / Double(max(40, s.bpm)) / 2
        let total = Int(floor(Double(s.dur) / step))
        let dens = 0.3 + Double(s.energy) * 0.1
        var motif: [Int] = []
        for _ in 0..<16 { motif.append(r() < dens ? Int(floor(r() * Double(scale.count))) : -1) }
        let motif2: [Int] = motif.map { v in
            if v < 0 { return r() < 0.2 ? Int(floor(r() * Double(scale.count))) : -1 }
            if r() < 0.35 { return min(scale.count - 1, max(0, v + (r() < 0.5 ? 1 : -1))) }
            return v
        }
        return Plan(root: 45 + (n * 7) % 12, scale: scale, prog: progs[n % 4], dia: dia, step: step, total: total,
                    motif: motif, motif2: motif2, e: s.energy)
    }

    // MARK: 渲染

    /// 生成整首歌的单声道采样
    static func render(_ s: Song) -> [Float] {
        let c = compose(s)
        let sr = sampleRate
        let length = Int(Double(s.dur) * sr) + Int(sr)   // 多留 1 秒尾音
        var out = [Float](repeating: 0, count: length)
        var noiseSeed: UInt32 = UInt32(truncatingIfNeeded: s.number &* 2654435761)

        out.withUnsafeMutableBufferPointer { buf in
            // 一个音：振荡器 → 低通 → 包络（起音 15ms，0.7d 后指数衰减）
            func tone(_ f: Double, _ t: Double, _ d: Double, _ wave: Wave, _ g: Double, _ cut: Double) {
                let start = Int(t * sr), end = min(buf.count, Int((t + d + 0.4) * sr))
                guard start < end else { return }
                var lp = Biquad.lowpass(cut, sr)
                var phase = 0.0
                let inc = f / sr
                let attack = 0.015, releaseAt = d * 0.7, tau = max(0.001, d * 0.18)
                for i in start..<end {
                    let tt = Double(i - start) / sr
                    var env: Double
                    if tt < attack { env = g * tt / attack }
                    else if tt < releaseAt { env = g }
                    else { env = g * exp(-(tt - releaseAt) / tau) }
                    let osc: Double
                    switch wave {
                    case .sine: osc = sin(2 * .pi * phase)
                    case .triangle: osc = 1 - 4 * abs(phase - 0.5)
                    case .square: osc = phase < 0.5 ? 1 : -1
                    }
                    phase += inc
                    if phase >= 1 { phase -= 1 }
                    buf[i] += Float(lp.process(osc) * env)
                }
            }
            // 噪声打击（踩镲 / 军鼓）
            func hit(_ t: Double, _ type: NoiseFilter, _ freq: Double, _ g: Double, _ dec: Double) {
                let start = Int(t * sr), end = min(buf.count, Int((t + dec + 0.05) * sr))
                guard start < end else { return }
                var flt = type == .highpass ? Biquad.highpass(freq, sr) : Biquad.bandpass(freq, sr)
                let k = log(0.001 / g) / dec
                for i in start..<end {
                    let tt = Double(i - start) / sr
                    noiseSeed = noiseSeed &* 1664525 &+ 1013904223
                    let nz = Double(noiseSeed >> 8) / Double(1 << 24) * 2 - 1
                    let env = tt <= dec ? g * exp(k * tt) : 0.001
                    buf[i] += Float(flt.process(nz) * env)
                }
            }
            // 底鼓：140Hz → 45Hz 下滑
            func kick(_ t: Double) {
                let start = Int(t * sr), end = min(buf.count, Int((t + 0.3) * sr))
                guard start < end else { return }
                var phase = 0.0
                let kf = log(45.0 / 140.0) / 0.12, kg = log(0.001 / 0.55) / 0.28
                for i in start..<end {
                    let tt = Double(i - start) / sr
                    let f = tt < 0.12 ? 140 * exp(kf * tt) : 45
                    phase += f / sr
                    let env = tt < 0.28 ? 0.55 * exp(kg * tt) : 0.001
                    buf[i] += Float(sin(2 * .pi * phase) * env)
                }
            }

            for i in 0..<c.total {
                let t = 0.06 + Double(i) * c.step
                let bar = i / 8, deg = c.prog[bar % 4], ch = c.chord(deg)
                let fade = i >= c.total - 16 ? Double(c.total - i) / 16 : 1
                if i % 8 == 0 { for k in ch { tone(hz(c.root + 12 + k), t, c.step * 8, .triangle, 0.045 * fade, 1500) } }
                let be = c.e >= 3 ? 2 : 4
                if i % be == 0 { tone(hz(c.root - 12 + ch[0]), t, c.step * Double(be) * 0.9, .sine, 0.17 * fade, 500) }
                if bar >= 1 {
                    let ph = (i / 16) % 4 == 3 ? c.motif2 : c.motif
                    let v = ph[i % 16]
                    if v >= 0 {
                        let len = c.step * (ph[(i + 1) % 16] < 0 ? 1.8 : 0.9)
                        tone(hz(c.root + 24 + c.scale[v]), t, len, c.e >= 4 ? .square : .sine, (c.e >= 4 ? 0.028 : 0.075) * fade, c.e >= 4 ? 2400 : 3200)
                    }
                }
                if c.e >= 3 && bar >= 1 {
                    if i % 4 == 0 { kick(t) }
                    if i % 2 == 1 { hit(t, .highpass, 7000, (c.e >= 4 ? 0.05 : 0.03) * fade, 0.05) }
                    if c.e >= 4 && i % 8 == 4 { hit(t, .bandpass, 1800, 0.14 * fade, 0.16) }
                }
                if c.e <= 2 && i % 16 == 8 { tone(hz(c.root + 36 + c.scale[(i / 16) % 5]), t, c.step * 4, .sine, 0.03 * fade, 5000) }
            }

            // 总线：增益 0.8 + 简单压缩（代替 Web Audio 的 DynamicsCompressor）
            var env: Float = 0
            let threshold: Float = 0.25, ratio: Float = 4
            let att = Float(exp(-1 / (0.003 * sr))), rel = Float(exp(-1 / (0.25 * sr)))
            var peak: Float = 0
            for i in 0..<buf.count {
                let x = buf[i] * 0.8
                let a = abs(x)
                env = a > env ? att * env + (1 - att) * a : rel * env + (1 - rel) * a
                var gain: Float = 1
                if env > threshold { gain = (threshold + (env - threshold) / ratio) / env }
                let y = x * gain
                buf[i] = y
                peak = max(peak, abs(y))
            }
            if peak > 0 {
                let norm = 0.85 / peak
                for i in 0..<buf.count { buf[i] *= norm }
            }
        }
        return out
    }
}

/// RBJ 双二阶滤波器
struct Biquad {
    var b0 = 0.0, b1 = 0.0, b2 = 0.0, a1 = 0.0, a2 = 0.0
    var x1 = 0.0, x2 = 0.0, y1 = 0.0, y2 = 0.0

    private static func make(_ f: Double, _ sr: Double, _ q: Double, _ kind: Int) -> Biquad {
        let w = 2 * Double.pi * min(f, sr * 0.45) / sr
        let alpha = sin(w) / (2 * q), cw = cos(w)
        var b = Biquad()
        let a0: Double
        switch kind {
        case 0: // lowpass
            b.b0 = (1 - cw) / 2; b.b1 = 1 - cw; b.b2 = (1 - cw) / 2
        case 1: // highpass
            b.b0 = (1 + cw) / 2; b.b1 = -(1 + cw); b.b2 = (1 + cw) / 2
        default: // bandpass (0 dB peak)
            b.b0 = alpha; b.b1 = 0; b.b2 = -alpha
        }
        a0 = 1 + alpha
        b.a1 = -2 * cw / a0; b.a2 = (1 - alpha) / a0
        b.b0 /= a0; b.b1 /= a0; b.b2 /= a0
        return b
    }
    static func lowpass(_ f: Double, _ sr: Double) -> Biquad { make(f, sr, 0.8, 0) }
    static func highpass(_ f: Double, _ sr: Double) -> Biquad { make(f, sr, 0.8, 1) }
    static func bandpass(_ f: Double, _ sr: Double) -> Biquad { make(f, sr, 1.0, 2) }

    mutating func process(_ x: Double) -> Double {
        let y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = x; y2 = y1; y1 = y
        return y
    }
}
