import Foundation

// MARK: - 结构化需求（与 /api/understand 的响应一致，2.0 增加了意图、实体和追问字段）

/// 识别到的具体对象：歌名 / 歌手 / 影视作品
struct Entities: Codable, Equatable {
    var song: String? = nil
    var artist: String? = nil
    var workTitle: String? = nil
    var soundtrackType: String? = nil

    private enum CodingKeys: String, CodingKey { case song, artist, workTitle = "work_title", soundtrackType = "soundtrack_type" }
    static let soundtrackTypes = ["theme", "opening", "ending", "insert", "score", "any"]

    init(song: String? = nil, artist: String? = nil, workTitle: String? = nil, soundtrackType: String? = nil) {
        self.song = song; self.artist = artist; self.workTitle = workTitle; self.soundtrackType = soundtrackType
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        func str(_ k: CodingKeys) -> String? {
            guard let v = try? c.decode(String.self, forKey: k) else { return nil }
            let t = v.trimmingCharacters(in: .whitespacesAndNewlines)
            return t.isEmpty ? nil : t
        }
        song = str(.song); artist = str(.artist); workTitle = str(.workTitle)
        let st = str(.soundtrackType)
        soundtrackType = st.flatMap { Self.soundtrackTypes.contains($0) ? $0 : nil }
    }
}

/// 追问的选项
struct ClarifyOption: Codable, Equatable, Hashable {
    var value: String
    var label: String
}

/// "少推这个歌手 / 曲风"：只对这一轮推荐生效
struct Exclusion: Codable, Equatable, Hashable {
    var type: String    // artist | genre
    var value: String
}

struct Need: Decodable, Equatable {
    var text: String
    var chip: String?
    var current: String?
    var target: String
    var scene: String?
    var energy: Double?
    var time: String?
    var exclude: [String]
    var genres: [String]
    var exclusions: [Exclusion] = []
    /// recommend = 按心情推荐；specify_song = 找指定歌曲；soundtrack = 找影视作品的歌
    var intent = "recommend"
    var entities = Entities()
    var artistPreference: String? = nil
    var needsClarification = false
    var clarificationQuestion: String? = nil
    var clarificationOptions: [ClarifyOption] = []
    var clarificationDimension: String? = nil

    static let intents = ["recommend", "specify_song", "soundtrack"]

    private enum CodingKeys: String, CodingKey {
        case text, chip, current, target, scene, energy, time, exclude, genres, exclusions, intent, entities
        case artistPreference = "artist_preference", needsClarification = "needs_clarification"
        case clarificationQuestion = "clarification_question", clarificationOptions = "clarification_options"
        case clarificationDimension = "clarification_dimension"
    }

    init(text: String, chip: String?, current: String?, target: String, scene: String?, energy: Double?,
         time: String?, exclude: [String], genres: [String]) {
        self.text = text; self.chip = chip; self.current = current; self.target = target; self.scene = scene
        self.energy = energy; self.time = time; self.exclude = exclude; self.genres = genres
    }

    /// 服务器有没有返回意图（旧版服务器没有，要用本地规则补）
    private(set) var serverHasIntent = false

    // 宽松解码：服务器字段缺失或类型不对时给默认值（等同网页版 norm()）
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        func str(_ k: CodingKeys) -> String? {
            guard let v = try? c.decode(String.self, forKey: k) else { return nil }
            let t = v.trimmingCharacters(in: .whitespacesAndNewlines)
            return t.isEmpty ? nil : t
        }
        text = (try? c.decode(String.self, forKey: .text)) ?? ""
        chip = try? c.decode(String.self, forKey: .chip)
        current = try? c.decode(String.self, forKey: .current)
        let t = (try? c.decode(String.self, forKey: .target)) ?? "随心"
        target = Targets.all[t] != nil ? t : "随心"
        scene = try? c.decode(String.self, forKey: .scene)
        energy = try? c.decode(Double.self, forKey: .energy)
        time = try? c.decode(String.self, forKey: .time)
        exclude = (try? c.decode([String].self, forKey: .exclude)) ?? []
        genres = (try? c.decode([String].self, forKey: .genres)) ?? []
        exclusions = ((try? c.decode([LooseExclusion].self, forKey: .exclusions)) ?? []).compactMap(\.value)
        let it = try? c.decode(String.self, forKey: .intent)
        serverHasIntent = it != nil
        intent = it.flatMap { Self.intents.contains($0) ? $0 : nil } ?? "recommend"
        entities = (try? c.decode(Entities.self, forKey: .entities)) ?? Entities()
        artistPreference = str(.artistPreference)
        needsClarification = (try? c.decode(Bool.self, forKey: .needsClarification)) ?? false
        clarificationQuestion = str(.clarificationQuestion)
        clarificationOptions = ((try? c.decode([LooseOption].self, forKey: .clarificationOptions)) ?? []).compactMap(\.value)
        clarificationDimension = str(.clarificationDimension)
    }

    // 列表里单个坏元素不影响其他元素
    private struct LooseExclusion: Decodable {
        let value: Exclusion?
        init(from d: Decoder) throws { value = try? Exclusion(from: d) }
    }
    private struct LooseOption: Decodable {
        let value: ClarifyOption?
        init(from d: Decoder) throws {
            guard let o = try? ClarifyOption(from: d), !o.value.isEmpty, !o.label.isEmpty else { value = nil; return }
            value = o
        }
    }

    /// 是否需要在曲库外找歌
    var needsSearch: Bool { intent == "specify_song" || intent == "soundtrack" }
    /// 明确的歌名（不是影视作品）→ 去 Apple Music 搜
    var isSongSearch: Bool { intent == "specify_song" && entities.song != nil && entities.workTitle == nil }
}

/// 首页的场景快捷按钮
struct SceneChip: Equatable, Identifiable {
    let id: String
    let label: String
    var current: String? = nil

    static let all: [SceneChip] = [
        SceneChip(id: "通勤", label: "下班通勤"), SceneChip(id: "睡前", label: "睡前"), SceneChip(id: "学习", label: "工作学习"),
        SceneChip(id: "运动", label: "运动"), SceneChip(id: "难过", label: "有点难过", current: "难过"),
        SceneChip(id: "放松", label: "放松一下"), SceneChip(id: "开心", label: "心情很好", current: "开心"),
        SceneChip(id: "开车", label: "开车兜风"), SceneChip(id: "发呆", label: "发呆放空"), SceneChip(id: "随便", label: "随便听听"),
    ]
}

struct TargetSpec {
    let moods: [String]
    let e: Double?
    let v: Double?
}

enum Targets {
    static let all: [String: TargetSpec] = [
        "放松": TargetSpec(moods: ["放松", "治愈", "平静"], e: 2, v: 3.6),
        "振奋": TargetSpec(moods: ["振奋", "快乐", "热血"], e: 4, v: 4.5),
        "平静": TargetSpec(moods: ["平静", "治愈", "梦幻"], e: 1.3, v: 3.2),
        "专注": TargetSpec(moods: ["专注", "平静", "梦幻"], e: 2, v: 3.2),
        "宣泄": TargetSpec(moods: ["伤感", "孤独", "怀旧"], e: 2, v: 2),
        "浪漫": TargetSpec(moods: ["浪漫", "梦幻", "快乐"], e: 2.5, v: 4),
        "热血": TargetSpec(moods: ["热血", "振奋"], e: 4.8, v: 4),
        "治愈": TargetSpec(moods: ["治愈", "放松", "快乐"], e: 2.3, v: 4),
        "开心": TargetSpec(moods: ["快乐", "振奋", "浪漫"], e: 3.6, v: 4.8),
        "怀旧": TargetSpec(moods: ["怀旧", "平静"], e: 2, v: 3),
        "随心": TargetSpec(moods: [], e: nil, v: nil),
    ]
    static func spec(_ t: String) -> TargetSpec { all[t] ?? all["随心"]! }

    static let phrase: [String: String] = [
        "放松": "帮你慢慢松下来", "振奋": "给你提提神", "平静": "让心静下来", "专注": "陪你专心做事", "宣泄": "陪你把情绪放出来",
        "浪漫": "刚好有一点甜", "热血": "把能量拉满", "治愈": "温柔但不往下沉", "开心": "让好心情继续", "怀旧": "带一点回忆的味道", "随心": "贴合你的口味",
    ]
}

// MARK: - 正则小工具

final class RX {
    let re: NSRegularExpression
    init(_ pattern: String, ci: Bool = false) {
        re = try! NSRegularExpression(pattern: pattern, options: ci ? [.caseInsensitive] : [])
    }
    func test(_ s: String) -> Bool {
        re.firstMatch(in: s, range: NSRange(s.startIndex..., in: s)) != nil
    }
    /// 所有匹配，每个匹配返回 [整体, 分组1, 分组2…]
    func all(_ s: String) -> [[String]] {
        re.matches(in: s, range: NSRange(s.startIndex..., in: s)).map { m in
            (0..<m.numberOfRanges).map { i in
                guard let r = Range(m.range(at: i), in: s) else { return "" }
                return String(s[r])
            }
        }
    }
}

extension String {
    /// 只替换第一次出现（等同 JS 的 String.replace(字符串, …)）
    func replacingFirst(_ target: String, with rep: String) -> String {
        guard !target.isEmpty, let r = range(of: target) else { return self }
        return replacingCharacters(in: r, with: rep)
    }
}

/// 歌曲是否命中某个"避开项"
struct ExclusionRule {
    let re: RX
    let label: String
    let test: (Song) -> Bool
}

// MARK: - 本地需求理解（离线兜底，规则与网页版一致）

enum NeedParser {
    static let exclusions: [ExclusionRule] = [
        ExclusionRule(re: RX("丧|伤感|悲|难过|苦情|emo|哭|沉重|压抑", ci: true), label: "太伤感的歌") { $0.moods.contains("伤感") || $0.valence <= 1 },
        ExclusionRule(re: RX("吵|闹|燃|嗨|激烈|重金属|躁"), label: "太吵太燃的歌") { $0.energy >= 5 || ($0.energy >= 4 && $0.genre == "摇滚") },
        ExclusionRule(re: RX("摇滚"), label: "摇滚") { $0.genre == "摇滚" },
        ExclusionRule(re: RX("说唱|rap|嘻哈", ci: true), label: "说唱") { $0.genre == "嘻哈" },
        ExclusionRule(re: RX("电子|edm", ci: true), label: "电子") { $0.genre == "电子" },
        ExclusionRule(re: RX("慢|催眠|无聊|太安静|太软"), label: "太慢太软的歌") { $0.energy <= 1 },
        ExclusionRule(re: RX("情歌|恋爱|甜|腻"), label: "情歌") { $0.moods.contains("浪漫") },
        ExclusionRule(re: RX("老歌|怀旧"), label: "怀旧老歌") { $0.moods.contains("怀旧") },
    ]

    private static let neg = RX("(不要太|别太|不想太|不要|别|不想听|不想|不太想|拒绝|讨厌)([^，。,.!！？?；;、\\s]{0,6})")
    private static let want = RX("(想要|想|希望|让我|需要|来点|来些|听点|变得|帮我)([^，。,.!！？?]{0,10})")

    private static let cur: [(RX, String)] = [
        (RX("累|疲惫|疲倦|困|没精神|乏|心累|好忙"), "疲惫"),
        (RX("难过|伤心|丧|低落|emo|失恋|想哭|委屈|不开心|郁闷|分手", ci: true), "难过"),
        (RX("焦虑|压力|烦|紧张|慌|崩溃|心乱"), "焦虑"),
        (RX("开心|高兴|快乐|兴奋|心情(很|超|特别)?好|爽|升职|放假"), "开心"),
        (RX("无聊|没劲"), "无聊"),
        (RX("孤独|寂寞|一个人|想家"), "孤独"),
        (RX("生气|愤怒|火大|气死"), "生气"),
        (RX("平静|还行|一般"), "平静"),
    ]
    private static let tgt: [(RX, String)] = [
        (RX("放松|舒服|轻松|松弛|缓一缓|歇"), "放松"),
        (RX("振作|打起精神|元气|提神|开心|快乐|有劲|充电"), "振奋"),
        (RX("安静|静一静|平静|睡|助眠|冷静"), "平静"),
        (RX("专注|集中|效率|认真"), "专注"),
        (RX("哭|发泄|宣泄|沉浸|陪我难过"), "宣泄"),
        (RX("浪漫|甜|恋爱|心动"), "浪漫"),
        (RX("燃|热血|嗨|炸|爆发|动感"), "热血"),
        (RX("治愈|温暖|温柔|安慰"), "治愈"),
        (RX("怀旧|回忆|老歌"), "怀旧"),
    ]
    private static let scn: [(RX, String)] = [
        (RX("下班|通勤|地铁|公交|上班路|回家路|路上"), "通勤"),
        (RX("睡前|睡觉|睡不着|失眠|晚安|躺床|入睡"), "睡前"),
        (RX("学习|工作|写作业|看书|写代码|加班|复习|办公|报告|考试"), "学习"),
        (RX("运动|跑步|健身|锻炼|撸铁|骑车|瑜伽"), "运动"),
        (RX("开车|自驾|兜风|驾驶|高速"), "开车"),
        (RX("发呆|放空|咖啡|窗边|下雨"), "发呆"),
        (RX("洗澡|做饭|家务|周末|躺平"), "放松"),
    ]
    private static let genAlias: [(RX, String)] = [
        (RX("流行|pop", ci: true), "流行"), (RX("r&b|rnb|节奏布鲁斯", ci: true), "R&B"), (RX("民谣"), "民谣"),
        (RX("摇滚|rock", ci: true), "摇滚"), (RX("电子|edm|电音", ci: true), "电子"), (RX("爵士|jazz", ci: true), "爵士"),
        (RX("lo-?fi", ci: true), "Lo-fi"), (RX("钢琴|纯音乐|轻音乐|古典|器乐"), "纯音乐"),
        (RX("说唱|嘻哈|rap|hip-?hop", ci: true), "嘻哈"), (RX("国风|古风|中国风"), "国风"),
    ]
    static let curDefault = ["疲惫": "放松", "焦虑": "平静", "开心": "开心", "无聊": "振奋", "孤独": "治愈", "生气": "热血", "平静": "放松"]
    static let sceneDefault = ["通勤": "治愈", "睡前": "平静", "学习": "专注", "运动": "热血", "开车": "开心", "发呆": "放松", "放松": "放松", "难过": "治愈", "开心": "开心"]

    static func timeSlot(_ d: Date = Date()) -> String {
        let h = Calendar.current.component(.hour, from: d)
        return h < 5 ? "深夜" : h < 9 ? "早晨" : h < 12 ? "上午" : h < 14 ? "中午" : h < 18 ? "下午" : h < 23 ? "晚上" : "深夜"
    }

    private static func first(_ list: [(RX, String)], _ txt: String) -> String? {
        for (re, v) in list where re.test(txt) { return v }
        return nil
    }

    static func understand(_ text: String, chip: SceneChip?, now: Date = Date()) -> Need {
        let raw = text.trimmingCharacters(in: .whitespacesAndNewlines)
        var rest = raw
        var exclude: [String] = []
        for m in neg.all(raw) {
            for x in exclusions where x.re.test(m[2]) && !exclude.contains(x.label) { exclude.append(x.label) }
            rest = rest.replacingFirst(m[0], with: " ")
        }
        var target: String? = nil
        for m in want.all(rest) {
            if let t = first(tgt, m[2]), target == nil { target = t }
            rest = rest.replacingFirst(m[0], with: " ")
        }
        if target == nil { target = first(tgt.filter { !["振奋", "宣泄", "平静"].contains($0.1) }, rest) }
        var current = first(cur, rest) ?? chip?.current
        let scene = first(scn, raw) ?? ((chip != nil && chip!.id != "随便") ? chip!.id : nil)
        if scene == "难过" || scene == "开心" { current = current ?? scene }
        let genres = genAlias.filter { $0.0.test(rest) }.map { $0.1 }
        if target == nil && current == "难过" { target = RX("哭|发泄|陪我|沉浸").test(raw) ? "宣泄" : "治愈" }
        if target == nil, let c = current { target = curDefault[c] }
        if target == nil, let s = scene { target = sceneDefault[s] }
        let tg = target ?? "随心"
        let time = timeSlot(now)
        var energy = Targets.spec(tg).e
        if energy == nil && current == "疲惫" { energy = 2 }
        if var e = energy {
            if RX("轻|慢|安静|柔|小声").test(rest) { e -= 0.8 }
            if RX("快|动感|带劲|节奏感|大声").test(rest) { e += 1 }
            if time == "深夜" { e -= 0.6 }
            energy = (min(5, max(1, e)) * 10).rounded() / 10
        }
        var need = Need(text: raw, chip: chip?.label, current: current, target: tg, scene: scene, energy: energy,
                        time: time, exclude: exclude, genres: genres)
        // 2.0：离线时同样识别"找指定歌曲 / 影视作品"和模糊需求
        let (intent, entities, artistPref) = intentOf(raw)
        need.intent = intent
        need.entities = entities
        need.artistPreference = artistPref
        if intent == "recommend" && artistPref == nil && entities.artist == nil && current == nil && scene == nil
            && genres.isEmpty && tg == "随心" && !deferRe.test(raw) && vagueRe.test(raw) {
            need.needsClarification = true
            need.clarificationDimension = "target"
            need.clarificationQuestion = "你现在更想听哪种感觉？"
            need.clarificationOptions = [ClarifyOption(value: "放松", label: "放松一下"), ClarifyOption(value: "开心", label: "提升心情"),
                                         ClarifyOption(value: "振奋", label: "来点活力"), ClarifyOption(value: "随心", label: "随便听听")]
        }
        return need
    }

    // MARK: 找歌意图（与网页 2.0 / 后端 rules.py 同一套规则）

    private static let deferRe = RX("随便|都行|都听|无所谓|你说了算|听你的|看你|随你")
    private static let vagueRe = RX("^(?:(?:帮我|给我|我想|我要|想|要|听|放|来|推荐|点|一些|一点|几首|几支|几|些|首|支|个|歌儿|歌曲|音乐|曲子|歌|我|你|一|吧|呀|啊|呗|了|的|下))+[\\s，。,.!！?；;、]*$")
    private static let name = "[\\u4e00-\\u9fa5A-Za-z·]{2,10}"
    private static let verb = "我想听|我想播放|我想放|想听|我要听|要听|播放|放一下|放一首|放首|放|点一首|点首|点歌|来一首|来首|来一曲|来一段|搜一下|搜索|搜|找一下|查找|找"
    private static let tailChars = "[^\\s，。,.!！？?；;、]"
    private static let rejectSub = ["的歌", "歌曲", "歌儿", "首歌", "音乐", "主题曲", "主题歌", "片头", "片尾", "插曲", "配乐", "原声", "ost", "bgm", "一点", "一些", "好听", "什么", "怎么", "推荐", "都行", "随便", "列表", "歌单", "下一首", "上一首", "暂停", "继续", "播放器"]
    private static let rejectExact: Set<String> = ["歌", "歌曲", "音乐", "的歌", "歌儿", "首歌", "点", "些", "首", "一曲", "一段", "个", "的", "点歌", "听歌", "歌听", "什么的"]
    private static let wordy: [String] = Vocab.moods + Array(Targets.all.keys) + ["舒缓", "舒服", "温柔", "温暖", "安静", "好听", "轻松"]
        + Vocab.genres + ["通勤", "睡前", "学习", "运动", "开车", "发呆", "放松", "难过", "开心"]
    private static let hasWordChar = RX("[\\u4e00-\\u9fa5A-Za-z0-9]")
    private static let edgePunct = CharacterSet(charactersIn: "，。,.!！？?；;、·…~〜-—_/\\|'\"“”‘’()（）[]【】<>《》")

    private static func cleanSong(_ v: String) -> String? {
        let c = v.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: edgePunct)
        guard !c.isEmpty, c.count <= 20 else { return nil }
        let low = c.lowercased()
        if rejectExact.contains(c) || rejectExact.contains(low) || c.hasSuffix("的") { return nil }
        if rejectSub.contains(where: { low.contains($0) }) { return nil }
        if wordy.contains(where: { c.contains($0) || low.contains($0.lowercased()) }) { return nil }
        return hasWordChar.test(c) ? c : nil
    }

    private static func cleanArtist(_ v: String) -> String? {
        let c = v.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !c.isEmpty, c.count <= 10, !c.hasSuffix("的"), !rejectExact.contains(c) else { return nil }
        guard RX("^" + name + "$").test(c) else { return nil }
        return wordy.contains(where: { c.contains($0) }) ? nil : c
    }

    /// 有找歌动词但歌名没通过上面的保守过滤时，仍按"找歌"处理；返回 "" 表示"那首歌"这种指代
    private static func explicitSong(_ t: String) -> String? {
        guard let m = RX("(?:" + verb + ")\\s*((?:一首|首|一支|支|一曲|一段|一个|个|下)?)\\s*(?:一些|点)?\\s*(" + tailChars + "{1,20})").all(t).first else { return nil }
        let quant = m[1], tail = m[2]
        if quant.isEmpty, let mm = RX("^(" + name + ")的(?:歌|歌曲|歌儿)$").all(tail).first,
           !RX("^(?:这|那|哪|某|一|两|几|首|支|曲|段|个)").test(mm[1]) { return nil }
        var c = tail
        if let r = RX("^(?:这|那|哪|某)?(?:一|两|几)?(?:首|支|曲|段|个)?(?:首歌|歌曲|音乐|歌)?").all(c).first, !r[0].isEmpty { c = String(c.dropFirst(r[0].count)) }
        if let r = RX("(?:的歌|歌曲|歌儿)$").all(c).first, !r[0].isEmpty { c = String(c.dropLast(r[0].count)) }
        c = c.trimmingCharacters(in: .whitespacesAndNewlines)
        if c.isEmpty {
            return RX("^(?:这|那|哪|某|一|两|几)(?:首|支|曲|段)?(?:首歌|歌曲|歌)?$").test(tail.trimmingCharacters(in: .whitespacesAndNewlines)) ? "" : nil
        }
        if c.count > 20 || rejectExact.contains(c) { return nil }
        let low = c.lowercased()
        if rejectSub.contains(where: { low.contains($0) }) { return nil }
        if wordy.contains(where: { c.contains($0) }) { return nil }
        return hasWordChar.test(c) ? c : nil
    }

    static func intentOf(_ raw: String) -> (String, Entities, String?) {
        var e = Entities()
        var intent = "recommend"
        var artistPref: String? = nil
        let workCue = RX("主题曲|主题歌|片头曲|片头歌|片头|片尾曲|片尾歌|片尾|插曲|原声|配乐|ost|bgm|里面的歌|里的歌", ci: true).test(raw)
        if let bm = RX("《([^》]{1,40})》").all(raw).first {
            if workCue { intent = "soundtrack"; e.workTitle = bm[1] } else { intent = "specify_song"; e.song = bm[1] }
            return (intent, e, nil)
        }
        if let wm = RX("(?:" + verb + ")?\\s*(?:一部|部)?(" + name + ")的(主题曲|主题歌|片头曲|片头歌|片头|片尾曲|片尾歌|片尾|插曲|配乐|原声|ost|bgm)", ci: true).all(raw).first {
            e.workTitle = cleanArtist(wm[1]) ?? wm[1].trimmingCharacters(in: .whitespacesAndNewlines)
            return ("soundtrack", e, nil)
        }
        if let am = RX("(?:" + verb + ")?\\s*(?:一些)?(" + name + ")的(" + tailChars + "{1,20})").all(raw).first,
           let s = cleanSong(am[2]), let a = cleanArtist(am[1]) {
            intent = "specify_song"; e.song = s; e.artist = a
        }
        if e.song == nil, let vm = RX("(?:" + verb + ")\\s*(?:一首|首|一曲|一段|个|下)?\\s*(" + tailChars + "{1,20})").all(raw).first,
           let s = cleanSong(vm[1]) {
            intent = "specify_song"; e.song = s
        }
        if intent == "recommend" && e.artist == nil,
           let om = RX("(?:听|推荐|想听|来点|放)(?:一些)?(?!点|些)(" + name + ")的(?:歌|歌曲|歌儿)").all(raw).first {
            artistPref = cleanArtist(om[1])
        }
        if intent == "recommend", let es = explicitSong(raw) {
            intent = "specify_song"; e.song = es.isEmpty ? nil : es; artistPref = nil
        }
        return (intent, e, artistPref)
    }

    static func energyLabel(_ e: Double?) -> String {
        guard let e else { return "不限" }
        return e < 1.8 ? "低" : e < 2.6 ? "中低" : e < 3.4 ? "中" : e < 4.2 ? "中高" : "高"
    }
}
