import Foundation

// MARK: - 歌曲模型（与后端 /api/songs 字段一致）

struct SongSource: Codable, Hashable {
    /// synth = App 内合成的示意旋律；file = 授权音频文件（url 可以是 /audio/xxx.mp3 这样的相对地址）
    var provider: String
    var url: String? = nil
}

struct Song: Codable, Identifiable, Hashable {
    var id: String
    var title: String
    var artist: String
    var genre: String
    var moods: [String]
    var energy: Int
    var valence: Int
    var scenes: [String]
    var bpm: Int
    var pop: Int
    var dur: Int
    var sources: [SongSource]
    // 真实曲目的授权信息（CC BY 要求注明作者、授权和出处）
    var license: String? = nil
    var licenseUrl: String? = nil
    var link: String? = nil
    var site: String? = nil

    /// 是否是授权的真实音频（而不是合成旋律）
    var isRealAudio: Bool { sources.contains { $0.provider == "file" && $0.url != nil } }

    /// mm001 → 1，用于封面旋转角度和旋律种子
    var number: Int { Int(id.filter(\.isNumber)) ?? 1 }

    init(id: String, title: String, artist: String, genre: String, moods: [String], energy: Int, valence: Int,
         scenes: [String], bpm: Int, pop: Int, dur: Int = 45, sources: [SongSource] = [SongSource(provider: "synth")]) {
        self.id = id; self.title = title; self.artist = artist; self.genre = genre; self.moods = moods
        self.energy = energy; self.valence = valence; self.scenes = scenes; self.bpm = bpm; self.pop = pop
        self.dur = dur; self.sources = sources
    }

    private enum CodingKeys: String, CodingKey {
        case id, title, artist, genre, moods, energy, valence, scenes, bpm, pop, dur, sources, license, link, site
        case licenseUrl = "license_url"
    }

    // 宽松解码：数字字段可能是整数或小数，缺字段时用默认值（和网页版 useCatalog 一致）
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        func num(_ k: CodingKeys, _ def: Int) -> Int {
            if let v = try? c.decode(Int.self, forKey: k) { return v }
            if let v = try? c.decode(Double.self, forKey: k) { return Int(v.rounded()) }
            if let s = try? c.decode(String.self, forKey: k), let v = Double(s) { return Int(v.rounded()) }
            return def
        }
        id = try c.decode(String.self, forKey: .id)
        title = try c.decode(String.self, forKey: .title)
        artist = try c.decode(String.self, forKey: .artist)
        genre = try c.decode(String.self, forKey: .genre)
        moods = (try? c.decode([String].self, forKey: .moods)) ?? []
        scenes = (try? c.decode([String].self, forKey: .scenes)) ?? []
        energy = num(.energy, 3)
        valence = num(.valence, 3)
        bpm = num(.bpm, 90)
        pop = num(.pop, 1)
        let d = num(.dur, 45)
        dur = d > 0 ? d : 45
        let src = (try? c.decode([SongSource].self, forKey: .sources)) ?? []
        sources = src.isEmpty ? [SongSource(provider: "synth")] : src
        license = try? c.decode(String.self, forKey: .license)
        licenseUrl = try? c.decode(String.self, forKey: .licenseUrl)
        link = try? c.decode(String.self, forKey: .link)
        site = try? c.decode(String.self, forKey: .site)
    }
}

// MARK: - 枚举字典（接口文档 §5）

enum Vocab {
    static let genres = ["流行", "R&B", "民谣", "摇滚", "电子", "爵士", "Lo-fi", "纯音乐", "嘻哈", "国风"]
    static let moods = ["治愈", "放松", "快乐", "伤感", "平静", "热血", "浪漫", "怀旧", "专注", "梦幻", "振奋", "孤独"]
    static let slots = ["稳妥", "探索", "惊喜"]
}

// MARK: - 曲库

struct Catalog {
    let songs: [Song]
    let byId: [String: Song]
    let artists: [String]

    init(_ songs: [Song]) {
        self.songs = songs
        var map: [String: Song] = [:]
        for s in songs { map[s.id] = s }
        byId = map
        var seen = Set<String>(), list: [String] = []
        for s in songs where !seen.contains(s.artist) { seen.insert(s.artist); list.append(s.artist) }
        artists = list
    }

    /// 歌手最常出现的曲风
    func artistGenre(_ artist: String) -> String {
        var count: [String: Int] = [:], order: [String] = []
        for s in songs where s.artist == artist {
            if count[s.genre] == nil { order.append(s.genre) }
            count[s.genre, default: 0] += 1
        }
        var best = order.first ?? ""
        for g in order where count[g]! > count[best]! { best = g }
        return best
    }

    /// 服务器曲库校验：至少 5 首合法歌曲才替换内置曲库
    static func validated(_ list: [Song]) -> Catalog? {
        let good = list.filter { !$0.id.isEmpty && !$0.title.isEmpty && !$0.artist.isEmpty && Vocab.genres.contains($0.genre) }
        return good.count >= 5 ? Catalog(good) : nil
    }

    static let onboardSongs = ["am001", "am006", "am011", "am016", "am021", "am026", "am031", "am036", "am044", "am046", "am008", "am024"]

    /// 内置曲库：约 500 首 Apple Music 上的真实歌曲（标签是人工估的，模型 B 打好标签后会覆盖）。字段：歌名|歌手|曲风|情绪|能量|效价|场景|BPM|热度
    /// 播放时按"歌名 + 歌手"在 Apple Music 里查找；dur 只用于找不到时的示意旋律长度
    static let builtIn: Catalog = {
        let songs = raw.split(separator: "\n").enumerated().map { i, line -> Song in
            let f = line.split(separator: "|", omittingEmptySubsequences: false).map(String.init)
            return Song(id: String(format: "am%03d", i + 1), title: f[0], artist: f[1], genre: f[2],
                        moods: f[3].split(separator: ",").map(String.init), energy: Int(f[4])!, valence: Int(f[5])!,
                        scenes: f[6].split(separator: ",").map(String.init), bpm: Int(f[7])!, pop: Int(f[8])!)
        }
        return Catalog(songs)
    }()

    private static let raw = """
晴天|周杰伦|流行|怀旧,浪漫|3|3|通勤,发呆,开车|138|5
小幸运|田馥甄|流行|治愈,浪漫|2|4|通勤,放松,开心|80|5
光年之外|邓紫棋|流行|振奋,梦幻|4|3|开车,运动|84|5
后来|刘若英|流行|伤感,怀旧|2|2|难过,睡前|74|5
Shape of You|Ed Sheeran|流行|快乐,振奋|4|5|运动,开心,通勤|96|5
Leave The Door Open|Bruno Mars|R&B|浪漫,放松|2|4|放松,开车,开心|74|4
Best Part|Daniel Caesar|R&B|浪漫,平静|1|4|睡前,放松|75|4
红豆|方大同|R&B|浪漫,治愈|2|4|放松,睡前,通勤|80|4
爱很简单|陶喆|R&B|浪漫,快乐|2|4|开心,开车|72|4
Redbone|Childish Gambino|R&B|梦幻,孤独|2|3|发呆,开车|80|3
成都|赵雷|民谣|怀旧,伤感|2|2|发呆,难过,开车|78|5
南山南|马頔|民谣|孤独,伤感|2|2|难过,睡前|72|4
理想三旬|陈鸿宇|民谣|怀旧,平静|2|3|发呆,通勤|84|4
斑马，斑马|宋冬野|民谣|孤独,怀旧|2|2|睡前,难过|70|4
去大理|郝云|民谣|放松,快乐|3|4|开车,开心,通勤|96|3
夜空中最亮的星|逃跑计划|摇滚|振奋,治愈|4|4|通勤,开车,难过|124|5
倔强|五月天|摇滚|热血,振奋|4|4|运动,难过|132|5
蓝莲花|许巍|摇滚|振奋,怀旧|4|4|开车,通勤|128|4
Don't Stop Me Now|Queen|摇滚|快乐,热血|5|5|运动,开心,开车|156|4
Yellow|Coldplay|摇滚|浪漫,梦幻|3|3|开车,发呆|88|4
Faded|Alan Walker|电子|梦幻,孤独|4|2|运动,开车,学习|90|5
Wake Me Up|Avicii|电子|振奋,快乐|5|4|运动,开车,开心|124|4
Something Just Like This|The Chainsmokers|电子|快乐,梦幻|4|4|开车,通勤|103|4
Midnight City|M83|电子|梦幻,振奋|4|4|开车,运动|105|3
Get Lucky|Daft Punk|电子|快乐,放松|3|5|开心,通勤|116|4
Fly Me To The Moon|Frank Sinatra|爵士|浪漫,快乐|3|5|开心,放松|120|4
Take Five|The Dave Brubeck Quartet|爵士|平静,专注|2|3|学习,发呆|172|3
What A Wonderful World|Louis Armstrong|爵士|治愈,平静|1|5|睡前,放松|72|4
Don't Know Why|Norah Jones|爵士|放松,浪漫|2|3|放松,睡前,发呆|88|4
So What|Miles Davis|爵士|平静,专注|2|3|学习,发呆|136|2
Feather|Nujabes|Lo-fi|治愈,怀旧|2|4|学习,通勤|88|3
Aruarian Dance|Nujabes|Lo-fi|平静,专注|2|3|学习,发呆|90|3
Affection|Jinsang|Lo-fi|治愈,放松|1|4|学习,睡前|82|2
Snowman|WYS|Lo-fi|平静,孤独|1|3|学习,睡前,难过|75|2
Sunset Lover|Petit Biscuit|Lo-fi|梦幻,放松|2|4|放松,开车,学习|90|3
River Flows In You|Yiruma|纯音乐|浪漫,平静|1|4|睡前,学习|65|5
Kiss The Rain|Yiruma|纯音乐|伤感,治愈|1|3|难过,睡前|58|4
Summer|久石让|纯音乐|快乐,怀旧|3|5|开心,学习,通勤|120|4
Comptine d'un autre été|Yann Tiersen|纯音乐|怀旧,孤独|2|3|发呆,难过|100|3
Nuvole Bianche|Ludovico Einaudi|纯音乐|平静,伤感|1|3|睡前,学习,难过|70|4
Lose Yourself|Eminem|嘻哈|热血,振奋|5|3|运动|171|5
野狼disco|宝石Gem|嘻哈|快乐,怀旧|4|5|开心,开车|116|4
HUMBLE.|Kendrick Lamar|嘻哈|热血,振奋|4|3|运动,开车|150|4
Sunflower|Post Malone|嘻哈|快乐,放松|3|5|开心,通勤,开车|90|5
Old Town Road|Lil Nas X|嘻哈|快乐,振奋|3|5|开心,开车|136|4
青花瓷|周杰伦|国风|怀旧,浪漫|2|3|发呆,睡前|70|5
生僻字|陈柯宇|国风|快乐,振奋|3|5|开心,通勤|96|4
牵丝戏|银临|国风|伤感,梦幻|2|2|难过,睡前|76|3
赤伶|HITA|国风|伤感,怀旧|3|2|难过,发呆|80|3
卷珠帘|霍尊|国风|平静,怀旧|1|3|睡前,学习,放松|66|3
稻香|周杰伦|流行|治愈,怀旧|3|4|开心,开车,通勤|82|5
七里香|周杰伦|流行|浪漫,怀旧|3|4|开车,通勤,发呆|90|5
告白气球|周杰伦|流行|浪漫,快乐|3|5|开心,通勤|92|5
简单爱|周杰伦|流行|快乐,浪漫|3|5|开车,开心|100|5
夜曲|周杰伦|流行|伤感,孤独|3|2|难过,发呆|86|5
匆匆那年|王菲|流行|怀旧,伤感|2|2|难过,睡前|72|5
红豆|王菲|流行|浪漫,伤感|1|3|睡前,发呆|68|5
传奇|王菲|流行|平静,浪漫|1|3|睡前,放松|66|4
因为爱情|王菲|流行|浪漫,怀旧|2|3|放松,睡前|72|4
十年|陈奕迅|流行|伤感,怀旧|2|2|难过,发呆|70|5
好久不见|陈奕迅|流行|孤独,伤感|2|2|难过,睡前|68|5
孤勇者|陈奕迅|流行|热血,振奋|4|3|运动,通勤|80|5
富士山下|陈奕迅|流行|伤感,平静|2|2|难过,睡前|76|4
稳稳的幸福|陈奕迅|流行|治愈,浪漫|2|4|放松,开心|78|4
泡沫|邓紫棋|流行|伤感,孤独|3|2|难过|76|5
句号|邓紫棋|流行|伤感|3|2|难过,发呆|74|4
倒数|邓紫棋|流行|浪漫,伤感|3|3|通勤,开车|82|4
演员|薛之谦|流行|伤感,孤独|2|2|难过,睡前|70|5
丑八怪|薛之谦|流行|伤感|2|2|难过|72|4
认真的雪|薛之谦|流行|伤感,孤独|2|2|难过,发呆|68|4
江南|林俊杰|流行|浪漫,怀旧|3|3|开车,通勤|92|5
修炼爱情|林俊杰|流行|伤感,孤独|2|2|难过,睡前|70|5
不为谁而作的歌|林俊杰|流行|孤独,平静|2|3|发呆,睡前|76|4
可惜没如果|林俊杰|流行|伤感,怀旧|2|2|难过|72|4
小酒窝|林俊杰|流行|浪漫,快乐|2|5|开心,放松|76|4
爱情转移|陈奕迅|流行|伤感,怀旧|2|2|难过,发呆|78|4
平凡之路|朴树|民谣|振奋,孤独|3|3|开车,通勤|98|5
那些花儿|朴树|民谣|怀旧,伤感|2|2|发呆,难过|74|4
New Boy|朴树|流行|快乐,振奋|4|5|开心,通勤|132|4
小情歌|苏打绿|流行|浪漫,治愈|2|4|放松,睡前|76|5
我好想你|苏打绿|流行|孤独,伤感|2|2|难过,睡前|80|3
Lemon|米津玄師|流行|伤感,怀旧|3|2|难过,通勤|87|5
打上花火|DAOKO|流行|梦幻,怀旧|3|3|发呆,开车|96|4
夜に駆ける|YOASOBI|流行|振奋,伤感|5|3|通勤,运动|130|5
アイドル|YOASOBI|流行|热血,振奋|5|4|运动,开心|166|4
Pretender|Official髭男dism|流行|伤感,浪漫|3|2|开车,难过|92|4
First Love|宇多田ヒカル|流行|浪漫,伤感|2|2|睡前,难过|80|4
Blinding Lights|The Weeknd|流行|振奋,梦幻|5|3|开车,运动|171|5
Save Your Tears|The Weeknd|流行|伤感,振奋|4|3|开车,通勤|118|4
Levitating|Dua Lipa|流行|快乐,振奋|4|5|运动,开心|103|5
Don't Start Now|Dua Lipa|流行|振奋,快乐|4|4|运动,开心|124|4
As It Was|Harry Styles|流行|怀旧,快乐|4|4|通勤,开车|174|5
Watermelon Sugar|Harry Styles|流行|快乐,浪漫|3|5|开心,开车|95|4
Perfect|Ed Sheeran|流行|浪漫,治愈|2|4|放松,睡前|63|5
Thinking Out Loud|Ed Sheeran|流行|浪漫,平静|2|4|放松,睡前|79|5
Photograph|Ed Sheeran|流行|怀旧,浪漫|2|3|发呆,睡前|108|4
Someone Like You|Adele|流行|伤感,孤独|2|1|难过,睡前|68|5
Rolling in the Deep|Adele|流行|热血,伤感|4|2|难过,开车|105|5
Hello|Adele|流行|伤感,怀旧|3|2|难过|79|4
Shake It Off|Taylor Swift|流行|快乐,振奋|4|5|开心,运动|160|5
Love Story|Taylor Swift|流行|浪漫,快乐|3|5|开心,通勤|119|5
Blank Space|Taylor Swift|流行|快乐,振奋|3|4|开心,通勤|96|4
Anti-Hero|Taylor Swift|流行|孤独,怀旧|3|3|通勤,发呆|97|4
Cruel Summer|Taylor Swift|流行|振奋,浪漫|4|4|开车,开心|170|4
Bad Guy|Billie Eilish|流行|梦幻,孤独|3|3|发呆,通勤|135|5
Ocean Eyes|Billie Eilish|流行|梦幻,浪漫|1|3|睡前,发呆|145|4
Happier Than Ever|Billie Eilish|流行|伤感,热血|3|2|难过|81|4
drivers license|Olivia Rodrigo|流行|伤感,孤独|2|1|难过,开车|144|4
good 4 u|Olivia Rodrigo|流行|热血,振奋|5|3|运动,开车|167|4
Stay|The Kid LAROI|流行|振奋,伤感|4|3|开车,运动|170|4
Flowers|Miley Cyrus|流行|振奋,治愈|3|4|开心,通勤|118|5
Counting Stars|OneRepublic|流行|振奋,快乐|4|4|开车,通勤|122|5
Viva La Vida|Coldplay|摇滚|振奋,热血|4|4|开车,运动|138|5
Fix You|Coldplay|摇滚|治愈,伤感|2|3|难过,睡前|69|5
The Scientist|Coldplay|摇滚|伤感,怀旧|2|2|难过,发呆|73|4
Clocks|Coldplay|摇滚|梦幻,专注|3|3|学习,开车|131|4
A Sky Full of Stars|Coldplay|电子|快乐,梦幻|4|5|开心,开车|125|4
Uptown Funk|Mark Ronson|流行|快乐,振奋|5|5|运动,开心|115|5
Happy|Pharrell Williams|流行|快乐|4|5|开心,通勤|160|5
Can't Stop the Feeling!|Justin Timberlake|流行|快乐,振奋|4|5|开心,运动|113|4
Peaches|Justin Bieber|R&B|放松,浪漫|2|4|开车,放松|90|4
Love Yourself|Justin Bieber|流行|放松,孤独|2|3|发呆,通勤|100|4
Sorry|Justin Bieber|流行|快乐,振奋|4|4|开心,运动|100|4
See You Again|Wiz Khalifa|嘻哈|怀旧,伤感|3|2|难过,开车|80|5
Let Her Go|Passenger|民谣|伤感,怀旧|2|2|难过,发呆|75|5
Riptide|Vance Joy|民谣|快乐,浪漫|3|4|开心,开车|102|4
Ho Hey|The Lumineers|民谣|快乐,振奋|3|5|开心,开车|80|4
Budapest|George Ezra|民谣|快乐,放松|3|5|开心,通勤|128|4
Skinny Love|Bon Iver|民谣|孤独,伤感|1|2|难过,睡前|76|3
Holocene|Bon Iver|民谣|平静,孤独|1|3|睡前,发呆|74|3
Fast Car|Tracy Chapman|民谣|怀旧,孤独|2|3|开车,发呆|104|4
The Sound of Silence|Simon & Garfunkel|民谣|孤独,平静|1|2|睡前,发呆|106|4
Scarborough Fair|Simon & Garfunkel|民谣|怀旧,梦幻|1|3|睡前,发呆|94|4
Blowin' in the Wind|Bob Dylan|民谣|平静,怀旧|1|3|发呆,开车|88|4
Hallelujah|Jeff Buckley|民谣|伤感,平静|1|2|难过,睡前|60|4
Banana Pancakes|Jack Johnson|民谣|放松,快乐|2|5|放松,开心|90|4
Better Together|Jack Johnson|民谣|浪漫,放松|2|5|放松,开心|80|3
Rivers and Roads|The Head and the Heart|民谣|怀旧,伤感|2|3|开车,发呆|80|3
Big Yellow Taxi|Joni Mitchell|民谣|快乐,怀旧|3|4|开心,开车|88|3
董小姐|宋冬野|民谣|孤独,怀旧|2|2|发呆,难过|74|4
安和桥|宋冬野|民谣|怀旧,孤独|2|2|发呆,睡前|72|4
消愁|毛不易|民谣|伤感,孤独|2|2|难过,睡前|64|5
像我这样的人|毛不易|民谣|孤独,伤感|2|2|难过,发呆|68|4
借|毛不易|民谣|伤感,平静|2|2|睡前,难过|70|4
春风十里|鹿先森乐队|民谣|浪漫,治愈|2|4|放松,开车|80|4
画|赵雷|民谣|治愈,平静|2|3|睡前,放松|76|4
少年锦时|赵雷|民谣|怀旧,快乐|3|4|开车,通勤|90|3
南方姑娘|赵雷|民谣|怀旧,孤独|2|3|发呆,开车|80|4
白桦林|朴树|民谣|伤感,怀旧|2|2|难过,睡前|70|4
一生所爱|卢冠廷|流行|伤感,怀旧|2|2|难过,睡前|70|4
送别|朴树|民谣|伤感,怀旧|1|2|难过,睡前|66|4
外面的世界|齐秦|民谣|孤独,怀旧|2|2|发呆,开车|74|4
同桌的你|老狼|民谣|怀旧,治愈|2|3|发呆,通勤|80|4
恋恋风尘|老狼|民谣|怀旧,平静|2|3|发呆,睡前|76|3
旅行|许巍|民谣|放松,治愈|3|4|开车,放松|96|3
曾经的你|许巍|摇滚|振奋,怀旧|4|4|开车,通勤|132|5
故乡|许巍|摇滚|怀旧,孤独|3|3|开车,发呆|90|4
花房姑娘|崔健|摇滚|浪漫,怀旧|3|3|开车,发呆|90|4
一无所有|崔健|摇滚|热血,孤独|4|2|开车,难过|124|4
海阔天空|Beyond|摇滚|热血,振奋|4|4|开车,难过,运动|76|5
光辉岁月|Beyond|摇滚|振奋,怀旧|3|4|开车,通勤|80|5
真的爱你|Beyond|摇滚|治愈,怀旧|3|4|开心,开车|82|5
喜欢你|Beyond|摇滚|浪漫,伤感|2|2|难过,发呆|72|4
突然好想你|五月天|摇滚|伤感,孤独|3|2|难过,开车|78|5
温柔|五月天|摇滚|浪漫,伤感|3|3|开车,发呆|86|5
知足|五月天|摇滚|治愈,伤感|2|3|难过,睡前|80|4
派对动物|五月天|摇滚|快乐,热血|5|5|运动,开心|140|4
星空|五月天|摇滚|梦幻,孤独|3|3|开车,发呆|84|3
私奔到月球|五月天|摇滚|浪漫,快乐|3|5|开心,开车|112|4
奔跑|羽泉|摇滚|热血,振奋|5|5|运动|130|4
追梦赤子心|GALA|摇滚|热血,振奋|5|4|运动,难过|140|4
骄傲的少年|南征北战|摇滚|热血,振奋|5|4|运动,开车|140|4
无地自容|黑豹乐队|摇滚|热血,孤独|4|3|开车,运动|128|4
Don't Break My Heart|黑豹乐队|摇滚|伤感,怀旧|3|2|难过,开车|78|4
易燃易爆炸|陈粒|民谣|热血,孤独|3|2|发呆,开车|90|3
奇妙能力歌|陈粒|民谣|梦幻,治愈|2|4|睡前,发呆|76|3
四季予你|程响|民谣|浪漫,治愈|2|4|放松,睡前|76|4
起风了|买辣椒也用券|流行|怀旧,振奋|3|3|通勤,开车|80|5
年少有为|李荣浩|流行|伤感,怀旧|2|2|难过,发呆|72|4
麻雀|李荣浩|流行|振奋,孤独|3|3|通勤,开车|82|4
李白|李荣浩|流行|快乐,放松|3|4|开心,通勤|96|4
Bohemian Rhapsody|Queen|摇滚|热血,梦幻|4|3|开车,发呆|72|5
We Will Rock You|Queen|摇滚|热血,振奋|5|4|运动|81|5
Hotel California|Eagles|摇滚|怀旧,梦幻|3|3|开车,发呆|75|5
Stairway to Heaven|Led Zeppelin|摇滚|梦幻,怀旧|3|3|开车,发呆|82|4
Smells Like Teen Spirit|Nirvana|摇滚|热血|5|2|运动,开车|117|5
Wonderwall|Oasis|摇滚|怀旧,浪漫|3|3|开车,通勤|87|5
Don't Look Back in Anger|Oasis|摇滚|振奋,怀旧|4|3|开车,通勤|82|4
Creep|Radiohead|摇滚|孤独,伤感|3|1|难过,发呆|92|5
Karma Police|Radiohead|摇滚|孤独,梦幻|3|2|发呆,难过|76|4
Mr. Brightside|The Killers|摇滚|热血,振奋|5|3|运动,开车|148|5
Sweet Child O' Mine|Guns N' Roses|摇滚|热血,快乐|5|4|开车,运动|125|5
Livin' on a Prayer|Bon Jovi|摇滚|热血,振奋|5|4|运动,开车|123|5
Highway to Hell|AC/DC|摇滚|热血|5|4|开车,运动|116|4
Eye of the Tiger|Survivor|摇滚|热血,振奋|5|4|运动|109|5
Numb|Linkin Park|摇滚|伤感,热血|4|2|难过,运动|110|5
In the End|Linkin Park|摇滚|伤感,热血|4|2|运动,难过|105|5
Believer|Imagine Dragons|摇滚|热血,振奋|5|3|运动|125|5
Radioactive|Imagine Dragons|摇滚|热血|5|2|运动,开车|137|4
Demons|Imagine Dragons|摇滚|伤感,振奋|3|2|难过,开车|90|4
Seven Nation Army|The White Stripes|摇滚|热血|4|3|运动,开车|124|4
Do I Wanna Know?|Arctic Monkeys|摇滚|梦幻,孤独|3|2|开车,发呆|85|5
505|Arctic Monkeys|摇滚|浪漫,伤感|3|2|开车,难过|140|4
Take Me Out|Franz Ferdinand|摇滚|振奋,快乐|5|4|运动,开心|105|3
Basket Case|Green Day|摇滚|热血,振奋|5|4|运动|170|4
Boulevard of Broken Dreams|Green Day|摇滚|孤独,伤感|4|2|开车,难过|84|4
Zombie|The Cranberries|摇滚|伤感,热血|4|2|难过,开车|84|4
Under the Bridge|Red Hot Chili Peppers|摇滚|孤独,怀旧|3|3|开车,发呆|84|4
Californication|Red Hot Chili Peppers|摇滚|梦幻,怀旧|3|3|开车,发呆|96|4
Africa|TOTO|摇滚|怀旧,快乐|3|4|开车,开心|93|5
Take On Me|a-ha|流行|快乐,振奋|5|5|开心,运动|169|5
Everybody Wants to Rule the World|Tears for Fears|流行|怀旧,梦幻|3|3|开车,通勤|112|4
Billie Jean|Michael Jackson|流行|振奋,梦幻|4|3|运动,开车|117|5
Beat It|Michael Jackson|流行|热血,振奋|5|4|运动|139|5
Dancing Queen|ABBA|流行|快乐,怀旧|4|5|开心,运动|101|5
Girls Just Want to Have Fun|Cyndi Lauper|流行|快乐|4|5|开心|120|4
September|Earth, Wind & Fire|R&B|快乐,怀旧|4|5|开心,运动|126|5
Superstition|Stevie Wonder|R&B|振奋,快乐|4|4|开心,开车|100|4
Isn't She Lovely|Stevie Wonder|R&B|快乐,治愈|3|5|开心,放松|119|4
Ain't No Mountain High Enough|Marvin Gaye|R&B|快乐,浪漫|4|5|开心,开车|130|4
What's Going On|Marvin Gaye|R&B|平静,怀旧|2|3|发呆,放松|102|4
Stand By Me|Ben E. King|R&B|浪漫,治愈|2|4|放松,开心|118|5
Lovely Day|Bill Withers|R&B|快乐,治愈|2|5|开心,放松,通勤|98|4
Ain't No Sunshine|Bill Withers|R&B|伤感,孤独|2|2|难过,发呆|79|4
Let's Stay Together|Al Green|R&B|浪漫,放松|2|4|放松,睡前|102|4
Crazy in Love|Beyoncé|R&B|振奋,热血|5|4|运动,开心|99|5
Halo|Beyoncé|R&B|浪漫,振奋|3|4|开心,放松|80|4
Adorn|Miguel|R&B|浪漫,放松|2|4|放松,开车|90|3
Thinkin Bout You|Frank Ocean|R&B|梦幻,孤独|2|3|睡前,发呆|65|4
Pink + White|Frank Ocean|R&B|梦幻,怀旧|2|4|开车,发呆|80|4
Kill Bill|SZA|R&B|伤感,梦幻|3|3|开车,发呆|89|5
Snooze|SZA|R&B|浪漫,放松|2|3|放松,睡前|72|4
Good Days|SZA|R&B|治愈,梦幻|2|3|放松,发呆|121|4
Earned It|The Weeknd|R&B|浪漫,梦幻|2|3|睡前,开车|60|4
Call Out My Name|The Weeknd|R&B|伤感,孤独|2|2|难过,睡前|67|4
Location|Khalid|R&B|浪漫,放松|2|3|开车,放松|80|4
Talk|Khalid|R&B|浪漫,梦幻|3|3|开车,通勤|136|4
Die For You|The Weeknd|R&B|浪漫,伤感|3|3|开车,睡前|67|4
Get You|Daniel Caesar|R&B|浪漫,平静|1|4|睡前,放松|69|4
Untitled (How Does It Feel)|D'Angelo|R&B|浪漫,梦幻|2|3|睡前|80|3
No One|Alicia Keys|R&B|浪漫,振奋|3|4|开心,开车|90|4
If I Ain't Got You|Alicia Keys|R&B|浪漫,治愈|2|4|放松,睡前|59|4
Say So|Doja Cat|R&B|快乐,浪漫|3|5|开心,通勤|111|4
Essence|Wizkid|R&B|放松,浪漫|2|4|放松,开车|104|3
普通朋友|陶喆|R&B|伤感,孤独|2|2|难过,开车|76|4
找自己|陶喆|R&B|振奋,快乐|3|4|开心,开车|96|3
特别的人|方大同|R&B|浪漫,治愈|2|4|放松,睡前|74|4
三人游|方大同|R&B|伤感,浪漫|2|3|开车,发呆|82|4
春风吹|方大同|R&B|快乐,放松|3|5|开心,开车|100|3
你不知道的事|王力宏|R&B|伤感,孤独|2|2|难过,睡前|68|4
一路向北|周杰伦|R&B|伤感,孤独|3|2|开车,难过|84|5
暗号|周杰伦|R&B|浪漫,梦幻|3|3|开车,通勤|90|4
龙卷风|周杰伦|R&B|伤感,浪漫|2|2|难过,发呆|72|4
说好不哭|周杰伦|流行|伤感,怀旧|2|2|难过,睡前|70|4
Mojito|周杰伦|流行|快乐,放松|3|5|开心,开车|96|4
是你|梦然|R&B|浪漫,治愈|2|4|放松,睡前|72|3
晚安|颜人中|R&B|浪漫,平静|1|3|睡前|70|3
Titanium|David Guetta|电子|振奋,热血|5|4|运动,开车|126|5
Levels|Avicii|电子|快乐,振奋|5|5|运动,开心|126|5
The Nights|Avicii|电子|振奋,怀旧|4|4|开车,运动|126|4
Waiting For Love|Avicii|电子|振奋,浪漫|4|4|开车,运动|128|4
Closer|The Chainsmokers|电子|浪漫,怀旧|3|3|开车,通勤|95|5
Don't Let Me Down|The Chainsmokers|电子|振奋,伤感|4|3|运动,开车|160|4
Animals|Martin Garrix|电子|热血|5|3|运动|128|4
Scared to Be Lonely|Martin Garrix|电子|孤独,伤感|3|2|开车,难过|138|4
Alone|Alan Walker|电子|振奋,孤独|4|3|运动,开车|97|4
Lean On|Major Lazer|电子|快乐,梦幻|4|4|开心,运动|98|5
Stay the Night|Zedd|电子|浪漫,振奋|4|4|开车,运动|128|4
Clarity|Zedd|电子|振奋,伤感|4|3|开车,运动|128|4
Summer|Calvin Harris|电子|快乐,振奋|4|5|开心,开车|128|4
This Is What You Came For|Calvin Harris|电子|振奋,梦幻|4|4|运动,开车|124|4
One More Time|Daft Punk|电子|快乐,振奋|5|5|开心,运动|123|5
Instant Crush|Daft Punk|电子|孤独,梦幻|3|3|开车,发呆|110|4
Around the World|Daft Punk|电子|快乐,专注|4|4|运动,学习|121|4
Strobe|deadmau5|电子|梦幻,专注|3|3|学习,开车|128|3
Opus|Eric Prydz|电子|梦幻,振奋|4|4|开车,运动|126|3
Language|Porter Robinson|电子|梦幻,振奋|4|4|开车,发呆|128|3
Shelter|Porter Robinson|电子|梦幻,怀旧|3|3|发呆,开车|100|3
Never Be Like You|Flume|电子|梦幻,伤感|3|3|开车,发呆|120|3
Innerbloom|RÜFÜS DU SOL|电子|梦幻,平静|3|3|开车,学习|122|3
Sweet Disposition|The Temper Trap|摇滚|梦幻,振奋|4|4|开车,通勤|126|4
Intro|The xx|电子|梦幻,专注|3|3|学习,开车|100|4
Breathe Me|Sia|流行|伤感,孤独|2|2|难过,睡前|70|4
Chandelier|Sia|流行|热血,伤感|4|2|难过,运动|117|5
Cheap Thrills|Sia|流行|快乐,振奋|4|5|开心,运动|90|4
Teardrop|Massive Attack|电子|梦幻,孤独|2|2|睡前,发呆|77|4
Porcelain|Moby|电子|梦幻,平静|2|3|发呆,睡前|96|3
Windowlicker|Aphex Twin|电子|梦幻,专注|3|3|学习|110|2
Kerala|Bonobo|电子|梦幻,专注|3|3|学习,开车|120|3
Cirrus|Bonobo|电子|平静,专注|3|4|学习,通勤|120|3
Kong|Bonobo|电子|梦幻,平静|2|3|学习,发呆|100|3
Sun Models|ODESZA|电子|梦幻,快乐|3|4|开车,通勤|100|3
A Moment Apart|ODESZA|电子|梦幻,振奋|3|4|开车,发呆|110|3
Say My Name|ODESZA|电子|快乐,梦幻|3|4|开心,开车|100|3
Faded|ZHU|电子|梦幻,孤独|3|3|开车,发呆|124|3
Cola|CamelPhat|电子|梦幻,专注|4|3|运动,开车|124|3
Gecko|Oliver Heldens|电子|快乐,振奋|5|5|运动|125|3
Pompeii|Bastille|流行|振奋,怀旧|4|3|开车,运动|128|4
Heat Waves|Glass Animals|流行|怀旧,梦幻|3|3|开车,发呆|81|5
Electric Feel|MGMT|电子|梦幻,快乐|3|4|开车,开心|103|4
Kids|MGMT|电子|梦幻,怀旧|4|4|开车,开心|123|4
Feel It Still|Portugal. The Man|摇滚|快乐,振奋|4|4|开心,通勤|79|4
Young Folks|Peter Bjorn and John|流行|快乐,放松|3|4|通勤,开心|117|3
Little Talks|Of Monsters and Men|民谣|振奋,快乐|4|4|开车,开心|103|4
Home|Edward Sharpe & The Magnetic Zeros|民谣|快乐,浪漫|3|5|开心,开车|116|3
Dog Days Are Over|Florence + The Machine|摇滚|振奋,快乐|4|4|开心,运动|150|4
Lovely|Billie Eilish|流行|伤感,孤独|2|1|难过,睡前|115|4
Autumn Leaves|Bill Evans|爵士|怀旧,平静|2|3|发呆,学习|120|3
Waltz for Debby|Bill Evans|爵士|平静,治愈|1|4|学习,睡前|90|3
Peace Piece|Bill Evans|爵士|平静,专注|1|3|学习,睡前|60|3
My Funny Valentine|Chet Baker|爵士|浪漫,孤独|1|3|睡前,发呆|60|3
Almost Blue|Chet Baker|爵士|孤独,伤感|1|2|睡前,难过|58|3
Blue in Green|Miles Davis|爵士|孤独,平静|1|2|发呆,睡前|60|3
Round Midnight|Thelonious Monk|爵士|孤独,平静|1|3|睡前,发呆|60|3
In a Sentimental Mood|Duke Ellington & John Coltrane|爵士|浪漫,平静|1|3|睡前,放松|65|3
Naima|John Coltrane|爵士|平静,浪漫|1|3|睡前,学习|66|3
My Favorite Things|John Coltrane|爵士|专注,梦幻|3|4|学习,发呆|180|3
Moanin'|Art Blakey & The Jazz Messengers|爵士|振奋,快乐|4|4|开车,开心|130|3
Cantaloupe Island|Herbie Hancock|爵士|放松,专注|3|4|学习,通勤|112|3
Watermelon Man|Herbie Hancock|爵士|快乐,放松|3|4|开心,通勤|120|3
Song for My Father|Horace Silver|爵士|放松,怀旧|3|4|学习,发呆|130|3
The Girl from Ipanema|Stan Getz & João Gilberto|爵士|放松,浪漫|2|4|放松,开车|130|4
Corcovado|Stan Getz & João Gilberto|爵士|浪漫,平静|1|4|睡前,放松|120|3
Mas Que Nada|Sérgio Mendes|爵士|快乐,振奋|4|5|开心,开车|112|3
Feeling Good|Nina Simone|爵士|振奋,热血|3|4|开心,开车|112|4
I Put a Spell on You|Nina Simone|爵士|浪漫,孤独|2|2|发呆,睡前|72|3
Summertime|Ella Fitzgerald & Louis Armstrong|爵士|放松,平静|1|4|放松,睡前|72|4
Dream a Little Dream of Me|Ella Fitzgerald & Louis Armstrong|爵士|浪漫,治愈|1|4|睡前,放松|76|3
Cheek to Cheek|Ella Fitzgerald & Louis Armstrong|爵士|浪漫,快乐|3|5|开心,放松|90|3
At Last|Etta James|爵士|浪漫,治愈|1|5|睡前,放松|90|4
Sway|Michael Bublé|爵士|浪漫,快乐|3|5|开心,放松|124|4
Feeling Good|Michael Bublé|爵士|振奋,快乐|3|4|开心,开车|110|4
L-O-V-E|Nat King Cole|爵士|快乐,浪漫|3|5|开心|130|4
Unforgettable|Nat King Cole|爵士|浪漫,怀旧|1|4|睡前,放松|80|4
La Vie en rose|Édith Piaf|爵士|浪漫,怀旧|1|4|睡前,发呆|80|4
Come Away With Me|Norah Jones|爵士|浪漫,平静|1|3|睡前,放松|78|4
Sunrise|Norah Jones|爵士|放松,治愈|2|4|放松,通勤|94|3
Misty|Erroll Garner|爵士|浪漫,平静|1|3|睡前,放松|70|3
Take the 'A' Train|Duke Ellington|爵士|快乐,振奋|4|5|通勤,开心|160|3
Sing, Sing, Sing|Benny Goodman|爵士|热血,快乐|5|5|运动,开心|220|3
Spain|Chick Corea|爵士|振奋,专注|4|4|学习,开车|150|3
Birdland|Weather Report|爵士|快乐,振奋|4|4|开车,通勤|150|3
Strasbourg St. Denis|Roy Hargrove|爵士|放松,快乐|3|4|通勤,开心|96|3
Kiss of Life|Sade|爵士|浪漫,放松|2|4|睡前,开车|98|4
Smooth Operator|Sade|爵士|梦幻,浪漫|2|3|开车,睡前|120|4
Valerie|Amy Winehouse|爵士|快乐,振奋|4|4|开心,通勤|106|4
Back to Black|Amy Winehouse|爵士|伤感,孤独|3|2|难过|123|4
夜来香|邓丽君|爵士|浪漫,怀旧|1|4|睡前,发呆|86|4
月亮代表我的心|邓丽君|流行|浪漫,怀旧|1|4|睡前,放松|70|5
甜蜜蜜|邓丽君|流行|浪漫,快乐|2|5|开心,放松|80|5
Coffee|beabadoobee|Lo-fi|浪漫,放松|1|4|放松,睡前|90|3
Luv(sic.) pt3|Nujabes|Lo-fi|浪漫,治愈|2|4|学习,通勤|90|3
Reflection Eternal|Nujabes|Lo-fi|怀旧,平静|2|3|学习,发呆|92|3
Battlecry|Nujabes|Lo-fi|振奋,专注|3|4|学习,通勤|93|3
Shiki no Uta|MINMI|Lo-fi|治愈,怀旧|3|4|通勤,学习|90|3
Solitude|Jinsang|Lo-fi|孤独,平静|1|3|学习,睡前|78|2
Monday Loop|Tomppabeats|Lo-fi|放松,专注|2|4|学习,通勤|85|2
Prelude|Idealism|Lo-fi|平静,专注|1|3|学习,睡前|75|2
Controlla|Idealism|Lo-fi|平静,孤独|1|3|学习,发呆|80|2
Roots|Kupla|Lo-fi|平静,专注|1|3|学习,睡前|78|2
Shells|Philanthrope|Lo-fi|治愈,放松|1|4|学习,放松|82|2
Soulful|L'Indécis|Lo-fi|放松,治愈|2|4|学习,通勤|88|2
Ocean|Saib|Lo-fi|平静,梦幻|1|3|学习,睡前|80|2
Glimpse of Us|Joji|Lo-fi|伤感,孤独|2|1|难过,睡前|85|4
Slow Dancing in the Dark|Joji|Lo-fi|伤感,梦幻|2|2|睡前,难过|89|4
Sanctuary|Joji|Lo-fi|浪漫,梦幻|2|3|开车,睡前|86|4
Japanese Denim|Daniel Caesar|R&B|浪漫,放松|2|4|放松,睡前|80|3
Apocalypse|Cigarettes After Sex|Lo-fi|梦幻,浪漫|1|3|睡前,发呆|94|4
Sweet|Cigarettes After Sex|Lo-fi|浪漫,梦幻|1|3|睡前,发呆|90|3
K.|Cigarettes After Sex|Lo-fi|浪漫,孤独|1|3|睡前,开车|92|4
Space Song|Beach House|Lo-fi|梦幻,孤独|2|3|开车,发呆|147|4
Myth|Beach House|Lo-fi|梦幻,平静|2|3|发呆,开车|120|3
Sofia|Clairo|Lo-fi|浪漫,快乐|3|4|通勤,开心|125|3
Pretty Girl|Clairo|Lo-fi|孤独,放松|2|3|发呆,通勤|96|3
Chamber of Reflection|Mac DeMarco|Lo-fi|孤独,梦幻|2|2|发呆,睡前|130|3
My Kind of Woman|Mac DeMarco|Lo-fi|浪漫,放松|2|4|放松,睡前|82|3
Ivy|Frank Ocean|Lo-fi|怀旧,伤感|2|2|开车,难过|116|4
Nights|Frank Ocean|Lo-fi|梦幻,孤独|3|3|开车,发呆|90|4
Chicago|Sufjan Stevens|民谣|怀旧,振奋|3|4|开车|130|3
Mystery of Love|Sufjan Stevens|民谣|浪漫,伤感|1|3|睡前,发呆|80|3
Death with Dignity|Sufjan Stevens|民谣|平静,伤感|1|2|睡前,难过|80|2
Merry-Go-Round of Life|久石让|纯音乐|梦幻,怀旧|2|4|发呆,学习|80|4
One Summer's Day|久石让|纯音乐|怀旧,治愈|1|4|发呆,睡前|76|4
Kiki's Delivery Service|久石让|纯音乐|快乐,治愈|2|5|开心,学习|100|3
天空之城|久石让|纯音乐|怀旧,梦幻|2|3|学习,发呆|80|4
Always With Me|木村弓|纯音乐|治愈,平静|1|4|睡前,发呆|78|3
Experience|Ludovico Einaudi|纯音乐|振奋,梦幻|3|3|学习,发呆|90|4
Una Mattina|Ludovico Einaudi|纯音乐|平静,怀旧|1|3|学习,睡前|72|4
I Giorni|Ludovico Einaudi|纯音乐|平静,伤感|1|3|睡前,学习|66|3
Gymnopédie No.1|Erik Satie|纯音乐|平静,孤独|1|3|睡前,学习|66|4
Clair de Lune|Claude Debussy|纯音乐|梦幻,平静|1|4|睡前,学习|66|5
Canon in D|Johann Pachelbel|纯音乐|平静,治愈|1|4|学习,睡前|60|5
Moonlight Sonata|Ludwig van Beethoven|纯音乐|孤独,伤感|1|2|睡前,难过|54|4
Für Elise|Ludwig van Beethoven|纯音乐|浪漫,平静|2|3|学习,睡前|72|4
Nocturne Op. 9 No. 2|Frédéric Chopin|纯音乐|浪漫,平静|1|3|睡前,学习|60|4
Spring|Max Richter|纯音乐|振奋,梦幻|4|4|学习,开车|100|3
On the Nature of Daylight|Max Richter|纯音乐|伤感,平静|1|2|难过,睡前|60|4
Time|Hans Zimmer|纯音乐|振奋,伤感|3|3|学习,开车|60|5
Interstellar Main Theme|Hans Zimmer|纯音乐|梦幻,孤独|2|3|学习,发呆|70|4
Cornfield Chase|Hans Zimmer|纯音乐|振奋,梦幻|3|3|学习,开车|100|4
He's a Pirate|Klaus Badelt|纯音乐|热血,振奋|5|4|运动,开车|130|4
Merry Christmas Mr. Lawrence|坂本龍一|纯音乐|怀旧,伤感|1|3|睡前,发呆|72|4
Energy Flow|坂本龍一|纯音乐|平静,治愈|1|4|睡前,学习|72|3
Luv Letter|DJ Okawari|纯音乐|浪漫,治愈|2|4|学习,放松|88|3
Flower Dance|DJ Okawari|纯音乐|梦幻,快乐|3|4|学习,通勤|130|4
Maybe|Yiruma|纯音乐|浪漫,平静|1|4|睡前,学习|70|3
The Truth That You Leave|Pianoboy|纯音乐|伤感,平静|1|3|难过,睡前|70|3
Mariage d'amour|Richard Clayderman|纯音乐|浪漫,怀旧|1|4|睡前,发呆|80|4
Ballade pour Adeline|Richard Clayderman|纯音乐|浪漫,治愈|1|4|放松,睡前|76|4
Bloom|The Paper Kites|民谣|浪漫,平静|1|4|睡前,放松|78|3
Your Hand in Mine|Explosions in the Sky|纯音乐|梦幻,治愈|3|4|学习,发呆|120|3
Hoppípolla|Sigur Rós|纯音乐|梦幻,振奋|3|4|发呆,开车|120|3
Svefn-g-englar|Sigur Rós|纯音乐|梦幻,平静|1|3|睡前,发呆|60|2
Weightless|Marconi Union|纯音乐|平静,放松|1|3|睡前,放松|60|3
An Ending (Ascent)|Brian Eno|纯音乐|平静,梦幻|1|3|睡前,学习|60|3
Nara|E.S. Posthumus|纯音乐|热血,振奋|4|3|运动,学习|90|3
Victory|Two Steps from Hell|纯音乐|热血,振奋|5|4|运动|134|4
Heart of Courage|Two Steps from Hell|纯音乐|热血,振奋|5|4|运动,学习|90|3
星空|Richard Clayderman|纯音乐|浪漫,梦幻|1|4|睡前,发呆|72|3
琵琶语|林海|纯音乐|平静,怀旧|1|3|睡前,学习|66|4
城南花已开|三亩地|纯音乐|治愈,平静|2|4|学习,放松|90|4
雪の華|中島美嘉|流行|浪漫,伤感|2|3|睡前,发呆|78|4
Ref:rain|Aimer|流行|伤感,平静|2|2|难过,睡前|90|3
Sicko Mode|Travis Scott|嘻哈|热血,梦幻|5|3|运动,开车|155|5
Goosebumps|Travis Scott|嘻哈|梦幻,孤独|4|3|开车,运动|130|4
God's Plan|Drake|嘻哈|振奋,放松|3|4|开车,通勤|77|5
Hotline Bling|Drake|嘻哈|放松,孤独|3|3|开车,通勤|135|5
One Dance|Drake|嘻哈|快乐,放松|3|4|开心,开车|104|5
Passionfruit|Drake|嘻哈|放松,孤独|2|3|开车,发呆|112|4
Alright|Kendrick Lamar|嘻哈|振奋,热血|4|4|运动,开心|110|4
Money Trees|Kendrick Lamar|嘻哈|放松,梦幻|3|3|开车,发呆|72|4
Swimming Pools|Kendrick Lamar|嘻哈|梦幻,孤独|3|2|开车|74|4
Stronger|Kanye West|嘻哈|热血,振奋|5|4|运动|104|5
Gold Digger|Kanye West|嘻哈|快乐,振奋|4|4|开心,运动|93|4
Flashing Lights|Kanye West|嘻哈|梦幻,振奋|4|3|开车,运动|90|4
Runaway|Kanye West|嘻哈|孤独,伤感|3|2|发呆,难过|87|4
Empire State of Mind|JAY-Z|嘻哈|振奋,热血|4|4|开车,通勤|87|5
Juicy|The Notorious B.I.G.|嘻哈|怀旧,快乐|3|4|开车,开心|96|4
California Love|2Pac|嘻哈|快乐,振奋|4|5|开车,开心|92|4
Still D.R.E.|Dr. Dre|嘻哈|振奋,专注|4|3|开车,运动|93|5
Without Me|Eminem|嘻哈|快乐,振奋|5|4|运动,开心|112|5
Mockingbird|Eminem|嘻哈|伤感,怀旧|3|2|难过,开车|84|4
Till I Collapse|Eminem|嘻哈|热血,振奋|5|3|运动|171|5
The Real Slim Shady|Eminem|嘻哈|快乐,振奋|4|4|开心,运动|105|4
In Da Club|50 Cent|嘻哈|振奋,热血|4|4|运动,开车|90|4
Can't Hold Us|Macklemore & Ryan Lewis|嘻哈|热血,振奋|5|5|运动|146|5
Thrift Shop|Macklemore & Ryan Lewis|嘻哈|快乐|4|5|开心|95|4
Rockstar|Post Malone|嘻哈|梦幻,孤独|3|2|开车,发呆|160|4
Circles|Post Malone|嘻哈|怀旧,伤感|3|3|开车,通勤|120|5
Congratulations|Post Malone|嘻哈|振奋,快乐|3|4|开心,开车|123|4
Mood|24kGoldn|嘻哈|快乐,伤感|4|4|通勤,开车|91|4
Ms. Jackson|OutKast|嘻哈|怀旧,快乐|4|4|开车,开心|95|4
Hey Ya!|OutKast|嘻哈|快乐,振奋|5|5|开心,运动|160|5
Love Me Like You Do|Ellie Goulding|流行|浪漫,梦幻|3|4|开车,开心|95|4
Feel Good Inc.|Gorillaz|嘻哈|梦幻,振奋|4|3|开车,通勤|139|4
Clint Eastwood|Gorillaz|嘻哈|梦幻,孤独|3|3|开车,发呆|84|4
The Message|Nas|嘻哈|专注,热血|3|3|通勤,学习|94|3
N.Y. State of Mind|Nas|嘻哈|专注,热血|3|3|通勤,学习|84|3
Electric Relaxation|A Tribe Called Quest|嘻哈|放松,快乐|3|4|通勤,学习|92|3
Can I Kick It?|A Tribe Called Quest|嘻哈|快乐,放松|3|4|开心,通勤|97|3
Shook Ones, Pt. II|Mobb Deep|嘻哈|热血,专注|4|2|运动,通勤|94|3
沧海一声笑|GAI|嘻哈|热血,怀旧|4|4|运动,开车|96|3
雅俗共赏|许嵩|国风|快乐,振奋|3|4|开心,通勤|96|4
不该|周杰伦|流行|伤感,浪漫|2|2|难过,睡前|76|4
飘向北方|那吾克热|嘻哈|孤独,怀旧|3|2|开车,难过|80|4
星球坠落|艾热|嘻哈|梦幻,孤独|3|2|开车,发呆|86|3
时间煮雨|吴亦凡|流行|怀旧,伤感|2|2|难过,发呆|72|4
大鱼|周深|国风|梦幻,伤感|2|3|睡前,发呆|72|5
起风了|周深|流行|怀旧,振奋|3|3|开车,通勤|80|4
光亮|周深|流行|振奋,治愈|3|4|开心,通勤|80|3
芒种|音阙诗听|国风|快乐,怀旧|3|4|开心,通勤|100|4
锦鲤抄|银临|国风|浪漫,怀旧|2|3|发呆,睡前|76|3
叹云兮|鞠婧祎|国风|伤感,梦幻|2|2|难过,睡前|72|3
琵琶行|奇然|国风|伤感,怀旧|2|2|发呆,难过|80|3
烟花易冷|周杰伦|国风|伤感,怀旧|2|2|难过,发呆|76|5
东风破|周杰伦|国风|伤感,怀旧|2|2|难过,发呆|70|5
发如雪|周杰伦|国风|浪漫,伤感|3|3|发呆,开车|80|5
菊花台|周杰伦|国风|伤感,平静|2|2|睡前,难过|66|5
兰亭序|周杰伦|国风|浪漫,怀旧|2|3|发呆,睡前|72|5
千里之外|周杰伦|国风|浪漫,伤感|2|3|发呆,睡前|76|5
本草纲目|周杰伦|国风|热血,快乐|4|4|运动,开心|98|4
霍元甲|周杰伦|国风|热血,振奋|5|4|运动|120|4
曹操|林俊杰|国风|热血,振奋|4|3|开车,运动|86|4
庐州月|许嵩|国风|怀旧,伤感|2|2|发呆,睡前|76|4
清明雨上|许嵩|国风|伤感,怀旧|2|2|难过,睡前|72|4
断桥残雪|许嵩|国风|伤感,孤独|2|2|难过,发呆|76|4
半壶纱|刘珂矣|国风|平静,浪漫|1|3|睡前,放松|70|4
一笑倾城|汪苏泷|流行|浪漫,快乐|3|5|开心,通勤|96|4
红昭愿|音阙诗听|国风|热血,振奋|4|4|运动,开心|110|4
探窗|国风堂|国风|伤感,浪漫|2|3|睡前,发呆|76|3
桃花诺|邓紫棋|国风|浪漫,伤感|2|3|睡前,发呆|74|4
赤伶|等什么君|国风|伤感,怀旧|3|2|难过,发呆|80|3
囍|葛东琪|国风|伤感,梦幻|3|2|发呆,难过|86|4
九张机|叶炫清|国风|伤感,浪漫|2|2|睡前,难过|72|3
红颜劫|姚贝娜|国风|伤感,梦幻|2|2|难过,睡前|70|3
画心|张靓颖|国风|浪漫,伤感|2|2|睡前,难过|72|4
凉凉|杨宗纬 & 张碧晨|国风|伤感,浪漫|2|2|难过,睡前|68|5
倾尽天下|河图|国风|热血,伤感|3|2|发呆,难过|80|3
盗将行|花粥 & 马雨阳|国风|快乐,浪漫|3|4|开心,开车|96|4
少年|梦然|流行|振奋,热血|4|4|运动,通勤|90|4
沙漠骆驼|展展与罗罗|流行|振奋,孤独|4|3|开车,运动|130|4
野子|苏运莹|民谣|振奋,孤独|3|3|开车,发呆|88|4
空空如也|胡66|流行|伤感,孤独|2|2|难过|74|3
下山|要不要买菜|国风|快乐,热血|4|4|开心,运动|120|3
万疆|李玉刚|国风|振奋,热血|4|4|开车,运动|80|3
上春山|魏晨|国风|快乐,浪漫|3|5|开心,通勤|108|3
"""
}
