import SwiftUI

// MARK: - 封面：曲风底色 + 白色小格 + 手绘图案（随歌曲 ID 轻微旋转）

struct CoverArt: View {
    @Environment(AppModel.self) private var model
    let song: Song
    var corner: CGFloat = 14

    private static let style: [String: (Color, String)] = [
        "流行": (Palette.red, "motif-pop"), "R&B": (Palette.blue, "motif-rnb"), "民谣": (Palette.yellow, "motif-folk"),
        "摇滚": (Palette.red, "motif-rock"), "电子": (Palette.blue, "motif-electronic"), "爵士": (Palette.yellow, "motif-jazz"),
        "Lo-fi": (Palette.sky, "motif-lofi"), "纯音乐": (Palette.coverCream, "motif-instrumental"), "嘻哈": (Palette.yellow, "motif-hiphop"),
        "国风": (Palette.red, "motif-guofeng"),
    ]

    var body: some View {
        let (bg, motif) = Self.style[song.genre] ?? (Palette.yellow, "motif-jazz")
        GeometryReader { geo in
            let u = geo.size.width / 100
            ZStack {
                bg
                // 底部两排白色小格
                Canvas { ctx, _ in
                    for i in 0..<4 {
                        ctx.fill(Path(CGRect(x: CGFloat(i) * 24 * u, y: 88 * u, width: 12 * u, height: 12 * u)), with: .color(.white.opacity(0.28)))
                        ctx.fill(Path(CGRect(x: (12 + CGFloat(i) * 24) * u, y: 76 * u, width: 12 * u, height: 12 * u)), with: .color(.white.opacity(0.28)))
                    }
                }
                Image(motif)
                    .resizable()
                    .interpolation(.high)
                    .scaledToFit()
                    .rotationEffect(.degrees(Double(song.number % 7 - 3)))
                // Apple Music 查到封面后盖在上面；加载中或没查到时显示手绘封面
                if let url = model.artwork(song.id) {
                    AsyncImage(url: url) { img in img.resizable().scaledToFill() } placeholder: { Color.clear }
                        .frame(width: geo.size.width, height: geo.size.height)
                        .clipped()
                }
            }
        }
        .aspectRatio(1, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: corner, style: .continuous))
        .accessibilityHidden(true)
    }
}

// MARK: - 吉祥物：戴红耳机的小音符团子

struct Mascot: View {
    enum Kind: String { case sing, happy, sleepy }
    var kind: Kind = .sing
    var bob = false
    @State private var up = false

    var body: some View {
        Image("mascot-\(kind.rawValue)")
            .resizable()
            .scaledToFit()
            .rotationEffect(.degrees(bob ? (up ? 2 : -2) : 0), anchor: UnitPoint(x: 0.5, y: 0.9))
            .offset(y: bob && up ? -8 : 0)
            .onAppear {
                guard bob else { return }
                withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true)) { up = true }
            }
            .accessibilityLabel("MoodMusic 的小音符团子")
    }
}

// MARK: - Logo：MoodMusic AI + 手绘椭圆圈

struct Logo: View {
    var size: CGFloat = 26
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 3) {
            Text("MoodMusic").font(AppFont.hand(size))
            Text("AI").font(AppFont.hand(size * 0.62))
        }
        .foregroundStyle(.white)
        .padding(.vertical, size * 0.25).padding(.horizontal, size * 0.7)
        .overlay(
            ZStack {
                Ellipse().stroke(.white, lineWidth: 2.2).padding(-4)
                Ellipse().stroke(.white, lineWidth: 1.6).rotationEffect(.degrees(-2)).padding(-2)
            }
        )
        .fixedSize()
        .accessibilityLabel("MoodMusic AI")
    }
}

// MARK: - 页眉：红色带 + 问候

struct HeaderBand: View {
    var body: some View {
        TimelineView(.everyMinute) { ctx in
            HStack {
                Logo()
                Spacer()
                VStack(alignment: .trailing, spacing: 0) {
                    Text("\(NeedParser.timeSlot(ctx.date))好")
                    Text(Self.stamp(ctx.date))
                }
                .font(AppFont.hand(17))
                .foregroundStyle(.white.opacity(0.95))
            }
            .padding(.horizontal, 18).padding(.top, 10).padding(.bottom, 12)
        }
        .background(BandBackground().ignoresSafeArea(edges: .top))
    }

    static func stamp(_ d: Date) -> String {
        let days = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"]
        let c = Calendar.current.dateComponents([.weekday, .hour, .minute], from: d)
        return "\(days[(c.weekday ?? 1) - 1]) " + String(format: "%02d:%02d", c.hour ?? 0, c.minute ?? 0)
    }
}

// MARK: - 选择胶囊

struct ChipButton: View {
    let label: String
    var sub: String? = nil
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Circle().fill(selected ? Palette.red : Palette.blue).frame(width: 8, height: 8)
                Text(label).font(.system(size: 14, weight: selected ? .bold : .regular))
                if let sub, !sub.isEmpty {
                    Text(sub).font(.system(size: 11)).foregroundStyle(selected ? Palette.redInk : Palette.muted)
                }
            }
            .foregroundStyle(selected ? Palette.redInk : Palette.ink)
            .padding(.vertical, 8).padding(.horizontal, 14)
            .sketch(selected ? Palette.yellow : .white, line: selected ? Palette.red : Palette.blue, width: 2, radius: 18, seed: label.count + 3)
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}

/// 自动换行的流式布局
struct FlowLayout: Layout {
    var spacing: CGFloat = 9

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxW = proposal.width ?? .infinity
        var x: CGFloat = 0, y: CGFloat = 0, rowH: CGFloat = 0, widest: CGFloat = 0
        for v in subviews {
            let s = v.sizeThatFits(.unspecified)
            if x > 0 && x + s.width > maxW { y += rowH + spacing; x = 0; rowH = 0 }
            x += s.width + spacing
            rowH = max(rowH, s.height)
            widest = max(widest, x - spacing)
        }
        return CGSize(width: min(widest, maxW), height: y + rowH)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX, y = bounds.minY, rowH: CGFloat = 0
        for v in subviews {
            let s = v.sizeThatFits(.unspecified)
            if x > bounds.minX && x + s.width > bounds.maxX { y += rowH + spacing; x = bounds.minX; rowH = 0 }
            v.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(s))
            x += s.width + spacing
            rowH = max(rowH, s.height)
        }
    }
}

// MARK: - 小图标按钮（喜欢 / 收藏 / 不喜欢 …）

struct IconLabelButton: View {
    let icon: String
    let label: String
    var on = false
    var onColor: Color = Palette.red
    var vertical = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Group {
                if vertical {
                    VStack(spacing: 2) { Image(systemName: icon).font(.system(size: 20)); Text(label).font(.system(size: 12, weight: on ? .bold : .regular)) }
                        .frame(maxWidth: .infinity).padding(.vertical, 8)
                } else {
                    HStack(spacing: 5) { Image(systemName: icon).font(.system(size: 15)); Text(label).font(.system(size: 13, weight: on ? .bold : .regular)) }
                        .padding(.vertical, 6).padding(.horizontal, 10)
                }
            }
            .foregroundStyle(on ? onColor : Palette.muted)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

/// 推荐位标签：稳妥 / 探索 / 惊喜
struct SlotTag: View {
    let slot: String
    var body: some View {
        let (bg, fg): (Color, Color) = slot == "探索" ? (Palette.yellow, Palette.exploreInk) : slot == "惊喜" ? (Palette.red, .white) : (Palette.safeBg, Palette.blueInk)
        Text(SlotText.of(slot))
            .font(.system(size: 11, weight: .bold))
            .kerning(0.5)
            .foregroundStyle(fg)
            .padding(.vertical, 1).padding(.horizontal, 7)
            .background(RoundedRectangle(cornerRadius: 6).fill(bg))
    }
}

/// 卡片标题行
struct SectionTitle: View {
    let text: String
    var body: some View { Text(text).font(AppFont.display(18)).foregroundStyle(Palette.ink) }
}

/// 页面通用容器：滚动 + 内边距
struct PageScroll<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) { content }
                .padding(.horizontal, 20).padding(.top, 20).padding(.bottom, 24)
                .frame(maxWidth: 560)
                .frame(maxWidth: .infinity)
        }
        .scrollDismissesKeyboard(.interactively)
    }
}

/// 播放进度条（可拖动）
struct ProgressBar: View {
    let fraction: Double
    var height: CGFloat = 12
    var knob = true
    var fill: Color = Palette.red
    var onSeek: ((Double) -> Void)? = nil

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            ZStack(alignment: .leading) {
                Capsule().fill(Palette.track)
                Capsule().fill(fill).frame(width: max(0, min(1, fraction)) * w)
                if knob {
                    Circle().fill(.white).overlay(Circle().stroke(Palette.blue, lineWidth: 3))
                        .frame(width: 20, height: 20)
                        .offset(x: max(0, min(1, fraction)) * w - 10)
                }
            }
            .frame(height: height)
            .frame(maxHeight: .infinity)
            .contentShape(Rectangle())
            .gesture(DragGesture(minimumDistance: 0).onEnded { v in onSeek?(min(1, max(0, v.location.x / w))) })
        }
        .frame(height: knob ? 24 : height)
    }
}

func fmtTime(_ t: Double) -> String {
    let s = max(0, Int(t))
    return "\(s / 60):" + String(format: "%02d", s % 60)
}
