import SwiftUI

struct ResultsView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        if let need = model.need {
            switch model.resultKind {
            case .search: SearchResultsView(need: need, result: model.searchResult)
            case .pending: SearchPendingView(need: need)
            case .recommend: recommendList(need)
            }
        } else {
            HomeView()
        }
    }

    private func recommendList(_ need: Need) -> some View {
        PageScroll {
            HStack {
                IconLabelButton(icon: "chevron.left", label: "重新说") { model.go(.home) }
                Spacer()
                Text("第 \(model.batchNo) 批").tiny()
            }
            VStack(alignment: .leading, spacing: 2) {
                Text("为你推荐 · Top 5").eyebrow()
                Text("这一刻，听这些").displayTitle()
            }
            WhyCard(need: need, batch: model.batch)
            VStack(spacing: 14) {
                ForEach(Array(model.batch.enumerated()), id: \.element.id) { i, r in
                    if let s = model.song(r.id) { SongCard(rec: r, song: s, index: i) }
                }
            }
            HStack(spacing: 10) {
                Button { model.refresh() } label: { Label("换一批", systemImage: "arrow.clockwise") }
                    .buttonStyle(SecondaryButtonStyle())
                    .disabled(model.busy)
                Button { model.playBatch(0) } label: { Label("全部播放", systemImage: "play.fill") }
                    .buttonStyle(PrimaryButtonStyle())
            }
            Text("曲库是 \(model.catalog.songs.count) 首 Apple Music 上的真实歌曲。").tiny()
        }
    }
}

/// 推荐位说明（和网页 2.0 一致）
enum SlotText {
    static let label = ["稳妥": "适合你当前状态", "探索": "尝试新的风格", "惊喜": "给你一点新鲜感"]
    static let desc = ["稳妥": "贴合你的口味与此刻的需求", "探索": "换一位你可能还没听过的歌手", "惊喜": "换个平时少听的风格，添点新鲜感"]
    static func of(_ slot: String) -> String { label[slot] ?? label["稳妥"]! }
}

// MARK: - "我听懂的是"

struct UnderstandingCard: View {
    let need: Need
    let mode: APIClient.Mode

    private var modeText: String {
        switch mode {
        case .llm: return "AI 大模型理解"
        case .rules: return "服务器规则理解"
        case .local: return "本地规则理解"
        }
    }

    private var rows: [(String, String)] {
        var r: [(String, String)] = []
        let e = need.entities
        if let s = e.song { r.append(("想找的歌", "《\(s)》")) }
        if let a = e.artist { r.append(("指定歌手", a)) }
        if let w = e.workTitle { r.append(("作品", "《\(w)》")) }
        if e.artist == nil, let a = need.artistPreference { r.append(("想听的歌手", a)) }
        if need.current != nil || need.target != "随心" { r.append(("情绪", "\(need.current ?? "未提及")  →  想要\(need.target)")) }
        if let s = need.scene { r.append(("场景", s == "学习" ? "工作 / 学习" : s)) }
        r.append(("能量", NeedParser.energyLabel(need.energy)))
        r.append(("时间", need.time ?? NeedParser.timeSlot()))
        if !need.genres.isEmpty { r.append(("想听", need.genres.joined(separator: "、"))) }
        if !need.exclude.isEmpty { r.append(("避开", need.exclude.joined(separator: "、"))) }
        return r
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("我听懂的是").eyebrow()
                Spacer()
                Text(modeText).tiny()
            }
            Group {
                if !need.text.isEmpty { Text("“\(need.text)”") }
                else if let c = need.chip { Text("场景：\(c)") }
                else { Text("没有说具体需求，先按你的口味来") }
            }
            .font(.system(size: 17, weight: .medium, design: .rounded))
            .foregroundStyle(Palette.blueInk)

            Grid(alignment: .leadingFirstTextBaseline, horizontalSpacing: 12, verticalSpacing: 6) {
                ForEach(rows, id: \.0) { row in
                    GridRow {
                        Text(row.0).font(.system(size: 12)).foregroundStyle(Palette.muted)
                        Text(row.1).font(.system(size: 14, weight: .semibold)).foregroundStyle(Palette.ink)
                    }
                }
            }
        }
        .padding(16)
        .sketch(Palette.cream, line: Palette.yellow, width: 3, radius: 20, seed: 17)
    }
}

// MARK: - "为什么是这 5 首"

struct WhyCard: View {
    let need: Need
    let batch: [Recommendation]

    private var lead: String {
        var bits: [String] = []
        if let s = need.scene { bits.append("很适合\(s == "学习" ? "工作学习" : s)的时候") }
        if let c = need.current, c != need.target { bits.append("帮你从\(c)慢慢过渡到\(need.target)") }
        else if need.target != "随心" { bits.append("围绕“\(need.target)”来挑") }
        if !need.exclude.isEmpty { bits.append("并避开了你不想听的\(need.exclude.joined(separator: "、"))") }
        return bits.isEmpty ? "" : bits.joined(separator: "，") + "。"
    }

    var body: some View {
        let counts = Dictionary(grouping: batch, by: \.slot).mapValues(\.count)
        VStack(alignment: .leading, spacing: 8) {
            SectionTitle(text: "为什么是这 5 首")
            if !lead.isEmpty { Text(lead).tiny() }
            ForEach(["稳妥", "探索", "惊喜"].filter { counts[$0] != nil }, id: \.self) { s in
                HStack(spacing: 8) {
                    SlotTag(slot: s)
                    Text("×\(counts[s] ?? 0)").font(.system(size: 13, weight: .bold)).foregroundStyle(Palette.ink)
                    Text(SlotText.desc[s] ?? "").tiny()
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .sketch(.white, line: Palette.blue, width: 2.5, radius: 20, seed: 23)
    }
}

// MARK: - 歌曲卡片

struct SongCard: View {
    @Environment(AppModel.self) private var model
    let rec: Recommendation
    let song: Song
    let index: Int

    var body: some View {
        let x = model.stats(song.id)
        let note = model.fbNote(song.id)
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Button { model.playBatch(index) } label: {
                    CoverArt(song: song)
                        .frame(width: 68, height: 68)
                        .overlay(alignment: .bottomTrailing) {
                            Image(systemName: "play.fill").font(.system(size: 10)).foregroundStyle(Palette.red)
                                .frame(width: 24, height: 24)
                                .background(Circle().fill(Palette.paper))
                                .background(Circle().fill(Palette.ink).offset(y: 2))
                                .padding(4)
                        }
                }
                .buttonStyle(.plain)
                .accessibilityLabel("播放 \(song.title)")

                VStack(alignment: .leading, spacing: 2) {
                    SlotTag(slot: rec.slot)
                    Text(song.title).font(AppFont.display(18)).foregroundStyle(Palette.ink).fixedSize(horizontal: false, vertical: true)
                    Text("\(song.artist) · \(song.genre)").font(.system(size: 13)).foregroundStyle(Palette.muted)
                    if let a = model.tags(song.id)?.audience {
                        Text("适合：\(a)").font(.system(size: 12)).foregroundStyle(Palette.blueInk)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            Text(x.dislike != 0 ? "已记下你不喜欢这首，之后不会再推荐它，同类风格也会少一些。" : rec.reason)
                .font(.system(size: 13.5))
                .foregroundStyle(Palette.ink)
                .lineSpacing(3)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.vertical, 8).padding(.horizontal, 10)
                .background(RoundedRectangle(cornerRadius: 12).fill(Palette.cream))
            if !note.isEmpty { FeedbackNote(text: note) }
            FeedbackRow(id: song.id)
            MuteRow(song: song, showAdd: true)
        }
        .padding(.horizontal, 12).padding(.top, 12).padding(.bottom, 10)
        .sketch(.white, line: Palette.blue, width: 2.5, radius: 20, seed: song.number)
        .opacity(x.dislike != 0 ? 0.55 : 1)
    }
}

/// 反馈后的持久说明
struct FeedbackNote: View {
    let text: String
    var body: some View {
        Label(text, systemImage: "checkmark.circle")
            .font(.system(size: 12))
            .foregroundStyle(Palette.blueInk)
    }
}

/// 喜欢 / 收藏 / 不喜欢 / 跳过
struct FeedbackRow: View {
    @Environment(AppModel.self) private var model
    let id: String
    var vertical = false

    var body: some View {
        let x = model.stats(id)
        let liked = model.isApple(id) ? model.isAppleLiked(String(id.dropFirst(6))) : x.like != 0
        HStack(spacing: vertical ? 4 : 0) {
            IconLabelButton(icon: liked ? "heart.fill" : "heart", label: "喜欢", on: liked, vertical: vertical) { model.setFlag(id, .like) }
            IconLabelButton(icon: x.fav != 0 ? "star.fill" : "star", label: x.fav != 0 ? "已收藏" : "收藏", on: x.fav != 0, onColor: Palette.favInk, vertical: vertical) { model.setFlag(id, .fav) }
            IconLabelButton(icon: x.dislike != 0 ? "hand.thumbsdown.fill" : "hand.thumbsdown", label: x.dislike != 0 ? "已不喜欢" : "不喜欢", on: x.dislike != 0, onColor: Palette.blueInk, vertical: vertical) { model.setFlag(id, .dislike) }
            IconLabelButton(icon: "forward", label: "跳过", on: x.skip != 0, onColor: Palette.exploreInk, vertical: vertical) { model.skip(id) }
            if !vertical { Spacer(minLength: 0) }
        }
    }
}

/// 少推这个歌手 / 曲风（只对这一轮推荐生效）+ 加入歌单
struct MuteRow: View {
    @Environment(AppModel.self) private var model
    @Environment(\.openURL) private var openURL
    let song: Song
    var showAdd = false

    var body: some View {
        FlowLayout(spacing: 6) {
            if model.need != nil {
                pill("少推 \(song.artist)", on: model.isMuted("artist", song.artist)) { model.mute("artist", song.artist) }
                pill("少推 \(song.genre)", on: model.isMuted("genre", song.genre)) { model.mute("genre", song.genre) }
            }
            if showAdd {
                pill("＋ 加入歌单", on: false) { model.addToPlaylist(model.libItem(forSong: song.id)) }
            }
            if let u = model.appleMusicURL(forSong: song.id) {
                pill("在 Apple Music 中打开 ↗", on: false) { openURL(u) }
            }
        }
    }

    private func pill(_ t: String, on: Bool, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(t).font(.system(size: 12, weight: on ? .bold : .regular))
                .foregroundStyle(on ? .white : Palette.muted)
                .padding(.vertical, 5).padding(.horizontal, 10)
                .background(Capsule().fill(on ? Palette.muted : Palette.track))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

// MARK: - 追问页（最多问一次，可跳过）

struct ClarifyView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        let n = model.need
        let said = n?.text ?? ""
        PageScroll {
            HStack {
                IconLabelButton(icon: "chevron.left", label: "换一种说法") { model.go(.home) }
                Spacer()
            }
            VStack(alignment: .leading, spacing: 2) {
                Text("再确认一下").eyebrow()
                Text(n?.clarificationQuestion ?? "能再补充一点吗？").displayTitle()
            }
            VStack(alignment: .leading, spacing: 10) {
                Text(said.isEmpty ? "先帮我确认一下方向" : "“\(said)”")
                    .font(.system(size: 17, weight: .medium, design: .rounded)).foregroundStyle(Palette.blueInk)
                Text("选一个，我立刻按这个方向挑歌；不想选也没关系，可以直接跳过。").tiny()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .sketch(Palette.cream, line: Palette.yellow, width: 3, radius: 20, seed: 17)
            VStack(spacing: 10) {
                ForEach(n?.clarificationOptions ?? [], id: \.self) { o in
                    Button(o.label) { model.answerClarify(o.value) }.buttonStyle(SecondaryButtonStyle()).disabled(model.busy)
                }
            }
            Button("跳过，直接推荐") { model.skipClarify() }.buttonStyle(GhostButtonStyle()).disabled(model.busy)
                .frame(maxWidth: .infinity)
        }
    }
}

// MARK: - 找指定歌曲的结果

struct SearchResultsView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.openURL) private var openURL
    let need: Need
    let result: AppleMusic.SearchResult?

    private var isOST: Bool { result?.reason.hasPrefix("soundtrack") == true }

    private var ask: String {
        let e = need.entities
        if isOST, let w = e.workTitle ?? e.song {
            let en = WorkTitles.hasCJK(w) ? WorkTitles.english(for: w) : nil
            return "《\(w)》" + (en.map { "（\($0)）" } ?? "") + "里的歌"
        }
        if e.song == nil, let a = e.artist { return "\(a) 的歌" }
        let s = [e.song.map { "《\($0)》" }, e.artist].compactMap { $0 }.joined(separator: " · ")
        return s.isEmpty ? "这首歌" : s
    }

    var body: some View {
        PageScroll {
            HStack {
                IconLabelButton(icon: "chevron.left", label: "换一种说法") { model.go(.home) }
                Spacer()
            }
            VStack(alignment: .leading, spacing: 2) {
                Text("我听懂你要找什么了").eyebrow()
                Text(result?.found == true ? "找到啦" : reason == "soundtrack" ? "找到这些相关的原声" : reason == "artist" ? "找到 \(result?.candidates.first?.artistName ?? need.entities.artist ?? "") 的歌" : reason == "artist_empty" ? "没找到这位歌手" : "没找到这首歌").displayTitle()
            }
            VStack(alignment: .leading, spacing: 8) {
                Text("“\(need.text)”").font(.system(size: 17, weight: .medium, design: .rounded)).foregroundStyle(Palette.blueInk)
                Text("你在找：\(ask)").tiny()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .sketch(Palette.cream, line: Palette.yellow, width: 3, radius: 20, seed: 17)

            if let r = result, let h = r.hit, r.found {
                found(h, all: r.all)
            } else if reason == "soundtrack" || reason == "artist" {
                Text(reason == "artist" ? "下面是在 Apple Music 里找到的这位歌手的歌，点一首就能听。"
                     : "下面是在 Apple Music 里按作品名找到的原声歌曲。我没法确认哪一首就是你说的那首，请你自己挑。").muted()
                if let all = result?.candidates, !all.isEmpty {
                    Button { model.playItems(all.map(\.libItem), 0, title: "找到的歌曲") } label: { Label("全部播放", systemImage: "play.fill") }
                        .buttonStyle(PrimaryButtonStyle())
                }
                candidatesCard
            } else {
                notFoundCard
                candidatesCard
            }
            HStack(spacing: 10) {
                Button("说说我的心情") { model.go(.home) }.buttonStyle(PrimaryButtonStyle())
                if result?.found == true { Button("再找一首") { model.searchAgain() }.buttonStyle(SecondaryButtonStyle()) }
            }
        }
    }

    private func found(_ h: AppleMusic.Hit, all: [AppleMusic.Hit]) -> some View {
        let liked = model.isAppleLiked(String(h.trackId))
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("真实歌曲").font(.system(size: 11, weight: .bold)).foregroundStyle(Palette.blueInk)
                    .padding(.vertical, 1).padding(.horizontal, 7).background(RoundedRectangle(cornerRadius: 6).fill(Palette.safeBg))
                Spacer()
                Text("来源：Apple Music（\(h.storefront.uppercased()) 区）").tiny()
            }
            HStack(spacing: 12) {
                AsyncImage(url: h.artwork.flatMap { URL(string: $0) }) { img in img.resizable().scaledToFill() } placeholder: { Palette.cream }
                    .frame(width: 72, height: 72).clipShape(RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 2) {
                    Text(h.trackName).font(AppFont.display(20)).foregroundStyle(Palette.ink)
                    Text(h.artistName + (h.collectionName.map { " · 《\($0)》" } ?? "")).muted()
                }
            }
            Button { model.playItems(all.map(\.libItem), 0, title: "找到的歌曲") } label: { Label("播放", systemImage: "play.fill") }
                .buttonStyle(PrimaryButtonStyle())
            if let u = h.trackViewUrl.flatMap({ URL(string: $0) }) {
                Button("在 Apple Music 中打开") { openURL(u) }.buttonStyle(SecondaryButtonStyle())
            }
            HStack(spacing: 10) {
                Button { model.toggleAppleLike(h.libItem) } label: { Label(liked ? "已喜欢" : "喜欢", systemImage: liked ? "heart.fill" : "heart") }
                    .buttonStyle(SecondaryButtonStyle(tint: liked ? Palette.red : Palette.blueInk, line: liked ? Palette.red : Palette.blue))
                Button("＋ 加入歌单") { model.addToPlaylist(h.libItem) }.buttonStyle(SecondaryButtonStyle())
            }
            Text("有 Apple Music 订阅时会完整播放，没有订阅放 30 秒试听。").tiny()
        }
        .padding(16)
        .sketch(.white, line: Palette.blue, width: 2.5, radius: 20, seed: 31)
    }

    private var reason: String { result?.reason ?? "upstream_error" }

    private var notFoundCard: some View {
        let amb = reason == "ambiguous"
        let msg = ["empty": "曲库里没有找到这首歌。换个歌名或歌手再试试？",
                   "no_match": "找到了相似的结果，但都不能确认是你要的那首，所以不替你认定。",
                   "ambiguous": "找到好几首同名的歌，分属不同歌手，我不替你认定是哪一首。",
                   "upstream_error": "暂时连不上 Apple Music，请检查网络后再试。",
                   "artist_empty": "在 Apple Music 里没找到这位歌手的歌。检查一下名字，或者说说此刻的心情，我按心情来推荐。",
                   "soundtrack_empty": "在 Apple Music 里没找到这部作品的原声。可以试试直接说歌名，比如“我想听《晴天》”。"][reason] ?? "暂时没有找到这首歌。"
        return VStack(alignment: .leading, spacing: 8) {
            SectionTitle(text: amb ? "有好几首同名歌曲" : "没有可靠匹配")
            Text(msg).muted()
            Text(amb ? "请从下面的候选里选你要找的那一首；或补上歌手名，例如“周杰伦的晴天”。" : "我们不会拿别的版本或别的歌曲冒充你要找的那首。").tiny()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .sketch(.white, line: Palette.blue, width: 2.5, radius: 20, seed: 33)
    }

    @ViewBuilder private var candidatesCard: some View {
        let cands = result?.candidates ?? []
        if !cands.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                SectionTitle(text: reason == "ambiguous" || reason == "soundtrack" || reason == "artist" ? "选一首" : "你可能想找的是")
                ForEach(Array(cands.enumerated()), id: \.element.id) { i, c in
                    CandidateRow(hit: c, index: i, all: cands)
                }
            }
        }
    }
}

private struct CandidateRow: View {
    @Environment(AppModel.self) private var model
    let hit: AppleMusic.Hit
    let index: Int
    let all: [AppleMusic.Hit]

    var body: some View {
        let liked = model.isAppleLiked(String(hit.trackId))
        HStack(spacing: 8) {
            Button { model.playItems(all.map(\.libItem), index, title: "找到的歌曲") } label: {
                HStack(spacing: 10) {
                    AsyncImage(url: hit.artwork.flatMap { URL(string: $0) }) { img in img.resizable().scaledToFill() } placeholder: { Palette.cream }
                        .frame(width: 44, height: 44).clipShape(RoundedRectangle(cornerRadius: 9))
                    VStack(alignment: .leading, spacing: 1) {
                        Text(hit.trackName).font(.system(size: 14, weight: .semibold)).lineLimit(1)
                        Text(hit.artistName + (hit.collectionName.map { " · 《\($0)》" } ?? "")).font(.system(size: 12)).foregroundStyle(Palette.muted).lineLimit(1)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .foregroundStyle(Palette.ink)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("播放 \(hit.trackName)")
            IconLabelButton(icon: liked ? "heart.fill" : "heart", label: "", on: liked) { model.toggleAppleLike(hit.libItem) }
                .accessibilityLabel("喜欢")
            IconLabelButton(icon: "plus", label: "") { model.addToPlaylist(hit.libItem) }
                .accessibilityLabel("加入歌单")
        }
        .padding(8)
        .sketch(.white, line: Palette.blue, width: 2, radius: 14, seed: index + 50)
    }
}

// MARK: - 影视作品的歌：还不支持

struct SearchPendingView: View {
    @Environment(AppModel.self) private var model
    let need: Need

    private static let role = ["theme": "主题曲", "opening": "片头曲", "ending": "片尾曲", "insert": "插曲", "score": "配乐 / 原声", "any": ""]

    private var want: String {
        let e = need.entities
        var w: [String] = []
        if let s = e.song { w.append("《\(s)》") }
        if let a = e.artist { w.append("\(a) 的歌") }
        if let t = e.workTitle { w.append("《\(t)》" + (Self.role[e.soundtrackType ?? ""] ?? "")) }
        if w.isEmpty, let a = need.artistPreference { w.append("\(a) 的歌") }
        return w.isEmpty ? "你想听的那首歌" : w.joined(separator: " · ")
    }

    var body: some View {
        PageScroll {
            HStack {
                IconLabelButton(icon: "chevron.left", label: "换一种说法") { model.go(.home) }
                Spacer()
            }
            VStack(alignment: .leading, spacing: 2) {
                Text("我听懂你要找什么了").eyebrow()
                Text("还搜不到这首歌").displayTitle()
            }
            VStack(alignment: .leading, spacing: 8) {
                Text("“\(need.text)”").font(.system(size: 17, weight: .medium, design: .rounded)).foregroundStyle(Palette.blueInk)
                Text("你想找的是：\(want)").tiny()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .sketch(Palette.cream, line: Palette.yellow, width: 3, radius: 20, seed: 17)
            VStack(alignment: .leading, spacing: 8) {
                SectionTitle(text: "影视歌曲还不能找")
                Text("现在还没法按影视作品找歌，我们不会拿风格相近的其他歌曲来冒充。可以直接说歌名，比如“我想听《晴天》”。").muted()
                Text("这段时间你也可以说说此刻的心情或场景，我先按那些来推荐。").tiny()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .sketch(.white, line: Palette.blue, width: 2.5, radius: 20, seed: 33)
            Button("说说我的心情") { model.go(.home) }.buttonStyle(PrimaryButtonStyle())
        }
    }
}
