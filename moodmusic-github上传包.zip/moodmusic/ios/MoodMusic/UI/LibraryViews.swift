import SwiftUI

// MARK: - 列表里的一行歌曲（内置歌曲和 Apple Music 歌曲通用）

struct LibItemRow<Trailing: View>: View {
    @Environment(AppModel.self) private var model
    let item: LibItem
    let seed: Int
    let onPlay: () -> Void
    @ViewBuilder var trailing: Trailing

    var body: some View {
        HStack(spacing: 10) {
            Button(action: onPlay) {
                HStack(spacing: 12) {
                    cover.frame(width: 52, height: 52)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(item.title).font(AppFont.display(16)).foregroundStyle(Palette.ink).lineLimit(2)
                        Text(sub).font(.system(size: 12)).foregroundStyle(Palette.muted).lineLimit(1)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("播放 \(item.title)")
            trailing
        }
        .padding(10)
        .sketch(.white, line: Palette.blue, width: 2, radius: 16, seed: seed + 40)
    }

    private var sub: String {
        if item.isApple { return item.artist + (item.collectionName.map { " · 《\($0)》" } ?? "") + " · Apple Music" }
        return item.artist + (item.genre.map { " · \($0)" } ?? "")
    }

    @ViewBuilder private var cover: some View {
        if !item.isApple, let s = model.song(item.id) {
            CoverArt(song: s, corner: 11)
        } else {
            AsyncImage(url: item.artwork.flatMap { URL(string: $0) }) { img in img.resizable().scaledToFill() } placeholder: {
                ZStack { Palette.cream; Image(systemName: "music.note").foregroundStyle(Palette.red) }
            }
            .clipShape(RoundedRectangle(cornerRadius: 11))
        }
    }
}

private struct EmptyBox: View {
    let text: String
    let button: String
    let action: () -> Void
    var body: some View {
        VStack(spacing: 10) {
            Mascot(kind: .sleepy).frame(width: 120, height: 120)
            Text(text).muted().multilineTextAlignment(.center)
            Button(button, action: action).buttonStyle(SecondaryButtonStyle())
        }
        .padding(.vertical, 18).padding(.horizontal, 10)
        .frame(maxWidth: .infinity)
    }
}

// MARK: - 我喜欢的音乐

struct LikedView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.openURL) private var openURL

    var body: some View {
        let list = model.likedEntries
        PageScroll {
            VStack(alignment: .leading, spacing: 2) {
                Text("我喜欢的音乐").eyebrow()
                Text("你点过喜欢的歌").displayTitle()
            }
            Text("推荐里点“喜欢”的歌，和找歌时喜欢的 Apple Music 歌曲，都会放在这里。").muted()
            if list.isEmpty {
                EmptyBox(text: "还没有喜欢的歌。听到喜欢的歌时点一下“喜欢”，它就会出现在这里。", button: "去找歌") { model.go(.home) }
            } else {
                Button { model.playItems(list, 0, title: "我喜欢的音乐") } label: { Label("播放全部", systemImage: "play.fill") }
                    .buttonStyle(PrimaryButtonStyle())
                VStack(spacing: 10) {
                    ForEach(Array(list.enumerated()), id: \.element.key) { i, it in
                        LibItemRow(item: it, seed: i, onPlay: { model.playItems(list, i, title: "我喜欢的音乐") }) {
                            if let u = model.appleMusicURL(it) {
                                IconLabelButton(icon: "arrow.up.right.square", label: "") { openURL(u) }
                                    .accessibilityLabel("在 Apple Music 中打开")
                            }
                            IconLabelButton(icon: "heart.fill", label: "", on: true) {
                                if it.isApple { model.toggleAppleLike(it) } else { model.setFlag(it.id, .like) }
                            }
                            .accessibilityLabel("取消喜欢 \(it.title)")
                        }
                    }
                }
            }
        }
    }
}

// MARK: - 收藏：歌单列表

struct FavoritesView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        PageScroll {
            VStack(alignment: .leading, spacing: 2) {
                Text("我的收藏").eyebrow()
                Text("我的歌单").displayTitle()
            }
            Text("“我的收藏”放的是你收藏的曲库歌曲；也可以自己建歌单，把找到的 Apple Music 歌曲放进去。").muted()
            VStack(spacing: 10) {
                ForEach(model.playlists) { p in
                    let n = model.items(of: p).count
                    Button { model.openPlaylist(p.id) } label: {
                        HStack(spacing: 12) {
                            Image(systemName: p.id == AppModel.defaultPlaylist ? "star.fill" : "music.note.list")
                                .font(.system(size: 20)).foregroundStyle(p.id == AppModel.defaultPlaylist ? Palette.favInk : Palette.red)
                                .frame(width: 44, height: 44)
                                .background(RoundedRectangle(cornerRadius: 11).fill(Palette.cream))
                            VStack(alignment: .leading, spacing: 1) {
                                Text(p.name).font(AppFont.display(17)).foregroundStyle(Palette.ink)
                                Text("\(n) 首" + (p.id == AppModel.defaultPlaylist ? " · 系统歌单" : "")).font(.system(size: 12)).foregroundStyle(Palette.muted)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            Image(systemName: "chevron.right").foregroundStyle(Palette.muted)
                        }
                        .padding(10)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .sketch(.white, line: Palette.blue, width: 2, radius: 16, seed: p.name.count + 60)
                }
            }
            Button("＋ 新建歌单") { model.newPlaylistTapped() }.buttonStyle(SecondaryButtonStyle())
        }
    }
}

// MARK: - 歌单详情

struct PlaylistView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.openURL) private var openURL

    var body: some View {
        if let p = model.playlist(model.plId) {
            let list = model.items(of: p)
            let system = p.id == AppModel.defaultPlaylist
            PageScroll {
                HStack {
                    IconLabelButton(icon: "chevron.left", label: "我的歌单") { model.go(.favorites) }
                    Spacer()
                    Text("\(list.count) 首").tiny()
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(system ? "系统歌单" : "我的歌单").eyebrow()
                    Text(p.name).displayTitle()
                }
                if !system {
                    HStack(spacing: 10) {
                        Button("重命名") { model.renamePlaylistTapped() }.buttonStyle(SecondaryButtonStyle())
                        Button(model.confirmPlDel ? "再点一次确认删除" : "删除歌单") { model.deletePlaylistTapped() }
                            .buttonStyle(SecondaryButtonStyle(tint: Palette.red, line: Palette.red))
                    }
                }
                if list.isEmpty {
                    EmptyBox(text: system ? "还没有收藏。听到喜欢的歌时点一下“收藏”，它就会出现在这里。" : "这个歌单还是空的。在推荐或找歌结果里点“＋ 加入歌单”就能放进来。",
                             button: "去找歌") { model.go(.home) }
                } else {
                    Button { model.playItems(list, 0, title: p.name) } label: { Label("播放全部", systemImage: "play.fill") }
                        .buttonStyle(PrimaryButtonStyle())
                    VStack(spacing: 10) {
                        ForEach(Array(list.enumerated()), id: \.element.key) { i, it in
                            LibItemRow(item: it, seed: i, onPlay: { model.playItems(list, i, title: p.name) }) {
                                IconLabelButton(icon: "play.fill", label: "") { model.playItems(list, i, title: p.name) }
                                    .accessibilityLabel("播放 \(it.title)")
                                if let u = model.appleMusicURL(it) {
                                    IconLabelButton(icon: "arrow.up.right.square", label: "") { openURL(u) }
                                        .accessibilityLabel("在 Apple Music 中打开")
                                }
                                IconLabelButton(icon: "trash", label: "") { model.removeFromPlaylist(it) }
                                    .accessibilityLabel("从歌单移除 \(it.title)")
                            }
                        }
                    }
                }
            }
        } else {
            FavoritesView()
        }
    }
}

// MARK: - 新建 / 重命名歌单

struct NewPlaylistView: View {
    @Environment(AppModel.self) private var model
    @FocusState private var focused: Bool

    var body: some View {
        @Bindable var model = model
        let rename = model.plRenameId != nil
        PageScroll {
            HStack {
                IconLabelButton(icon: "chevron.left", label: "返回") { model.cancelNewPlaylist() }
                Spacer()
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(rename ? "重命名歌单" : "新建歌单").eyebrow()
                Text("给歌单起个名字").displayTitle()
            }
            VStack(alignment: .trailing, spacing: 6) {
                TextField("比如：下班路上", text: $model.plName)
                    .font(.system(size: 16))
                    .focused($focused)
                    .submitLabel(.done)
                    .onSubmit { model.savePlaylistName() }
                    .onChange(of: model.plName) { _, v in if v.count > 30 { model.plName = String(v.prefix(30)) } }
                Text("\(model.plName.count)/30").tiny()
            }
            .padding(14)
            .sketch(.white, line: Palette.blue, width: 3, radius: 18, seed: 13)
            if let it = model.pendingItem, !rename {
                Text("建好后会回到“加入歌单”，把《\(it.title)》放进去。").tiny()
            }
            Button(rename ? "保存名称" : "创建歌单") { focused = false; model.savePlaylistName() }.buttonStyle(PrimaryButtonStyle())
            Button("取消") { focused = false; model.cancelNewPlaylist() }.buttonStyle(GhostButtonStyle()).frame(maxWidth: .infinity)
        }
        .onAppear { focused = true }
    }
}

// MARK: - 加入歌单

struct AddToView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        PageScroll {
            HStack {
                IconLabelButton(icon: "chevron.left", label: "返回") { model.cancelAddTo() }
                Spacer()
            }
            VStack(alignment: .leading, spacing: 2) {
                Text("加入歌单").eyebrow()
                Text(model.pendingItem.map { "《\($0.title)》" } ?? "选一个歌单").displayTitle()
            }
            if let it = model.pendingItem {
                Text(it.artist + (it.isApple ? " · Apple Music 歌曲（只能放进自建歌单）" : "")).muted()
            }
            VStack(spacing: 10) {
                ForEach(model.playlists) { p in
                    let has = model.pendingItem.map { pi in model.items(of: p).contains { $0.key == pi.key } } ?? false
                    let blocked = p.id == AppModel.defaultPlaylist && model.pendingItem?.isApple == true
                    Button { model.addPending(to: p.id) } label: {
                        HStack {
                            Text(p.name).font(AppFont.display(17)).foregroundStyle(blocked ? Palette.muted : Palette.ink)
                            Spacer()
                            Text(has ? "已在歌单里" : blocked ? "只收曲库歌曲" : "\(model.items(of: p).count) 首").tiny()
                        }
                        .padding(14)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .sketch(.white, line: Palette.blue, width: 2, radius: 16, seed: p.name.count + 70)
                }
            }
            Button("＋ 新建歌单") { model.newPlaylistTapped() }.buttonStyle(SecondaryButtonStyle())
        }
    }
}

// MARK: - 我的

struct ProfileView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.openURL) private var openURL

    var body: some View {
        let tm = model.taste
        let gs = Vocab.genres.map { ($0, tm.genre($0)) }.filter { $0.1 > 0 }.sorted { $0.1 > $1.1 }.prefix(6)
        let mx = max(1, gs.map(\.1).max() ?? 1)
        let artists = model.catalog.artists.map { ($0, tm.artist($0)) }.filter { $0.1 > 0 }.sorted { $0.1 > $1.1 }.prefix(8)
        PageScroll {
            VStack(alignment: .leading, spacing: 2) {
                Text("我的").eyebrow()
                Text("我的音乐口味").displayTitle()
            }

            card {
                SectionTitle(text: "Taste Profile · 偏好曲风")
                if gs.isEmpty {
                    Text("还没有偏好数据。在推荐里点“喜欢”或“收藏”，这里就会慢慢长出来。").muted()
                } else {
                    VStack(spacing: 7) {
                        ForEach(Array(gs.enumerated()), id: \.offset) { i, g in
                            HStack(spacing: 8) {
                                Text(g.0).font(.system(size: 13)).frame(width: 56, alignment: .leading)
                                ProgressBar(fraction: g.1 / mx, height: 12, knob: false, fill: i % 2 == 0 ? Palette.red : Palette.blue)
                                Text(String(format: "%.1f", g.1)).font(.system(size: 13, weight: .semibold).monospacedDigit())
                                    .foregroundStyle(Palette.muted).frame(width: 34, alignment: .trailing)
                            }
                        }
                    }
                }
                if !artists.isEmpty {
                    Text("常听的歌手").tiny()
                    FlowLayout(spacing: 8) {
                        ForEach(Array(artists), id: \.0) { a in
                            Text(a.0).font(.system(size: 14)).padding(.vertical, 6).padding(.horizontal, 12)
                                .sketch(.white, line: Palette.blue, width: 1.5, radius: 16, seed: a.0.count)
                        }
                    }
                }
            }

            // 开发用：只在 Xcode 直接安装（Debug）时显示；TestFlight / App Store 版本用户看不到
            #if DEBUG
            card {
                SectionTitle(text: "模型 B · 歌曲标签")
                let builtIn = model.catalog.songs.filter { model.tags($0.id) != nil }.count
                let apple = model.tagStore.items.keys.filter { model.tags($0) != nil }.count
                Text(model.tagger
                     ? "模型 B 会给曲库里的每首歌分析适合什么人、什么情绪和场景，推荐时直接读取。你搜到、喜欢、加进歌单的歌，以及每天的 Apple Music 热门榜，也会进入曲库。"
                     : "服务器上的模型 B 还没接好，现在内置歌曲先用原来的标签，搜到的歌暂时不参与推荐。").muted()
                Text("已打好标签：内置 \(builtIn)/\(model.catalog.songs.count) 首 · 搜到、热门榜和公共曲库加入的 \(apple)/\(model.tagStore.items.count) 首").tiny()
                Text("公共曲库：\(model.sharedStatus)").tiny()
            }
            #endif

            card {
                SectionTitle(text: "Apple Music")
                Text(model.music.statusText).muted()
                #if DEBUG
                Text("查歌情况：\(model.music.lastLookup)").tiny()
                #endif
                switch model.music.access {
                case .unknown:
                    Button("连接 Apple Music") { model.connectAppleMusic() }.buttonStyle(SecondaryButtonStyle())
                case .notAuthorized:
                    Button("打开系统设置") {
                        if let u = URL(string: UIApplication.openSettingsURLString) { openURL(u) }
                    }.buttonStyle(SecondaryButtonStyle())
                case .noSubscription:
                    Button("重新检查订阅") { model.connectAppleMusic() }.buttonStyle(SecondaryButtonStyle())
                case .subscriber:
                    EmptyView()
                }
            }

            card {
                SectionTitle(text: "本地数据与隐私")
                Text("不需要注册账号。你的喜欢、歌单和听歌偏好只保存在这台手机上，删除 App 或点下面的按钮后会被清除。").muted()
                Button("查看隐私政策") { openURL(AppConfig.privacyPolicyURL) }.buttonStyle(SecondaryButtonStyle())
                Button(model.confirmClear ? "再点一次，确认清除全部数据" : "清除本地数据") { model.clearTapped() }
                    .buttonStyle(SecondaryButtonStyle(tint: Palette.red, line: Palette.red))
            }

            Text("音乐由 Apple Music 提供。版本 \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0")").tiny()
        }
    }

    private func card<C: View>(@ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 12) { content() }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .sketch(.white, line: Palette.blue, width: 2.5, radius: 20, seed: 29)
    }
}
