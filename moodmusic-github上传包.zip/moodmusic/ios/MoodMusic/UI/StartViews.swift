import SwiftUI

// MARK: - 封面

struct CoverView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 10) {
                Logo(size: 44)
                Text("your mood · your music").font(AppFont.hand(18)).kerning(2).foregroundStyle(.white)
            }
            .frame(maxWidth: .infinity)
            .padding(.top, 24).padding(.bottom, 22)
            .background(BandBackground().ignoresSafeArea(edges: .top))

            ScrollView {
                VStack(spacing: 14) {
                    Mascot(kind: .sing, bob: true).frame(width: 190, height: 190).padding(.top, 8)
                    Text("让音乐懂你的心情")
                        .font(AppFont.display(27)).foregroundStyle(Palette.red)
                        .multilineTextAlignment(.center).lineSpacing(4)
                    Text("不只看你长期喜欢什么，也听懂你现在的心情、身处的场景，和你想在听完后变成的样子。")
                        .font(.system(size: 14)).foregroundStyle(Palette.ink)
                        .multilineTextAlignment(.center)
                        .padding(.vertical, 8).padding(.horizontal, 12)
                        .background(RoundedRectangle(cornerRadius: 14).fill(Palette.paper.opacity(0.92)))
                    Spacer(minLength: 12)
                    VStack(spacing: 6) {
                        Button("开始听歌 →") { model.go(.home) }.buttonStyle(PrimaryButtonStyle())
                        Text("说出你的心情 · AI 为你推荐好歌").tiny().padding(.top, 4)
                        Text("无需注册登录 · 偏好和歌单只保存在这台设备上").tiny()
                    }
                }
                .padding(.horizontal, 24).padding(.vertical, 18)
                .frame(maxWidth: 560)
                .frame(maxWidth: .infinity)
            }
            .background(Gingham(base: .white, size: 40))
            CheckStrip()
        }
        .background(Color.white.ignoresSafeArea(edges: .bottom))
    }
}

// MARK: - 首页：场景 + 一句话

struct HomeView: View {
    @Environment(AppModel.self) private var model
    @FocusState private var focused: Bool

    private let examples = ["刚下班，有点累，想听舒服一点但不要太丧的歌", "失恋了，今晚想哭一场", "要写报告了，需要专注，不要说唱", "周末去跑步，来点燃的", "我想听周杰伦的《晴天》"]

    var body: some View {
        @Bindable var model = model
        PageScroll {
            VStack(alignment: .leading, spacing: 2) {
                Text("Hi，今天的耳朵想要什么？").eyebrow()
                Text("此刻，你想听点什么？").displayTitle()
            }
            VStack(alignment: .leading, spacing: 10) {
                SectionTitle(text: "选一个场景")
                FlowLayout {
                    ForEach(SceneChip.all) { c in
                        ChipButton(label: c.label, selected: model.chip == c) { model.toggleChip(c) }
                    }
                }
            }
            VStack(alignment: .leading, spacing: 10) {
                SectionTitle(text: "或者直接告诉我你的状态")
                VStack(alignment: .leading, spacing: 8) {
                    Text("现在的心情、在做什么、想听完变成什么样，或者直接说想听哪首歌").tiny().padding(.horizontal, 6)
                    TextField("比如：刚下班，有点累，想听舒服一点但不要太丧的歌", text: $model.text, axis: .vertical)
                        .lineLimit(3...6)
                        .font(.system(size: 15))
                        .foregroundStyle(Palette.ink)
                        .padding(.horizontal, 6)
                        .frame(minHeight: 84, alignment: .topLeading)
                        .focused($focused)
                    HStack {
                        Text("时间会自动考虑：现在是\(NeedParser.timeSlot())").tiny().padding(.leading, 6)
                        Spacer()
                        Button { focused = false; model.voiceTapped() } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "mic.fill").font(.system(size: 15))
                                Text(model.listening ? "正在听…" : "说一说").font(.system(size: 14, weight: .bold))
                            }
                            .foregroundStyle(model.listening ? .white : Palette.red)
                            .padding(.vertical, 7).padding(.horizontal, 14)
                            .sketch(model.listening ? Palette.red : Palette.cream, line: model.listening ? Palette.ink : Palette.red, width: 2.5, radius: 18, seed: 9)
                            .scaleEffect(model.listening ? 1.05 : 1)
                            .animation(model.listening ? .easeInOut(duration: 0.5).repeatForever() : .default, value: model.listening)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("语音输入")
                    }
                }
                .padding(.horizontal, 12).padding(.top, 12).padding(.bottom, 10)
                .sketch(.white, line: Palette.blue, width: 3, radius: 22, seed: 13)

                VStack(alignment: .leading, spacing: 6) {
                    Text("试试这样说").tiny()
                    ForEach(examples, id: \.self) { e in
                        Button { model.text = e } label: {
                            HStack(alignment: .firstTextBaseline, spacing: 8) {
                                Text("♪").font(.system(size: 14, weight: .bold)).foregroundStyle(Palette.red)
                                Text(e).font(.system(size: 14)).foregroundStyle(Palette.blueInk).multilineTextAlignment(.leading)
                            }
                            .padding(.vertical, 4)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            Button("为我推荐 5 首歌") { focused = false; model.recommendTapped() }.buttonStyle(PrimaryButtonStyle())
            if let last = model.user.history.last {
                Text("上次（\(Self.shortDate(last.ts))）：\(last.text.isEmpty ? (last.chip ?? "按口味推荐") : last.text)").tiny()
            }
        }
    }

    static func shortDate(_ ms: Double) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "zh_CN")
        f.dateFormat = "M月d日 HH:mm"
        return f.string(from: Date(timeIntervalSince1970: ms / 1000))
    }
}

// MARK: - 理解中

struct ThinkingView: View {
    @Environment(AppModel.self) private var model
    @State private var lit = 0
    private var lines: [String] {
        ["识别当前情绪和想要的情绪", "判断场景、时间和要避开的风格", "在 \(model.catalog.songs.count) 首曲库里找一找", "为你挑选最合适的 5 首"]
    }

    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            Mascot(kind: .happy, bob: true).frame(width: 170, height: 170)
            Text("正在理解你此刻的需求").font(AppFont.display(24)).foregroundStyle(Palette.ink)
            VStack(spacing: 6) {
                ForEach(Array(lines.enumerated()), id: \.offset) { i, l in
                    Text(l).font(AppFont.hand(19))
                        .foregroundStyle(i < lit ? Palette.blueInk : Palette.muted)
                        .opacity(i < lit ? 1 : 0.25)
                }
            }
            Spacer()
        }
        .padding(24)
        .frame(maxWidth: .infinity)
        .task {
            for i in 1...4 {
                try? await Task.sleep(for: .milliseconds(260))
                withAnimation(.easeOut(duration: 0.3)) { lit = i }
            }
        }
    }
}
