import SwiftUI

struct PlayerView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        if let id = model.queue[safe: model.qi], let s = model.song(id) {
            let m = model.meta[id]
            let apple = model.appleItem(id)
            let note = model.fbNote(id)
            let on = model.isPlaying && model.currentId == id
            PageScroll {
                HStack {
                    let back: (String, Page) = m != nil && !model.batch.isEmpty ? ("推荐列表", .results)
                        : model.queueTitle == "找到的歌曲" && model.need != nil ? ("找歌结果", .results)
                        : model.queueTitle == "我喜欢的音乐" ? ("我喜欢的音乐", .liked)
                        : model.plId != nil && model.queueTitle != "推荐" ? ("歌单", .playlist) : ("首页", .home)
                    IconLabelButton(icon: "chevron.left", label: back.0) { model.go(back.1) }
                    Spacer()
                    Text("\(m.map { SlotText.of($0.slot) } ?? model.queueTitle) · \(model.qi + 1)/\(model.queue.count)").tiny()
                }
                Turntable(song: s, spinning: on)
                    .frame(maxWidth: .infinity)
                VStack(spacing: 2) {
                    Text(s.title).font(AppFont.display(26)).foregroundStyle(Palette.ink).multilineTextAlignment(.center)
                    if let apple {
                        Text(s.artist + (apple.collectionName.map { " · 《\($0)》" } ?? "")).muted().multilineTextAlignment(.center)
                    } else {
                        Text("\(s.artist) · \(s.genre)").muted()
                    }
                }
                .frame(maxWidth: .infinity)
                if let m {
                    Text(m.reason).font(.system(size: 13.5)).foregroundStyle(Palette.ink)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.vertical, 8).padding(.horizontal, 10)
                        .background(RoundedRectangle(cornerRadius: 12).fill(Palette.cream))
                }
                TimelineView(.periodic(from: .now, by: 0.25)) { _ in
                    let pos = model.currentId == id ? model.audio.position : 0
                    let dur = model.currentId == id ? model.audio.duration : Double(s.dur)
                    VStack(spacing: 6) {
                        ProgressBar(fraction: pos / max(1, dur)) { f in model.seek(fraction: f) }
                            .accessibilityElement()
                            .accessibilityLabel("播放进度")
                            .accessibilityValue(fmtTime(pos))
                            .accessibilityAdjustableAction { dir in
                                let step = 5 / max(1, dur)
                                let f = pos / max(1, dur)
                                model.seek(fraction: dir == .increment ? f + step : f - step)
                            }
                        HStack {
                            Text(fmtTime(pos))
                            Spacer()
                            Text(fmtTime(dur))
                        }
                        .font(.system(size: 12).monospacedDigit())
                        .foregroundStyle(Palette.muted)
                    }
                }
                HStack(spacing: 28) {
                    roundButton("backward.end.fill", "上一首") { model.prev() }
                    Button { model.toggle() } label: {
                        Image(systemName: on ? "pause.fill" : "play.fill")
                            .font(.system(size: 30)).foregroundStyle(.white)
                            .frame(width: 76, height: 76)
                            .background(Circle().fill(Palette.red))
                            .overlay(RoughRect(radius: 38, seed: 3).stroke(Palette.ink, lineWidth: 3))
                            .background(Circle().fill(Palette.redInk).offset(y: 5))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(on ? "暂停" : "播放")
                    roundButton("forward.end.fill", "下一首") { model.step(1) }
                }
                .frame(maxWidth: .infinity)
                if let apple {
                    AppleSongActions(item: apple)
                } else {
                    if !note.isEmpty { FeedbackNote(text: note).frame(maxWidth: .infinity) }
                    FeedbackRow(id: id, vertical: true)
                    MuteRow(song: s, showAdd: true).frame(maxWidth: .infinity, alignment: .center)
                }
                VStack(alignment: .leading, spacing: 6) {
                    SectionTitle(text: "播放队列")
                    ForEach(Array(model.queue.enumerated()), id: \.offset) { i, q in
                        if let qs = model.song(q) {
                            Button { model.jump(i) } label: {
                                HStack(spacing: 10) {
                                    CoverArt(song: qs, corner: 9).frame(width: 40, height: 40)
                                    VStack(alignment: .leading, spacing: 0) {
                                        Text(qs.title).font(.system(size: 14, weight: .semibold)).lineLimit(1)
                                        Text(qs.artist).font(.system(size: 12)).foregroundStyle(Palette.muted)
                                    }
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    Text(model.meta[q].map { SlotText.of($0.slot) } ?? "").tiny()
                                }
                                .foregroundStyle(Palette.ink)
                                .padding(6)
                                .background(RoundedRectangle(cornerRadius: 12).fill(i == model.qi ? Palette.cream : .clear))
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                if model.loadingId == id {
                    Text("正在从 Apple Music 查找这首歌…").tiny()
                } else if model.currentId == id {
                    switch model.audio.kind {
                    case .appleMusic: Text("正在通过 Apple Music 播放完整歌曲。").tiny()
                    case .preview: Text("Apple Music 30 秒试听片段。连接有订阅的 Apple ID 后可以听完整歌曲。").tiny()
                    case .synth: EmptyView()
                    }
                }
            }
        } else {
            HomeView()
        }
    }

    private func roundButton(_ icon: String, _ label: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon).font(.system(size: 26)).foregroundStyle(Palette.ink).frame(width: 48, height: 48).contentShape(Circle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

/// 搜索找到的 Apple Music 歌曲：喜欢 / 加入歌单 / 在 Apple Music 中打开
private struct AppleSongActions: View {
    @Environment(AppModel.self) private var model
    @Environment(\.openURL) private var openURL
    let item: LibItem

    var body: some View {
        let liked = model.isAppleLiked(item.id)
        HStack(spacing: 4) {
            IconLabelButton(icon: liked ? "heart.fill" : "heart", label: liked ? "已喜欢" : "喜欢", on: liked, vertical: true) { model.toggleAppleLike(item) }
            IconLabelButton(icon: "plus.circle", label: "加入歌单", vertical: true) { model.addToPlaylist(item) }
            if let u = model.appleMusicURL(item) {
                IconLabelButton(icon: "arrow.up.right.square", label: "Apple Music", vertical: true) { openURL(u) }
            }
        }
    }
}

// MARK: - 唱片机

struct Turntable: View {
    let song: Song
    let spinning: Bool
    @State private var angle: Double = 0
    @State private var last = Date()

    var body: some View {
        let size: CGFloat = 240
        ZStack(alignment: .topTrailing) {
            TimelineView(.animation(paused: !spinning)) { ctx in
                disc(size: size)
                    .rotationEffect(.degrees(angle))
                    .onChange(of: ctx.date) { _, now in
                        angle = (angle + now.timeIntervalSince(last) * 60).truncatingRemainder(dividingBy: 360)   // 6 秒一圈
                        last = now
                    }
            }
            Image("tonearm")
                .resizable().scaledToFit()
                .frame(width: size * 0.34)
                .rotationEffect(.degrees(spinning ? 6 : -14), anchor: UnitPoint(x: 0.8, y: 0.12))
                .offset(x: 8, y: -10)
                .animation(.easeInOut(duration: 0.5), value: spinning)
        }
        .frame(width: size, height: size)
        .padding(.top, 6)
        .onChange(of: spinning) { _, _ in last = Date() }
        .accessibilityHidden(true)
    }

    private func disc(size: CGFloat) -> some View {
        ZStack {
            Circle().fill(Palette.ink.opacity(0.15)).offset(y: 8)
            Canvas { ctx, sz in
                let c = CGPoint(x: sz.width / 2, y: sz.height / 2)
                var r = sz.width / 2
                var dark = true
                while r > 0 {
                    ctx.fill(Path(ellipseIn: CGRect(x: c.x - r, y: c.y - r, width: 2 * r, height: 2 * r)),
                             with: .color(dark ? Color(hex: 0x232634) : Color(hex: 0x2E3242)))
                    r -= 2; dark.toggle()
                }
            }
            .clipShape(Circle())
            CoverArt(song: song, corner: size)
                .frame(width: size * 0.42, height: size * 0.42)
                .clipShape(Circle())
                .overlay(Circle().stroke(Palette.paper, lineWidth: 4))
        }
        .frame(width: size, height: size)
    }
}
