import SwiftUI
import CoreText

// MARK: - 配色：红 / 黄 / 蓝 + 野餐格纹（与网页版一致）

extension Color {
    init(hex: UInt32, alpha: Double = 1) {
        self.init(.sRGB, red: Double((hex >> 16) & 0xFF) / 255, green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255, opacity: alpha)
    }
}

enum Palette {
    static let red = Color(hex: 0xC8102E)
    static let redInk = Color(hex: 0x9E0B22)
    static let yellow = Color(hex: 0xFFD84D)
    static let cream = Color(hex: 0xFFF4CC)
    static let blue = Color(hex: 0x1A8FE3)
    static let blueInk = Color(hex: 0x0B5FA5)
    static let sky = Color(hex: 0x8EC9F2)
    static let coverCream = Color(hex: 0xFFF1B8)
    static let ink = Color(hex: 0x1F2230)
    static let muted = Color(hex: 0x6E6655)
    static let paper = Color(hex: 0xFFFDF6)
    static let table = Color(hex: 0xFFFBEA)
    static let check = Color(hex: 0xFFCC33, alpha: 0.40)
    static let track = Color(hex: 0xF1E8C8)
    static let dash = Color(hex: 0xE8D9A6)
    static let safeBg = Color(hex: 0xDDEFFC)
    static let exploreInk = Color(hex: 0x6B4A00)
    static let favInk = Color(hex: 0xB07A00)
}

// MARK: - 字体：ZCOOL 快乐体做标题，Gaegu 做手写英文，正文用系统字体

enum AppFont {
    static func display(_ size: CGFloat) -> Font { .custom("ZCOOLKuaiLe-Regular", size: size, relativeTo: .title2) }
    static func hand(_ size: CGFloat) -> Font { .custom("Gaegu-Bold", size: size, relativeTo: .headline) }
    static func body(_ size: CGFloat = 15, weight: Font.Weight = .regular) -> Font { .system(size: size, weight: weight) }

    /// 启动时注册打包进来的字体（不用改 Info.plist）
    static func registerBundledFonts() {
        let urls = (Bundle.main.urls(forResourcesWithExtension: "ttf", subdirectory: nil) ?? [])
            + (Bundle.main.urls(forResourcesWithExtension: "ttf", subdirectory: "Fonts") ?? [])
        for url in urls { CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil) }
    }
}

// MARK: - 手绘描边：在圆角矩形轮廓上加平滑抖动，模拟网页版的 feDisplacementMap 效果

struct RoughRect: Shape {
    var radius: CGFloat
    var seed: Int = 7
    var amplitude: CGFloat = 1.4

    func path(in rect: CGRect) -> Path {
        let w = rect.width, h = rect.height
        guard w > 2, h > 2 else { return Path(rect) }
        let r = min(radius, w / 2, h / 2)
        let straightW = w - 2 * r, straightH = h - 2 * r
        let arc = CGFloat.pi / 2 * r
        let perimeter = 2 * straightW + 2 * straightH + 4 * arc
        let n = max(24, Int(perimeter / 7))
        let p1 = CGFloat(seed % 97) * 0.37, p2 = CGFloat(seed % 53) * 1.13, p3 = CGFloat(seed % 31) * 2.07

        // 沿轮廓取点 + 外法线方向
        func sample(_ s0: CGFloat) -> (CGPoint, CGVector) {
            var s = s0.truncatingRemainder(dividingBy: perimeter)
            if s < 0 { s += perimeter }
            let x0 = rect.minX, y0 = rect.minY
            // 上边
            if s < straightW { return (CGPoint(x: x0 + r + s, y: y0), CGVector(dx: 0, dy: -1)) }
            s -= straightW
            if s < arc { let a = -CGFloat.pi / 2 + s / r; return (CGPoint(x: x0 + w - r + r * cos(a), y: y0 + r + r * sin(a)), CGVector(dx: cos(a), dy: sin(a))) }
            s -= arc
            if s < straightH { return (CGPoint(x: x0 + w, y: y0 + r + s), CGVector(dx: 1, dy: 0)) }
            s -= straightH
            if s < arc { let a = s / r; return (CGPoint(x: x0 + w - r + r * cos(a), y: y0 + h - r + r * sin(a)), CGVector(dx: cos(a), dy: sin(a))) }
            s -= arc
            if s < straightW { return (CGPoint(x: x0 + w - r - s, y: y0 + h), CGVector(dx: 0, dy: 1)) }
            s -= straightW
            if s < arc { let a = CGFloat.pi / 2 + s / r; return (CGPoint(x: x0 + r + r * cos(a), y: y0 + h - r + r * sin(a)), CGVector(dx: cos(a), dy: sin(a))) }
            s -= arc
            if s < straightH { return (CGPoint(x: x0, y: y0 + h - r - s), CGVector(dx: -1, dy: 0)) }
            s -= straightH
            let a = CGFloat.pi + s / r
            return (CGPoint(x: x0 + r + r * cos(a), y: y0 + r + r * sin(a)), CGVector(dx: cos(a), dy: sin(a)))
        }

        var pts: [CGPoint] = []
        for i in 0..<n {
            let s = perimeter * CGFloat(i) / CGFloat(n)
            let (pt, nv) = sample(s)
            let off = amplitude * (0.6 * sin(s * 0.045 + p1) + 0.3 * sin(s * 0.11 + p2) + 0.1 * sin(s * 0.23 + p3))
            pts.append(CGPoint(x: pt.x + nv.dx * off, y: pt.y + nv.dy * off))
        }
        // 用中点做二次曲线，线条更顺
        var path = Path()
        func mid(_ a: CGPoint, _ b: CGPoint) -> CGPoint { CGPoint(x: (a.x + b.x) / 2, y: (a.y + b.y) / 2) }
        path.move(to: mid(pts[n - 1], pts[0]))
        for i in 0..<n { path.addQuadCurve(to: mid(pts[i], pts[(i + 1) % n]), control: pts[i]) }
        path.closeSubpath()
        return path
    }
}

extension View {
    /// 手绘风格卡片：填充 + 抖动描边
    func sketch(_ fill: Color = .white, line: Color = Palette.blue, width: CGFloat = 2.5, radius: CGFloat = 20, seed: Int = 7) -> some View {
        self
            .background(RoundedRectangle(cornerRadius: radius, style: .continuous).fill(fill))
            .overlay(RoughRect(radius: radius, seed: seed).stroke(line, style: StrokeStyle(lineWidth: width, lineCap: .round, lineJoin: .round)))
    }
}

// MARK: - 野餐格纹背景

struct Gingham: View {
    var base: Color = Palette.table
    var check: Color = Palette.check
    var size: CGFloat = 56

    var body: some View {
        Canvas { ctx, sz in
            ctx.fill(Path(CGRect(origin: .zero, size: sz)), with: .color(base))
            var x: CGFloat = 0
            while x < sz.width { ctx.fill(Path(CGRect(x: x, y: 0, width: size / 2, height: sz.height)), with: .color(check)); x += size }
            var y: CGFloat = 0
            while y < sz.height { ctx.fill(Path(CGRect(x: 0, y: y, width: sz.width, height: size / 2)), with: .color(check)); y += size }
        }
    }
}

/// 红色页眉：细白竖线
struct BandBackground: View {
    var body: some View {
        Canvas { ctx, sz in
            ctx.fill(Path(CGRect(origin: .zero, size: sz)), with: .color(Palette.red))
            var x: CGFloat = 46
            while x < sz.width { ctx.fill(Path(CGRect(x: x, y: 0, width: 1, height: sz.height)), with: .color(.white.opacity(0.55))); x += 47 }
        }
    }
}

/// 底部黄白小格条
struct CheckStrip: View {
    var body: some View {
        Canvas { ctx, sz in
            ctx.fill(Path(CGRect(origin: .zero, size: sz)), with: .color(Palette.yellow))
            var x: CGFloat = 0
            while x < sz.width { ctx.fill(Path(CGRect(x: x, y: 0, width: 11, height: sz.height)), with: .color(.white)); x += 22 }
        }
        .frame(height: 22)
        .opacity(0.9)
    }
}

// MARK: - 按钮样式

struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(AppFont.body(16, weight: .bold))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14).padding(.horizontal, 18)
            .sketch(Palette.red, line: Palette.ink, width: 3, radius: 30, seed: 11)
            .background(Capsule().fill(Palette.redInk).offset(y: configuration.isPressed ? 2 : 5))
            .offset(y: configuration.isPressed ? 3 : 0)
            .rotationEffect(.degrees(configuration.isPressed ? -0.5 : 0))
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

struct SecondaryButtonStyle: ButtonStyle {
    var tint: Color = Palette.blueInk
    var line: Color = Palette.blue
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(AppFont.body(16, weight: .bold))
            .foregroundStyle(tint)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14).padding(.horizontal, 18)
            .sketch(.white, line: line, width: 3, radius: 30, seed: 5)
            .offset(y: configuration.isPressed ? 2 : 0)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

struct GhostButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(AppFont.body(15, weight: .medium))
            .foregroundStyle(Palette.muted)
            .padding(8)
            .opacity(configuration.isPressed ? 0.6 : 1)
    }
}

// MARK: - 常用文字样式

extension Text {
    func eyebrow() -> some View { self.font(AppFont.hand(18)).foregroundStyle(Palette.red) }
    func displayTitle(_ size: CGFloat = 28) -> some View { self.font(AppFont.display(size)).foregroundStyle(Palette.ink) }
    func tiny() -> some View { self.font(.system(size: 12)).foregroundStyle(Palette.muted) }
    func muted() -> some View { self.font(.system(size: 14)).foregroundStyle(Palette.muted) }
}
