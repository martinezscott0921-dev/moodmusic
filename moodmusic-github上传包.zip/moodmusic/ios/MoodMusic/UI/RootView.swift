import SwiftUI

struct RootView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        ZStack(alignment: .top) {
            Palette.paper.ignoresSafeArea()
            VStack(spacing: 0) {
                if model.page != .cover { HeaderBand() }
                content
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .transition(.opacity)
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                if ![Page.cover, .thinking].contains(model.page) { FooterBar() }
            }
            if let t = model.toast {
                Text(t)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                    .padding(.vertical, 10).padding(.horizontal, 16)
                    .background(Capsule().fill(Palette.ink.opacity(0.92)))
                    .padding(.horizontal, 24)
                    .frame(maxHeight: .infinity, alignment: .bottom)
                    .padding(.bottom, 130)
                    .transition(.opacity.combined(with: .move(edge: .bottom)))
                    .allowsHitTesting(false)
                    .accessibilityAddTraits(.updatesFrequently)
            }
        }
        .animation(.easeOut(duration: 0.2), value: model.toast)
        .preferredColorScheme(.light)
        .task { await model.boot() }
    }

    @ViewBuilder private var content: some View {
        switch model.page {
        case .cover: CoverView()
        case .home: HomeView()
        case .thinking: ThinkingView()
        case .clarify: ClarifyView()
        case .results: ResultsView()
        case .player: PlayerView()
        case .liked: LikedView()
        case .favorites: FavoritesView()
        case .playlist: PlaylistView()
        case .newPlaylist: NewPlaylistView()
        case .addTo: AddToView()
        case .profile: ProfileView()
        }
    }
}

// MARK: - 底部：迷你播放器 + 四个标签

struct FooterBar: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        VStack(spacing: 0) {
            if let s = model.currentSong, model.page != .player { mini(s) }
            HStack {
                tab(.home, "house", "首页", active: [Page.home, .results, .player, .clarify].contains(model.page))
                tab(.liked, "heart", "喜欢", active: model.page == .liked)
                tab(.favorites, "star", "收藏", active: [Page.favorites, .playlist, .newPlaylist, .addTo].contains(model.page))
                tab(.profile, "person", "我的", active: model.page == .profile)
            }
            .padding(.top, 8)
            .overlay(alignment: .top) {
                Line().stroke(Palette.dash, style: StrokeStyle(lineWidth: 2, dash: [6, 4])).frame(height: 2)
            }
        }
        .background(Palette.paper.ignoresSafeArea(edges: .bottom))
    }

    private func mini(_ s: Song) -> some View {
        HStack(spacing: 10) {
            CoverArt(song: s, corner: 9).frame(width: 40, height: 40)
            Button { model.go(.player) } label: {
                VStack(alignment: .leading, spacing: 1) {
                    Text(s.title).font(.system(size: 14, weight: .bold)).lineLimit(1)
                    Text(s.artist).font(.system(size: 12)).foregroundStyle(Palette.muted).lineLimit(1)
                    TimelineView(.periodic(from: .now, by: 0.5)) { _ in
                        ProgressBar(fraction: model.audio.position / max(1, model.audio.duration), height: 3, knob: false)
                    }
                    .padding(.top, 3)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .foregroundStyle(Palette.ink)
            }
            .buttonStyle(.plain)
            Button { model.toggle() } label: {
                Image(systemName: model.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 16)).foregroundStyle(.white)
                    .frame(width: 40, height: 40).background(Circle().fill(Palette.red))
            }
            .buttonStyle(.plain)
            .accessibilityLabel(model.isPlaying ? "暂停" : "播放")
        }
        .padding(8).padding(.leading, 2)
        .sketch(.white, line: Palette.blue, width: 2.5, radius: 16, seed: 21)
        .padding(.horizontal, 12).padding(.bottom, 8).padding(.top, 6)
    }

    private func tab(_ p: Page, _ icon: String, _ label: String, active: Bool) -> some View {
        Button { model.go(p) } label: {
            VStack(spacing: 1) {
                Image(systemName: active ? icon + ".fill" : icon).font(.system(size: 20))
                Text(label).font(.system(size: 12, weight: active ? .bold : .regular))
            }
            .foregroundStyle(active ? Palette.red : Palette.muted)
            .frame(maxWidth: .infinity)
            .padding(.bottom, 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(active ? .isSelected : [])
    }
}

private struct Line: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: rect.minX, y: rect.midY))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.midY))
        return p
    }
}
