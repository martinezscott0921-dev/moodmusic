import Foundation
import Observation
import SwiftUI

enum Page: Equatable {
    case cover, home, thinking, clarify, results, player, liked, favorites, playlist, newPlaylist, addTo, profile
}

/// 结果页显示什么：推荐的 5 首 / 找指定歌曲的结果 / 影视作品的歌（暂不支持）
enum ResultKind: Equatable { case recommend, search, pending }

/// 全局状态与行为（对应网页 2.0 的 ui / S 对象和事件处理）
@MainActor
@Observable
final class AppModel {
    // 数据
    private(set) var catalog = Catalog.builtIn
    private(set) var user = UserData.load()

    // 页面
    var page: Page = .cover

    // 首页输入
    var chip: SceneChip?
    var text = ""
    private(set) var listening = false

    // 推荐 / 找歌
    private(set) var need: Need?
    private(set) var mode: APIClient.Mode = .local
    private(set) var batch: [Recommendation] = []
    private var seen: [String] = []
    private(set) var batchNo = 0
    private(set) var busy = false
    private(set) var resultKind: ResultKind = .recommend
    private(set) var searchResult: AppleMusic.SearchResult?
    private var clarifyAnswered = false
    private var askNow = false

    // 播放
    private(set) var queue: [String] = []
    private(set) var qi = 0
    private(set) var meta: [String: Recommendation] = [:]
    private(set) var queueTitle = "推荐"
    private(set) var currentId: String?
    private(set) var isPlaying = false
    /// 正在查歌 / 准备播放
    private(set) var loadingId: String?
    /// 搜索找到的 Apple Music 歌曲（不在内置曲库里），播放时临时登记
    private var extraSongs: [String: Song] = [:]
    private var extraItems: [String: LibItem] = [:]

    // 歌单页面
    private(set) var plId: String?
    var plName = ""
    private(set) var plRenameId: String?
    private(set) var pendingItem: LibItem?
    private var addFrom: Page = .home
    private(set) var confirmPlDel = false

    // 模型 B（歌曲标签）
    private(set) var tagStore = TagStore.load()
    private(set) var tagger = false
    /// 服务器有公共曲库：大家搜到并打好标签的歌，所有人都能被推荐到
    private(set) var sharedCatalog = false
    /// 公共曲库的同步情况（只在 Debug 版的“我的”页显示，方便排查）
    private(set) var sharedStatus = "还没检查"

    private var tagging = Set<String>()

    // 网络
    private(set) var online = false
    private(set) var llm: String?
    private var cooldownUntil = Date.distantPast

    // 提示
    private(set) var toast: String?
    private var toastTask: Task<Void, Never>?
    var confirmClear = false

    private let api = APIClient()
    let audio = AudioPlayer()
    let music = AppleMusic()
    private let speech = SpeechInput()

    init() {
        catalog = Self.taggedCatalog(tagStore)
        audio.onEnded = { [weak self] in self?.ended() }
        audio.onStateChange = { [weak self] in self?.syncPlayer() }
        audio.onRemote = { [weak self] a in
            guard let self else { return }
            switch a {
            case .play: if !self.isPlaying { self.toggle() }
            case .pause: if self.isPlaying { self.toggle() }
            case .toggle: self.toggle()
            case .next: self.step(1)
            case .previous: self.prev()
            }
        }
        speech.onText = { [weak self] t in
            guard let self else { return }
            self.text = self.speechBase + t
        }
        audio.onStreamError = { [weak self] in self?.showToast("试听片段加载失败，请检查网络后再试"); self?.syncPlayer() }
        audio.onAppleMusicError = { [weak self] in self?.showToast("Apple Music 暂时放不了这首，先放试听片段") }
        speech.onSessionChanged = { [weak self] in self?.audio.sessionChanged() }
        speech.onEnd = { [weak self] msg in
            self?.listening = false
            if let msg { self?.showToast(msg) }
        }
    }

    // MARK: 便捷

    func song(_ id: String) -> Song? { catalog.byId[id] ?? extraSongs[id] }
    func stats(_ id: String) -> SongStats { user.peek(id) }
    var currentSong: Song? { currentId.flatMap { song($0) } }
    var taste: TasteModel { TasteModel(user: user, catalog: catalog) }
    /// 结果页 / 播放页显示的真实封面（从 Apple Music 查到的）
    func artwork(_ id: String) -> URL? { music.tracks[id]?.artworkURL }
    /// 是不是搜索找到的 Apple Music 歌曲
    func isApple(_ id: String) -> Bool { id.hasPrefix("apple:") }
    func appleItem(_ id: String) -> LibItem? { extraItems[id] }

    /// 反馈后的一句持久说明
    func fbNote(_ id: String) -> String {
        let x = user.peek(id)
        if x.dislike != 0 { return "已记下不喜欢，之后不会再推荐这首，同类也会少一些" }
        if x.like != 0 { return "已喜欢，之后会多推一些这样的歌" }
        if x.fav != 0 { return "已收藏，能在“收藏”里找到" }
        if x.skip != 0 { return "已跳过，7 天内不再推荐这首" }
        return ""
    }

    func showToast(_ t: String) {
        toast = t
        toastTask?.cancel()
        toastTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(2.2))
            guard !Task.isCancelled else { return }
            self?.toast = nil
        }
    }

    func go(_ p: Page) {
        confirmClear = false
        withAnimation(.easeOut(duration: 0.2)) { page = p }
    }

    private func save() { user.save() }

    // MARK: 启动：探活（接口文档 §4.1）
    // 试听版用 App 内置的真实歌曲曲库，不拉服务器曲库；服务器只负责"理解需求"

    func boot() async {
        guard let h = await api.health() else { online = false; return }
        online = true
        llm = h.llm
        tagger = h.tagger
        sharedCatalog = h.catalog
        // 内置曲库交给模型 B（已经打过的会跳过）；之前进入曲库、还没打好的 Apple Music 歌也补上
        requestTags(Catalog.builtIn.songs.map { (APIClient.TagSong(id: $0.id, title: $0.title, artist: $0.artist), LibItem?.none) })
        requestTags(tagStore.items.values.map(tagRequest))
        await refreshCharts()
        await shareExisting()
        await syncSharedCatalog()
    }

    // MARK: 公共曲库：所有用户加进来、打好标签的歌，大家共享

    private static let sharedSinceKey = "moodmusic.shared.since"
    private static let sharedBackfillKey = "moodmusic.shared.backfilled.v2"

    /// 下载公共曲库里新增的歌，加进本机推荐曲库（不算作"你加的歌"，也不会再交给模型 B）
    private func syncSharedCatalog() async {
        guard sharedCatalog else { sharedStatus = "服务器没有公共曲库接口（打开 App 时检查）"; return }
        var got = 0
        var since = UserDefaults.standard.double(forKey: Self.sharedSinceKey)
        for _ in 0..<20 {
            guard let page = await api.catalog(since: since) else { sharedStatus += "；下载失败"; return }
            var changed = false
            for x in page.songs where x.id.hasPrefix("apple:") {
                guard let tg = x.tags?.value else { continue }
                let tid = String(x.id.dropFirst("apple:".count))
                guard !tid.isEmpty, tid.allSatisfy(\.isNumber) else { continue }
                if tagStore.items[x.id] == nil {
                    tagStore.items[x.id] = LibItem(kind: "apple", id: tid, title: x.title, artist: x.artist, collectionName: x.album,
                                                   storefront: x.storefront, previewUrl: x.preview_url, artwork: x.artwork,
                                                   durationMs: x.duration_ms)
                }
                tagStore.tags[x.id] = tg
                changed = true
                got += 1
            }
            if changed { tagStore.save(); catalog = Self.taggedCatalog(tagStore) }
            since = page.next
            UserDefaults.standard.set(since, forKey: Self.sharedSinceKey)
            if !page.more { break }
        }
        sharedStatus += "；从公共曲库下载 \(got) 首"
    }

    /// 公共曲库上线前已经打好标签的歌，补交一次给服务器（服务器有缓存，不会再调用大模型）
    private func shareExisting() async {
        guard sharedCatalog, tagger else { return }
        guard !UserDefaults.standard.bool(forKey: Self.sharedBackfillKey) else { sharedStatus = "已上传过本机的歌"; return }
        let list = tagStore.items.filter { tagStore.tags[$0.key] != nil }.values.map(tagRequest)
        UserDefaults.standard.set(true, forKey: Self.sharedBackfillKey)
        sharedStatus = "正在上传本机的 \(list.count) 首（每 7 秒 20 首）"
        guard !list.isEmpty else { return }
        requestTags(list, resend: true)
    }

    // MARK: 热门榜：每天把 Apple Music 热门歌曲加进推荐曲库

    @ObservationIgnored private var tagTail: Task<Void, Never>?

    private static let chartKey = "moodmusic.charts.lastFetch"

    private func refreshCharts() async {
        guard tagger else { return }
        let last = UserDefaults.standard.double(forKey: Self.chartKey)
        let now = Date().timeIntervalSince1970
        guard now - last > 20 * 3600 else { return }
        var got: [AppleMusic.Hit] = []
        for c in Array(Set([music.country, "cn", "us"])).sorted() { got += await AppleMusic.fetchChart(country: c) }
        guard !got.isEmpty else { return }
        UserDefaults.standard.set(now, forKey: Self.chartKey)
        var seen = Set<Int>()
        addToLibrary(got.filter { seen.insert($0.trackId).inserted }.map(\.libItem))
    }

    // MARK: 模型 B：给进入曲库的歌打标签

    /// 内置歌曲套上模型 B 的标签（还没打好的先用原来的标签）
    private static func taggedCatalog(_ t: TagStore) -> Catalog {
        Catalog(Catalog.builtIn.songs.map { s in t.tags[s.id]?.apply(to: s) ?? s })
    }

    func tags(_ id: String) -> SongTags? { tagStore.tags[id] }

    private func tagRequest(_ it: LibItem) -> (APIClient.TagSong, LibItem?) {
        (APIClient.TagSong(id: "apple:" + it.id, title: it.title, artist: it.artist, album: it.collectionName, genre_hint: it.genre,
                           preview_url: it.previewUrl, artwork: it.artwork, duration_ms: it.durationMs, storefront: it.storefront), it)
    }

    /// Apple Music 歌曲进入曲库：记下来并交给模型 B
    private func addToLibrary(_ items: [LibItem]) {
        let apple = items.filter(\.isApple)
        guard !apple.isEmpty else { return }
        var changed = false
        for it in apple where tagStore.items["apple:" + it.id] == nil {
            var x = it; x.likedAt = nil
            tagStore.items["apple:" + it.id] = x
            changed = true
        }
        if changed { tagStore.save() }
        requestTags(apple.map(tagRequest))
    }

    /// resend：已经有标签的歌也再交一次（只为让服务器记进公共曲库）
    private func requestTags(_ list: [(APIClient.TagSong, LibItem?)], resend: Bool = false) {
        guard online, tagger else { return }
        let todo = list.filter { (resend || tagStore.tags[$0.0.id] == nil) && !tagging.contains($0.0.id) }
        guard !todo.isEmpty else { return }
        for t in todo { tagging.insert(t.0.id) }
        // 所有打标签请求排成一队：服务器每分钟最多 10 次，每批之间隔 7 秒
        let prev = tagTail
        tagTail = Task {
            await prev?.value
            // 先读服务器上已经打好的标签（别人打过的歌直接用，几秒就好）
            for i in stride(from: 0, to: resend ? 0 : todo.count, by: 50) {
                let part = todo[i..<min(i + 50, todo.count)]
                guard let got = await api.cachedTags(part.map(\.0.id)) else { break }
                for (id, tg) in got where part.contains(where: { $0.0.id == id }) { tagStore.tags[id] = tg }
            }
            let rest = resend ? todo : todo.filter { tagStore.tags[$0.0.id] == nil }
            for t in todo where !resend && tagStore.tags[t.0.id] != nil { tagging.remove(t.0.id) }
            if rest.count < todo.count { tagStore.save(); catalog = Self.taggedCatalog(tagStore) }
            // 剩下服务器上也没有的，再交给模型 B
            let chunks = stride(from: 0, to: rest.count, by: 20).map { Array(rest[$0..<min($0 + 20, rest.count)]) }
            var sent = 0, failed = 0, why = ""
            for chunk in chunks {
                let (res, reason) = await api.tagWithStatus(chunk.map(\.0))
                for t in chunk { tagging.remove(t.0.id) }
                if resend {
                    if let got = res { sent += got.count } else { failed += 1; why = reason }
                    sharedStatus = "上传中：已上传 \(sent)/\(rest.count) 首" + (failed > 0 ? "，\(failed) 批失败（\(why)）" : "")
                }
                if let got = res, !got.isEmpty {
                    for (id, tg) in got where chunk.contains(where: { $0.0.id == id }) { tagStore.tags[id] = tg }
                    tagStore.save()
                    catalog = Self.taggedCatalog(tagStore)
                }
                try? await Task.sleep(for: .seconds(7))
            }
            if resend {
                sharedStatus = "上传完成：\(sent)/\(rest.count) 首" + (failed > 0 ? "，\(failed) 批失败（\(why)，下次打开会重试）" : "")
                if failed > 0 { UserDefaults.standard.set(false, forKey: Self.sharedBackfillKey) }
            }
        }
    }

    /// Apple Music 歌曲按模型 B 的标签变成一首能参与推荐、能播放的歌
    private func appleSong(_ it: LibItem, _ t: SongTags) -> Song {
        t.apply(to: Song(id: "apple:" + it.id, title: it.title, artist: it.artist, genre: t.genre, moods: [], energy: 3, valence: 3,
                         scenes: [], bpm: 100, pop: 3))
    }

    /// 推荐用的曲库：内置歌曲 + 已经打好标签的 Apple Music 歌曲
    private func recommendCatalog() -> Catalog {
        var songs = catalog.songs
        for (k, it) in tagStore.items.sorted(by: { $0.key < $1.key }) {
            guard let t = tagStore.tags[k] else { continue }
            _ = registerApple(it)
            songs.append(appleSong(it, t))
        }
        return Catalog(songs)
    }

    // MARK: 推荐

    func toggleChip(_ c: SceneChip) { chip = chip == c ? nil : c }

    func recommendTapped() {
        guard !busy else { return }
        if listening { speech.stop() }
        busy = true
        go(.thinking)
        Task {
            let minWait = Task { try? await Task.sleep(for: .seconds(1.25)) }
            await runRecommend(fresh: true)
            _ = await minWait.value
            busy = false
            if page == .thinking { go(askNow ? .clarify : .results) }
        }
    }

    func refresh() {
        guard !busy else { return }
        busy = true
        Task {
            await runRecommend(fresh: false)
            busy = false
            showToast("已为你换了一批")
        }
    }

    private func understand() async -> (Need, APIClient.Mode) {
        let local = { NeedParser.understand(self.text, chip: self.chip) }
        guard online else { return (local(), .local) }
        if Date() < cooldownUntil {
            let sec = Int(ceil(cooldownUntil.timeIntervalSinceNow))
            showToast("操作有点快，\(sec) 秒后再试")
            return (local(), .local)
        }
        switch await api.understand(text: text.trimmingCharacters(in: .whitespacesAndNewlines), chip: chip, time: NeedParser.timeSlot()) {
        case .ok(let r):
            var n = r.need
            let loc = local()
            // 旧版服务器不返回意图：用本地规则补上"找歌 / 影视作品"的识别
            if !n.serverHasIntent { n.intent = loc.intent; n.entities = loc.entities }
            // 服务器没要求追问、但本地判定需求太模糊时，补问一次（不增加任何请求）
            if !n.needsClarification && n.intent == "recommend" && n.entities.song == nil && n.entities.workTitle == nil
                && n.artistPreference == nil && loc.needsClarification {
                n.needsClarification = true
                n.clarificationQuestion = loc.clarificationQuestion
                n.clarificationOptions = loc.clarificationOptions
                n.clarificationDimension = loc.clarificationDimension
            }
            return (n, r.mode)
        case .rateLimited(let sec):
            cooldownUntil = Date().addingTimeInterval(TimeInterval(sec))
            showToast("操作有点快，\(sec) 秒后再试")
            return (local(), .local)
        case .failed:
            return (local(), .local)
        }
    }

    private var shouldAsk: Bool {
        guard let n = need else { return false }
        return n.intent == "recommend" && n.needsClarification && !n.clarificationOptions.isEmpty && !clarifyAnswered
    }

    private func runRecommend(fresh: Bool) async {
        if fresh || need == nil {
            let (n, m) = await understand()
            need = n
            mode = m
            seen = []
            batchNo = 0
            clarifyAnswered = false
        }
        // 需求太模糊：先问一句（这次不推荐，也不连续追问）
        if shouldAsk { askNow = true; batch = []; return }
        askNow = false
        guard let need else { return }
        searchResult = nil
        var result: [Recommendation] = []
        if need.isSongSearch {
            // 找指定歌曲：去 Apple Music 搜，不拿曲库里风格相近的歌冒充
            resultKind = .search
            searchResult = await music.searchSong(need.entities.song ?? "", artist: need.entities.artist)
            addToLibrary(searchResult?.all.map(\.libItem) ?? [])
        } else if need.intent != "soundtrack", need.entities.workTitle == nil, need.entities.song == nil, let a = need.entities.artist, !a.isEmpty {
            // 只说了歌手：去 Apple Music 搜这位歌手的歌（内置曲库里很多歌手没有）
            resultKind = .search
            searchResult = await music.searchArtist(a)
            addToLibrary(searchResult?.candidates.map(\.libItem) ?? [])
        } else if let work = need.entities.workTitle ?? (need.intent == "soundtrack" ? need.entities.song : nil), !work.isEmpty,
                  need.intent != "recommend" || need.entities.soundtrackType != nil {
            // 影视作品的歌：去 Apple Music 搜原声，列出候选让用户自己选
            // （服务器有时把它标成“找指定歌曲”，或把作品名放进歌名，所以两种都认）
            resultKind = .search
            let role = ["theme": "主题曲", "opening": "片头曲", "ending": "片尾曲", "insert": "插曲", "score": "配乐"][need.entities.soundtrackType ?? ""]
            // 中文剧名先换成英文名（Apple Music 里欧美影视原声只用英文名登记）
            var titles = [work]
            if WorkTitles.hasCJK(work) {
                if let en = WorkTitles.english(for: work) { titles.insert(en, at: 0) }
                else if online, let en = await api.workTitle(work), !WorkTitles.hasCJK(en) { titles.insert(en, at: 0) }
            }
            searchResult = await music.searchSoundtrack(titles: titles, role: role)
            addToLibrary(searchResult?.candidates.map(\.libItem) ?? [])
        } else if need.needsSearch {
            resultKind = .pending
        } else {
            resultKind = .recommend
            result = Recommender(catalog: recommendCatalog(), user: user).recommend(need, excludeIds: user.shown)
        }
        for r in result where !seen.contains(r.id) { seen.append(r.id) }
        // 推荐过的歌记在手机上：同样的话再说一次也换新歌，全部推完才轮回
        if !result.isEmpty { user.markShown(result.map(\.id)) }
        batch = result
        batchNo += 1
        music.prefetch(result.compactMap { song($0.id) })
        user.addHistory(HistoryEntry(ts: Date().timeIntervalSince1970 * 1000, text: need.text, chip: need.chip, target: need.target, ids: result.map(\.id)))
        save()
    }

    // MARK: 追问（最多问一次，可跳过）

    func answerClarify(_ v: String) {
        guard !busy, var n = need else { return }
        clarifyAnswered = true
        let dir = ["resonate": "宣泄", "calm": "平静", "lift": "振奋", "vent": "宣泄", "keep": "随心"]
        let t = Targets.all[v] != nil ? v : (dir[v] ?? "随心")
        n.target = t
        n.needsClarification = false
        n.clarificationOptions = []
        need = n
        continueRecommend()
    }

    func skipClarify() {
        guard !busy else { return }
        clarifyAnswered = true
        need?.needsClarification = false
        need?.clarificationOptions = []
        continueRecommend()
    }

    private func continueRecommend() {
        busy = true
        go(.thinking)
        Task {
            let minWait = Task { try? await Task.sleep(for: .seconds(0.7)) }
            await runRecommend(fresh: false)
            _ = await minWait.value
            busy = false
            if page == .thinking { go(askNow ? .clarify : .results) }
        }
    }

    func searchAgain() {
        searchResult = nil
        go(.home)
    }

    // MARK: 少推这个歌手 / 曲风（只影响这一轮，换一批时生效）

    func isMuted(_ type: String, _ value: String) -> Bool {
        need?.exclusions.contains(Exclusion(type: type, value: value)) ?? false
    }

    func mute(_ type: String, _ value: String) {
        guard var n = need else { return }
        let e = Exclusion(type: type, value: value)
        if let i = n.exclusions.firstIndex(of: e) {
            n.exclusions.remove(at: i)
            if type == "genre" { n.exclude.removeAll { $0 == value } }
            showToast("已恢复推荐\(value)")
        } else {
            n.exclusions.append(e)
            if type == "genre" && !n.exclude.contains(value) { n.exclude.append(value) }
            showToast("已减少推荐\(type == "artist" ? "歌手" : "曲风")「\(value)」，换一批时生效")
        }
        need = n
    }

    // MARK: 语音

    private var speechBase = ""

    func voiceTapped() {
        if listening { speech.stop(); return }
        if isPlaying { toggle() }
        speechBase = text.isEmpty ? "" : text + "，"
        listening = true
        Task { await speech.start() }
    }

    // MARK: 播放

    func playBatch(_ i: Int) {
        playQueue(batch.map(\.id), i, Dictionary(uniqueKeysWithValues: batch.map { ($0.id, $0) }), title: "推荐")
    }

    /// 播放歌单 / 我喜欢的音乐 / 搜索结果里的歌（内置歌曲和 Apple Music 歌曲都能放）
    func playItems(_ items: [LibItem], _ i: Int, title: String) {
        var ids: [String] = []
        for it in items {
            if it.isApple { ids.append(registerApple(it)) }
            else if catalog.byId[it.id] != nil { ids.append(it.id) }
        }
        guard !ids.isEmpty else { showToast("这首暂时没有可播放的音源"); return }
        music.prefetch(ids.compactMap { catalog.byId[$0] })
        playQueue(ids, min(i, ids.count - 1), [:], title: title)
    }

    /// 把 Apple Music 歌曲登记成一首临时歌曲，播放器就能放它
    private func registerApple(_ it: LibItem) -> String {
        let sid = "apple:" + it.id
        if let t = tagStore.tags[sid] {
            extraSongs[sid] = appleSong(it, t)
        } else if extraSongs[sid] == nil {
            extraSongs[sid] = Song(id: sid, title: it.title, artist: it.artist, genre: it.genre ?? "流行", moods: [], energy: 3, valence: 3,
                                   scenes: [], bpm: 100, pop: 3)
        }
        extraItems[sid] = it
        music.register(sid, AMTrack(storeId: it.id, name: it.title, artist: it.artist, previewUrl: it.previewUrl,
                                    artwork: it.artwork, durationMs: it.durationMs))
        return sid
    }

    private func playQueue(_ ids: [String], _ i: Int, _ m: [String: Recommendation], title: String) {
        guard !ids.isEmpty else { return }
        queue = ids
        qi = min(max(0, i), ids.count - 1)
        meta = m
        queueTitle = title
        startTrack()
        go(.player)
    }

    private var trackToken = 0
    /// 连续放不了的首数（防止整批都放不了时一直跳）
    private var failStreak = 0
    private var warnedPreview = false

    /// 播放顺序：Apple Music 完整版（有订阅）→ 30 秒试听 → 都不行就跳到下一首（不再放合成旋律）
    private func startTrack() {
        guard queue.indices.contains(qi), let s = song(queue[qi]) else { return }
        trackToken += 1
        let token = trackToken
        loadingId = s.id
        Task {
            if music.access == .unknown { await music.refreshAccess() }   // 第一次播放时请求权限
            let t = await music.track(for: s)
            guard token == trackToken else { return }
            loadingId = nil
            if t != nil { failStreak = 0 }
            if let t, music.access == .subscriber {
                audio.playAppleMusic(s, storeId: t.storeId, duration: t.seconds, fallback: t.preview)
            } else if let url = t?.preview {
                audio.playPreview(s, url: url)
                if !warnedPreview {
                    warnedPreview = true
                    showToast(music.access == .notAuthorized ? "没有 Apple Music 权限，先放 30 秒试听" : "没有 Apple Music 订阅，先放 30 秒试听")
                }
            } else {
                // 不放合成旋律：这首放不了就跳到下一首（整批都放不了时停下）
                audio.stop()
                failStreak += 1
                if queue.count > 1 && failStreak < queue.count {
                    showToast("《\(s.title)》在 Apple Music 暂时放不了，已跳到下一首")
                    qi = (qi + 1) % queue.count
                    startTrack()
                    return
                }
                failStreak = 0
                showToast(music.lastLookup.contains("失败") ? "连不上 Apple Music，请检查网络后再试" : "这些歌在 Apple Music 暂时都放不了")
            }
            syncPlayer()
        }
        if queue.count > 1, let n = song(queue[(qi + 1) % queue.count]) { music.prefetch([n]) }
    }

    /// 在“我的”页里手动连接 Apple Music
    func connectAppleMusic() {
        Task {
            await music.refreshAccess()
            showToast(music.access == .subscriber ? "已连接 Apple Music" : "没有订阅，会放 30 秒试听")
        }
    }

    func syncPlayer() {
        currentId = audio.current?.id
        isPlaying = audio.isPlaying
    }

    private func ended() {
        guard let s = audio.current else { syncPlayer(); return }
        if catalog.byId[s.id] != nil {
            var x = user.peek(s.id); x.play += 1; user.stats[s.id] = x
            user.bump(s, .play)
            save()
        }
        if qi < queue.count - 1 { qi += 1; startTrack() }
        else { audio.stop(); syncPlayer(); showToast("这一批听完了，可以换一批继续") }
    }

    func step(_ d: Int) {
        guard !queue.isEmpty else { return }
        qi = (qi + d + queue.count) % queue.count
        startTrack()
    }

    /// 跳过：可以撤销；在播放页跳过正在放的歌会切到下一首
    func skip(_ id: String) {
        guard let s = song(id) else { return }
        var x = user.peek(id)
        if x.skip != 0 {
            x.skip = 0; x.skippedAt = nil; user.bump(s, .skip, sign: -1); showToast("已撤销跳过")
        } else {
            x.skip = 1; x.skippedAt = Date().timeIntervalSince1970; user.bump(s, .skip); showToast("已跳过，7 天内不再推荐这首")
        }
        user.stats[id] = x
        if page == .player && queue[safe: qi] == id && queue.count > 1 {
            qi = (qi + 1) % queue.count
            startTrack()
        }
        save()
    }

    func prev() {
        if audio.position > 3 { audio.seek(0); syncPlayer() } else { step(-1) }
    }

    func toggle() {
        if loadingId != nil { return }
        if audio.current == nil {
            if !queue.isEmpty { startTrack() }
            return
        }
        if audio.isPlaying { audio.pause() } else { audio.resume() }
        syncPlayer()
    }

    func jump(_ i: Int) {
        guard queue.indices.contains(i) else { return }
        qi = i
        startTrack()
    }

    func seek(fraction: Double) {
        guard loadingId == nil else { return }
        if audio.current?.id != queue[safe: qi] { startTrack(); return }
        guard audio.current != nil else { return }
        audio.seek(min(1, max(0, fraction)) * audio.duration)
        syncPlayer()
    }

    // MARK: 反馈

    enum Flag { case like, fav, dislike }

    func setFlag(_ id: String, _ flag: Flag) {
        // 推荐里出现的 Apple Music 歌曲：喜欢记到“我喜欢的音乐”，收藏改成加入自建歌单
        if isApple(id), let it = extraItems[id] {
            if flag == .like { toggleAppleLike(it); return }
            if flag == .fav { addToPlaylist(it); return }
        }
        guard let s = song(id) else { return }
        var x = user.peek(id)
        switch flag {
        case .like:
            if x.like != 0 {
                x.like = 0; user.likedAt[id] = nil; user.bump(s, .like, sign: -1)
                showToast("已取消喜欢，已从“我喜欢的音乐”移除")
            } else {
                x.like = 1; user.likedAt[id] = Date().timeIntervalSince1970 * 1000; user.bump(s, .like)
                if x.dislike != 0 { x.dislike = 0; user.bump(s, .dislike, sign: -1) }
                showToast("记住了，会多推一些像《\(s.title)》的歌")
            }
        case .fav:
            if x.fav != 0 {
                x.fav = 0; user.bump(s, .fav, sign: -1); user.fav.removeAll { $0 == id }
                showToast("已取消收藏")
            } else {
                x.fav = 1; user.bump(s, .fav)
                user.fav = [id] + user.fav.filter { $0 != id }
                if x.dislike != 0 { x.dislike = 0; user.bump(s, .dislike, sign: -1) }
                showToast("已收藏，可以在“收藏”里找到")
            }
        case .dislike:
            if x.dislike != 0 { x.dislike = 0; user.bump(s, .dislike, sign: -1); showToast("已撤销不喜欢") }
            else {
                x.dislike = 1; user.bump(s, .dislike)
                if x.like != 0 { x.like = 0; user.bump(s, .like, sign: -1) }
                showToast("好的，之后不会再推荐这首")
                user.stats[id] = x
                if page == .player && queue[safe: qi] == id && queue.count > 1 {
                    qi = (qi + 1) % queue.count
                    startTrack()
                }
            }
        }
        user.stats[id] = x
        save()
    }

    // MARK: 我喜欢的音乐（内置歌曲看 stats.like，Apple Music 歌曲看 appleLikes，两边互不混用）

    func isAppleLiked(_ trackId: String) -> Bool { user.appleLikes["apple:" + trackId] != nil }

    func toggleAppleLike(_ item: LibItem) {
        let k = "apple:" + item.id
        let t = tagStore.tags[k]
        if user.appleLikes[k] != nil {
            user.appleLikes[k] = nil
            if let t { user.bump(appleSong(item, t), .like, sign: -1) }
            showToast("已从“我喜欢的音乐”移除")
        } else {
            addToLibrary([item])
            if let t { user.bump(appleSong(item, t), .like) }
            var it = item
            it.likedAt = Date().timeIntervalSince1970 * 1000
            user.appleLikes[k] = it
            showToast("已加入“我喜欢的音乐”")
        }
        save()
    }

    /// 已喜欢的歌（内置 + Apple Music），最近点的在前
    var likedEntries: [LibItem] {
        var out: [(LibItem, Double, Int)] = []
        for (seq, id) in user.stats.keys.sorted().enumerated() {
            guard let x = user.stats[id], x.like != 0, let s = catalog.byId[id] else { continue }
            out.append((LibItem(kind: "demo", id: id, title: s.title, artist: s.artist, genre: s.genre), user.likedAt[id] ?? 0, seq))
        }
        for (seq, k) in user.appleLikes.keys.sorted().enumerated() {
            guard let it = user.appleLikes[k] else { continue }
            out.append((it, it.likedAt ?? 0, seq))
        }
        return out.sorted { $0.1 != $1.1 ? $0.1 > $1.1 : ($0.2 != $1.2 ? $0.2 > $1.2 : $0.0.id < $1.0.id) }.map(\.0)
    }

    // MARK: 歌单（“我的收藏”是系统歌单，成员就是收藏的歌；其余是自建歌单）

    static let defaultPlaylist = "fav"

    var playlists: [Playlist] {
        [Playlist(id: Self.defaultPlaylist, name: "我的收藏")] + user.playlists
    }

    func playlist(_ id: String?) -> Playlist? { playlists.first { $0.id == id } }

    func items(of p: Playlist) -> [LibItem] {
        if p.id == Self.defaultPlaylist {
            return user.fav.compactMap { id in catalog.byId[id].map { LibItem(kind: "demo", id: id, title: $0.title, artist: $0.artist, genre: $0.genre) } }
        }
        return p.items
    }

    /// 在 Apple Music 里打开这首歌：有歌曲链接就用；查到过曲目编号就拼出链接；都没有就打开 Apple Music 搜索这首歌
    func appleMusicURL(_ it: LibItem) -> URL? {
        if let u = it.trackViewUrl.flatMap(URL.init(string:)) { return u }
        let sf = it.storefront ?? music.country
        if let sid = it.isApple ? it.id : music.tracks[it.id]?.storeId, !sid.isEmpty, sid.allSatisfy(\.isNumber) {
            return URL(string: "https://music.apple.com/\(sf)/song/\(sid)")
        }
        var c = URLComponents(string: "https://music.apple.com/\(sf)/search")
        c?.queryItems = [URLQueryItem(name: "term", value: it.title + " " + it.artist)]
        return c?.url
    }

    func appleMusicURL(forSong id: String) -> URL? { libItem(forSong: id).flatMap(appleMusicURL) }

    func libItem(forSong id: String) -> LibItem? {
        if let it = extraItems[id] { return it }
        return catalog.byId[id].map { LibItem(kind: "demo", id: id, title: $0.title, artist: $0.artist, genre: $0.genre) }
    }

    func openPlaylist(_ id: String) {
        plId = id
        confirmPlDel = false
        plName = ""
        plRenameId = nil
        go(.playlist)
    }

    func newPlaylistTapped() {
        plName = ""
        plRenameId = nil
        go(.newPlaylist)
    }

    func renamePlaylistTapped() {
        plName = playlist(plId)?.name ?? ""
        plRenameId = plId
        go(.newPlaylist)
    }

    func cancelNewPlaylist() {
        if plRenameId != nil { plRenameId = nil; go(.playlist) }
        else { go(pendingItem != nil ? .addTo : .favorites) }
    }

    func savePlaylistName() {
        let name = String(plName.trimmingCharacters(in: .whitespacesAndNewlines).prefix(30))
        guard !name.isEmpty else { showToast("请先给歌单起个名字"); return }
        let now = Date().timeIntervalSince1970 * 1000
        if let rid = plRenameId {
            guard !playlists.contains(where: { $0.id != rid && $0.name == name }) else { showToast("已经有同名歌单了，换个名字试试"); return }
            guard let i = user.playlists.firstIndex(where: { $0.id == rid }) else { return }
            user.playlists[i].name = name
            user.playlists[i].updatedAt = now
            save()
            plRenameId = nil
            go(.playlist)
            showToast("名称已更新")
            return
        }
        guard !playlists.contains(where: { $0.name == name }) else { showToast("已经有同名歌单了，换个名字试试"); return }
        let p = Playlist(id: "pl_" + String(Int(now), radix: 36) + "_" + String(Int.random(in: 0..<1_679_616), radix: 36),
                         name: name, createdAt: now, updatedAt: now)
        user.playlists.append(p)
        save()
        plName = ""
        if pendingItem != nil { go(.addTo) } else { plId = p.id; go(.playlist) }
        showToast("已创建歌单")
    }

    func deletePlaylistTapped() {
        guard let id = plId, id != Self.defaultPlaylist else { return }
        if !confirmPlDel { confirmPlDel = true; return }
        user.playlists.removeAll { $0.id == id }
        save()
        confirmPlDel = false
        plId = nil
        go(.favorites)
        showToast("歌单已删除")
    }

    /// 打开"加入歌单"页
    func addToPlaylist(_ item: LibItem?) {
        guard let item else { return }
        pendingItem = item
        addFrom = page
        go(.addTo)
    }

    func cancelAddTo() {
        pendingItem = nil
        go(addFrom)
    }

    func addPending(to pid: String) {
        guard let item = pendingItem, let p = playlist(pid) else { return }
        if p.id == Self.defaultPlaylist {
            guard !item.isApple else { showToast("“我的收藏”只收曲库里的歌，请选择自建歌单"); return }
            guard !user.fav.contains(item.id) else { showToast("这首歌已经在这个歌单里了"); return }
            if let s = catalog.byId[item.id] {
                user.fav = [item.id] + user.fav.filter { $0 != item.id }
                var x = user.peek(item.id)
                if x.fav == 0 { x.fav = 1; user.bump(s, .fav); user.stats[item.id] = x }
            }
        } else {
            guard let i = user.playlists.firstIndex(where: { $0.id == pid }) else { return }
            guard !user.playlists[i].items.contains(where: { $0.key == item.key }) else { showToast("这首歌已经在这个歌单里了"); return }
            var it = item
            it.likedAt = nil
            user.playlists[i].items.append(it)
            addToLibrary([it])
            user.playlists[i].updatedAt = Date().timeIntervalSince1970 * 1000
        }
        save()
        showToast("已加入「\(p.name)」")
        pendingItem = nil
        go(.favorites)
    }

    func removeFromPlaylist(_ item: LibItem) {
        guard let pid = plId else { return }
        if pid == Self.defaultPlaylist {
            guard !item.isApple, user.fav.contains(item.id) else { return }
            user.fav.removeAll { $0 == item.id }
            if let s = catalog.byId[item.id] {
                var x = user.peek(item.id)
                if x.fav != 0 { x.fav = 0; user.bump(s, .fav, sign: -1); user.stats[item.id] = x }
            }
        } else {
            guard let i = user.playlists.firstIndex(where: { $0.id == pid }) else { return }
            user.playlists[i].items.removeAll { $0.key == item.key }
            user.playlists[i].updatedAt = Date().timeIntervalSince1970 * 1000
        }
        save()
        showToast("已从歌单移除")
    }

    // MARK: 清除数据

    func clearTapped() {
        if !confirmClear { confirmClear = true; return }
        trackToken += 1
        loadingId = nil
        audio.stop()
        UserData.clear()
        user = UserData()
        tagStore.items = [:]   // 标签本身不含个人信息，保留；你加进曲库的歌清掉
        UserDefaults.standard.removeObject(forKey: Self.chartKey)   // 下次打开重新拉热门榜
        UserDefaults.standard.removeObject(forKey: Self.sharedSinceKey)   // 下次打开重新下载公共曲库
        tagStore.save()
        need = nil; batch = []; queue = []; chip = nil; text = ""; seen = []; searchResult = nil
        pendingItem = nil; plId = nil
        syncPlayer()
        showToast("本地数据已清除")
        go(.cover)
    }
}

extension Array {
    subscript(safe i: Int) -> Element? { indices.contains(i) ? self[i] : nil }
}
