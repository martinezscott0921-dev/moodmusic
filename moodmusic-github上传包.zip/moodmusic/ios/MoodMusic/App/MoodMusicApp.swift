import SwiftUI

@main
struct MoodMusicApp: App {
    @State private var model: AppModel

    init() {
        AppFont.registerBundledFonts()
        _model = State(initialValue: AppModel())
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(model)
                .tint(Palette.red)
        }
    }
}
