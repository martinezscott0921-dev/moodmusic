import Foundation

/// 全局配置：要换服务器地址，只改这一处。
enum AppConfig {
    /// 后端地址（不带 /api）。
    /// 现在：http://121.43.42.164（HTTP，只适合自己测试）
    /// 备案 + HTTPS 配好后改成：https://music.mypingrou.com ，并删掉 Info.plist 里的 NSAppTransportSecurity 那一段。
    static let apiBase = URL(string: "http://121.43.42.164")!

    /// 隐私政策网址（App Store Connect 里也要填同一个）
    static let privacyPolicyURL = URL(string: "https://mypingrou.com/moodmusic/privacy.html")!

    /// 网络超时（秒）
    static let healthTimeout: TimeInterval = 4
    static let understandTimeout: TimeInterval = 12
    static let defaultTimeout: TimeInterval = 8
}
