import AVFoundation
import MediaPlayer
import UIKit

/// 播放适配层：
/// - provider = synth：把 SynthComposer 生成的采样交给 AVAudioEngine 播放（示意旋律）
/// - provider = file：用 AVPlayer 播放音频地址（试听版里是 Apple Music 的 30 秒试听片段）
/// - Apple Music：用系统音乐播放器放完整歌曲（需要用户自己有 Apple Music 订阅）
/// 推荐引擎只认歌曲 ID，不关心用哪种播放器。
@MainActor
final class AudioPlayer {
    enum RemoteAction { case play, pause, toggle, next, previous }

    /// 一首播完（自然结束）
    var onEnded: (() -> Void)?
    /// 播放状态被系统改变（来电打断、拔耳机等）
    var onStateChange: (() -> Void)?
    /// 锁屏 / 控制中心 / 耳机线控
    var onRemote: ((RemoteAction) -> Void)?

    private(set) var current: Song?
    private(set) var isPlaying = false

    /// 当前用哪种方式在放
    enum Kind { case synth, preview, appleMusic }
    var kind: Kind { amActive ? .appleMusic : (stream != nil ? .preview : .synth) }

    private let engine = AVAudioEngine()
    private let node = AVAudioPlayerNode()
    private let format = AVAudioFormat(standardFormatWithSampleRate: SynthComposer.sampleRate, channels: 1)!
    private var cache: [String: AVAudioPCMBuffer] = [:]
    private var cacheOrder: [String] = []
    private var segmentStart: Double = 0
    private var pausedAt: Double = 0
    private var playToken = 0       // 切歌时丢弃过期的渲染结果
    private var scheduleGen = 0     // 区分"自然播完"和"被 stop 打断"

    init() {
        engine.attach(node)
        engine.connect(node, to: engine.mainMixerNode, format: format)
        let nc = NotificationCenter.default
        nc.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] note in
            let raw = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt
            MainActor.assumeIsolated {
                if raw == AVAudioSession.InterruptionType.began.rawValue { self?.systemPause(); self?.sessionReady = false }
            }
        }
        nc.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main) { [weak self] note in
            let raw = note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt
            MainActor.assumeIsolated {
                if raw == AVAudioSession.RouteChangeReason.oldDeviceUnavailable.rawValue { self?.systemPause() }
            }
        }
        nc.addObserver(forName: .AVAudioEngineConfigurationChange, object: engine, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.systemPause() }
        }
        setupRemoteCommands()
        // 启动时只设置"播放"模式，不激活会话，这样打开 App 不会打断别的 App 的音乐
        DispatchQueue.global(qos: .userInitiated).async {
            try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        }
    }

    // MARK: 播放控制

    var position: Double {
        guard let s = current else { return 0 }
        if amActive {
            let t = amPlayer.currentPlaybackTime
            return t.isFinite ? min(duration, max(0, t)) : pausedAt
        }
        if let p = stream {
            let t = p.currentTime().seconds
            return t.isFinite ? min(duration, max(0, t)) : pausedAt
        }
        guard isPlaying, let t = node.lastRenderTime, let pt = node.playerTime(forNodeTime: t) else { return pausedAt }
        return min(Double(s.dur), max(segmentStart, segmentStart + Double(pt.sampleTime) / pt.sampleRate))
    }

    /// 当前歌曲时长：真实音频优先用文件里的时长
    var duration: Double {
        guard let s = current else { return 0 }
        if amActive {
            if let d = amPlayer.nowPlayingItem?.playbackDuration, d > 0 { return d }
            return amDuration ?? Double(s.dur)
        }
        if let d = stream?.currentItem?.duration.seconds, d.isFinite, d > 0 { return d }
        return Double(s.dur)
    }

    /// 播放一首歌；source 是 /api/sources 返回的音源（没有就用歌曲自带的）
    func play(_ song: Song, source: SongSource?, from sec: Double = 0) {
        let src = source ?? song.sources.first { $0.provider == "file" }
        if let src, src.provider == "file", let u = src.url.flatMap(APIClient.absolute) {
            playStream(song, url: u, from: sec)
        } else {
            play(song, from: sec)
        }
    }

    /// 播放网上的音频地址（Apple Music 的 30 秒试听）
    func playPreview(_ song: Song, url: URL) {
        playStream(song, url: url, from: 0)
    }

    func play(_ song: Song, from sec: Double = 0) {
        stopStream()
        stopAppleMusic()
        playToken += 1
        let token = playToken
        // 先停掉上一首，合成新旋律需要零点几秒
        scheduleGen += 1
        node.stop()
        scheduledFor = nil
        current = song
        isPlaying = true
        pausedAt = sec
        segmentStart = sec
        updateNowPlaying()
        Task {
            let buf = await buffer(for: song)
            guard token == self.playToken, let buf else { return }
            self.start(buf, at: sec, autoplay: self.isPlaying)
        }
    }

    func pause() {
        guard isPlaying else { return }
        pausedAt = position
        if amActive { amPlayer.pause(); isPlaying = false; amGrace = Date().addingTimeInterval(1.5); return }
        if let p = stream { p.pause(); isPlaying = false; updateNowPlaying(); return }
        node.pause()
        isPlaying = false
        updateNowPlaying()
    }

    func resume() {
        guard let s = current, !isPlaying else { return }
        if amActive { amPlayer.play(); isPlaying = true; amGrace = Date().addingTimeInterval(1.5); return }
        if let p = stream {
            activateSession()
            p.play()
            isPlaying = true
            updateNowPlaying()
            return
        }
        if engine.isRunning, cache[s.id] != nil, scheduledFor == s.id {
            activateSession()
            node.play()
            isPlaying = true
            updateNowPlaying()
        } else {
            play(s, from: pausedAt)
        }
    }

    func seek(_ sec: Double) {
        guard let s = current else { return }
        if amActive {
            let target = min(duration, max(0, sec))
            pausedAt = target
            amPlayer.currentPlaybackTime = target
            amLast = target
            amGrace = Date().addingTimeInterval(1.5)
            return
        }
        if let p = stream {
            let target = min(duration, max(0, sec))
            pausedAt = target
            p.seek(to: CMTime(seconds: target, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
            updateNowPlaying()
            return
        }
        let target = min(Double(s.dur), max(0, sec))
        guard let buf = cache[s.id] else { play(s, from: target); return }
        start(buf, at: target, autoplay: isPlaying)
    }

    func stop() {
        stopStream()
        stopAppleMusic()
        playToken += 1
        scheduleGen += 1
        node.stop()
        current = nil
        isPlaying = false
        scheduledFor = nil
        pausedAt = 0
        updateNowPlaying()
    }

    /// 提前渲染（下一首），点播放时不用等
    func preload(_ song: Song) {
        guard !song.isRealAudio else { return }
        Task { _ = await buffer(for: song) }
    }

    // MARK: 内部

    private var scheduledFor: String?

    private func systemPause() {
        guard isPlaying, !amActive else { return }   // Apple Music 由系统播放器自己处理，状态靠轮询同步
        pausedAt = position
        if let p = stream { p.pause(); isPlaying = false; updateNowPlaying(); onStateChange?(); return }
        node.pause()
        isPlaying = false
        scheduledFor = engine.isRunning ? scheduledFor : nil
        updateNowPlaying()
        onStateChange?()
    }

    /// 设置音频会话：放到后台线程做，避免主线程卡顿（Xcode 的 Hang Risk 提示）
    // MARK: 真实音频（AVPlayer）

    private var stream: AVPlayer?
    private var streamObservers: [NSObjectProtocol] = []
    private var statusObservation: NSKeyValueObservation?

    private func playStream(_ song: Song, url: URL, from sec: Double) {
        stopStream()
        stopAppleMusic()
        playToken += 1
        scheduleGen += 1
        node.stop()
        scheduledFor = nil
        activateSession()

        let item = AVPlayerItem(url: url)
        let player = AVPlayer(playerItem: item)
        stream = player
        current = song
        pausedAt = sec
        isPlaying = true
        let token = playToken

        let nc = NotificationCenter.default
        streamObservers.append(nc.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self, token == self.playToken, self.isPlaying else { return }
                self.isPlaying = false
                self.pausedAt = self.duration
                self.updateNowPlaying()
                self.onEnded?()
            }
        })
        streamObservers.append(nc.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.streamFailed(token) }
        })
        // 文件打不开（网络断了、地址错了）→ 改放合成旋律，保证有声音
        let failed: (Int) -> Void = { [weak self] t in MainActor.assumeIsolated { self?.streamFailed(t) } }
        statusObservation = item.observe(\.status, options: [.new], changeHandler: Self.statusHandler(token, failed))

        if sec > 0 { player.seek(to: CMTime(seconds: sec, preferredTimescale: 600)) }
        player.play()
        updateNowPlaying()
    }

    private func streamFailed(_ token: Int) {
        guard token == playToken, let s = current else { return }
        _ = s
        stop()               // 不再放合成的示意旋律
        onStreamError?()
    }

    /// 真实音频加载失败时通知界面（提示"网络不好，先放示意旋律"）
    var onStreamError: (() -> Void)?

    private func stopStream() {
        statusObservation?.invalidate()
        statusObservation = nil
        streamObservers.forEach { NotificationCenter.default.removeObserver($0) }
        streamObservers = []
        stream?.pause()
        stream = nil
    }

    nonisolated private static func statusHandler(_ token: Int, _ failed: @escaping (Int) -> Void) -> @Sendable (AVPlayerItem, NSKeyValueObservedChange<AVPlayerItem.Status>) -> Void {
        let box = MainCallback(failed)
        return { item, _ in
            if item.status == .failed { DispatchQueue.main.async { box.call(token) } }
        }
    }

    // MARK: Apple Music（系统音乐播放器）

    private let amPlayer = MPMusicPlayerController.applicationQueuePlayer
    private var amActive = false
    private var amTimer: Timer?
    private var amSawPlaying = false
    private var amLast: Double = 0
    private var amStartedAt = Date()
    private var amDuration: Double?
    private var amFallback: URL?
    private var amGrace = Date.distantPast   // 刚发出播放 / 暂停指令时，系统状态还没跟上，先不同步

    /// 用 Apple Music 放完整歌曲；放不了时自动改放试听片段（fallback），再不行放示意旋律
    func playAppleMusic(_ song: Song, storeId: String, duration: Double?, fallback: URL?) {
        stopStream()
        stopAppleMusic()
        playToken += 1
        scheduleGen += 1
        node.stop()
        scheduledFor = nil
        current = song
        pausedAt = 0
        isPlaying = true
        amActive = true
        amSawPlaying = false
        amLast = 0
        amStartedAt = Date()
        amDuration = duration
        amFallback = fallback
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil   // 锁屏信息交给系统播放器

        amPlayer.setQueue(with: [storeId])
        let token = playToken
        let failed: (Int) -> Void = { [weak self] t in MainActor.assumeIsolated { self?.appleMusicFailed(t) } }
        let ready: (Int) -> Void = { [weak self] t in
            MainActor.assumeIsolated {
                guard let self, t == self.playToken, self.amActive, self.isPlaying else { return }
                self.amPlayer.play()
            }
        }
        amPlayer.prepareToPlay(completionHandler: Self.prepared(token, ready, failed))
        amTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            DispatchQueue.main.async { MainActor.assumeIsolated { self?.amTick(token) } }
        }
    }

    /// 每 0.5 秒看一次系统播放器的状态：同步暂停 / 继续，识别"播完了"
    private func amTick(_ token: Int) {
        guard amActive, token == playToken else { return }
        let state = amPlayer.playbackState
        let t = amPlayer.currentPlaybackTime
        if state == .playing {
            amSawPlaying = true
            if t.isFinite { amLast = t }
            if Date() < amGrace { return }
            if !isPlaying { isPlaying = true; onStateChange?() }   // 在控制中心点了继续
            return
        }
        guard isPlaying, Date() >= amGrace else { return }
        if !amSawPlaying {
            // 一直没放起来（没订阅、地区没有这首歌、网络不好）
            if Date().timeIntervalSince(amStartedAt) > 12 { appleMusicFailed(token) }
            return
        }
        let d = duration
        if state == .stopped || (d > 0 && amLast >= d - 1.5) {
            isPlaying = false
            pausedAt = d
            amSawPlaying = false
            onEnded?()
        } else if state == .paused || state == .interrupted {
            isPlaying = false       // 在控制中心 / 耳机上暂停，或来电打断
            pausedAt = t.isFinite ? t : amLast
            onStateChange?()
        }
    }

    private func appleMusicFailed(_ token: Int) {
        guard token == playToken, amActive, let s = current else { return }
        let url = amFallback
        stopAppleMusic()
        onAppleMusicError?()
        if let url { playStream(s, url: url, from: 0) } else { stop(); onStreamError?() }
    }

    /// Apple Music 放不了时通知界面
    var onAppleMusicError: (() -> Void)?

    private func stopAppleMusic() {
        amTimer?.invalidate()
        amTimer = nil
        guard amActive else { return }
        amActive = false
        amPlayer.stop()
    }

    nonisolated private static func prepared(_ token: Int, _ ready: @escaping (Int) -> Void, _ failed: @escaping (Int) -> Void) -> @Sendable (Error?) -> Void {
        let ok = MainCallback(ready), bad = MainCallback(failed)
        return { error in
            DispatchQueue.main.async { if error == nil { ok.call(token) } else { bad.call(token) } }
        }
    }

    private func activateSession() {
        guard !sessionReady else { return }
        sessionReady = true
        DispatchQueue.global(qos: .userInitiated).async {
            let session = AVAudioSession.sharedInstance()
            try? session.setCategory(.playback, mode: .default)
            try? session.setActive(true)
        }
    }

    private var sessionReady = false

    /// 语音输入结束后调用：需要重新设置一次播放模式
    func sessionChanged() { sessionReady = false }

    private func start(_ buf: AVAudioPCMBuffer, at sec: Double, autoplay: Bool) {
        guard let s = current else { return }
        activateSession()
        if !engine.isRunning {
            engine.prepare()
            do { try engine.start() } catch { isPlaying = false; onStateChange?(); return }
        }
        scheduleGen += 1
        node.stop()
        let from = AVAudioFramePosition(sec * SynthComposer.sampleRate)
        guard let seg = slice(buf, from: from) else {
            // 已经在结尾
            isPlaying = false
            onEnded?()
            return
        }
        let gen = scheduleGen
        let fire: (Int) -> Void = { [weak self] g in
            MainActor.assumeIsolated {
                guard let self, g == self.scheduleGen, self.isPlaying else { return }
                self.isPlaying = false
                self.pausedAt = Double(s.dur)
                self.updateNowPlaying()
                self.onEnded?()
            }
        }
        node.scheduleBuffer(seg, at: nil, options: [], completionCallbackType: .dataPlayedBack,
                            completionHandler: Self.onMain(gen, fire))
        scheduledFor = s.id
        segmentStart = sec
        pausedAt = sec
        if autoplay {
            node.play()
            isPlaying = true
        } else {
            isPlaying = false
        }
        updateNowPlaying()
    }

    /// 截取从 from 帧开始到歌曲结束（dur 秒）的片段
    private func slice(_ buf: AVAudioPCMBuffer, from: AVAudioFramePosition) -> AVAudioPCMBuffer? {
        let endFrame = min(Int(buf.frameLength), Int(Double(current?.dur ?? 45) * SynthComposer.sampleRate) + Int(SynthComposer.sampleRate / 2))
        let start = Int(max(0, from))
        let count = endFrame - start
        guard count > Int(SynthComposer.sampleRate * 0.05),
              let out = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(count)),
              let src = buf.floatChannelData?[0], let dst = out.floatChannelData?[0] else { return nil }
        dst.update(from: src.advanced(by: start), count: count)
        out.frameLength = AVAudioFrameCount(count)
        return out
    }

    private func buffer(for song: Song) async -> AVAudioPCMBuffer? {
        if let b = cache[song.id] { return b }
        let samples = await Task.detached(priority: .userInitiated) { SynthComposer.render(song) }.value
        if let b = cache[song.id] { return b }
        guard let buf = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(samples.count)),
              let dst = buf.floatChannelData?[0] else { return nil }
        samples.withUnsafeBufferPointer { src in dst.update(from: src.baseAddress!, count: samples.count) }
        buf.frameLength = AVAudioFrameCount(samples.count)
        cache[song.id] = buf
        cacheOrder.append(song.id)
        // 每首约 6MB，最多留 6 首（正在播的不删）
        while cacheOrder.count > 6, let i = cacheOrder.firstIndex(where: { $0 != current?.id }) {
            cache[cacheOrder.remove(at: i)] = nil
        }
        return buf
    }

    // MARK: 锁屏信息 & 线控

    private func setupRemoteCommands() {
        let cc = MPRemoteCommandCenter.shared()
        // 用 Apple Music 播放时，锁屏和耳机按钮由系统播放器自己处理
        let act: (RemoteAction) -> Void = { [weak self] a in
            MainActor.assumeIsolated { if let self, !self.amActive { self.onRemote?(a) } }
        }
        let seekTo: (Double) -> Void = { [weak self] t in
            MainActor.assumeIsolated { if let self, !self.amActive { self.seek(t) } }
        }
        cc.playCommand.addTarget(handler: Self.remote(.play, act))
        cc.pauseCommand.addTarget(handler: Self.remote(.pause, act))
        cc.togglePlayPauseCommand.addTarget(handler: Self.remote(.toggle, act))
        cc.nextTrackCommand.addTarget(handler: Self.remote(.next, act))
        cc.previousTrackCommand.addTarget(handler: Self.remote(.previous, act))
        cc.changePlaybackPositionCommand.addTarget(handler: Self.remoteSeek(seekTo))
    }

    // 下面几个工厂函数不属于主线程：系统可能在其他线程回调，统一切回主线程再处理
    nonisolated private static func remote(_ a: RemoteAction, _ act: @escaping (RemoteAction) -> Void) -> (MPRemoteCommandEvent) -> MPRemoteCommandHandlerStatus {
        let box = MainCallback(act)
        return { _ in DispatchQueue.main.async { box.call(a) }; return .success }
    }

    nonisolated private static func remoteSeek(_ seekTo: @escaping (Double) -> Void) -> (MPRemoteCommandEvent) -> MPRemoteCommandHandlerStatus {
        let box = MainCallback(seekTo)
        return { e in
            guard let e = e as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            let t = e.positionTime
            DispatchQueue.main.async { box.call(t) }
            return .success
        }
    }

    nonisolated private static func onMain(_ gen: Int, _ fire: @escaping (Int) -> Void) -> @Sendable (AVAudioPlayerNodeCompletionCallbackType) -> Void {
        let box = MainCallback(fire)
        return { _ in DispatchQueue.main.async { box.call(gen) } }
    }

    private static let artwork: MPMediaItemArtwork? = makeArtwork()

    private func updateNowPlaying() {
        let center = MPNowPlayingInfoCenter.default()
        if amActive { return }
        guard let s = current else { center.nowPlayingInfo = nil; return }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: s.title,
            MPMediaItemPropertyArtist: stream != nil ? s.artist + " · 试听" : s.artist + " · 示意旋律",
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: position,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0,
        ]
        if let art = Self.artwork { info[MPMediaItemPropertyArtwork] = art }
        center.nowPlayingInfo = info
    }
}

/// 锁屏封面：系统会在后台线程取图，所以放在主线程隔离之外
private func makeArtwork() -> MPMediaItemArtwork? {
    guard let img = UIImage(named: "mascot-happy") else { return nil }
    return MPMediaItemArtwork(boundsSize: img.size) { _ in img }
}

/// 把回调包起来跨线程传递；只在主线程上调用（上面都用 DispatchQueue.main.async 切回主线程）
private final class MainCallback<T>: @unchecked Sendable {
    private let f: (T) -> Void
    init(_ f: @escaping (T) -> Void) { self.f = f }
    func call(_ v: T) { f(v) }
}
