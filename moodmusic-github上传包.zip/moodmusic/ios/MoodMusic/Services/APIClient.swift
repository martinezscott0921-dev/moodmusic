import Foundation

/// 后端接口（接口文档 v1.0）。任何失败都返回 nil，由调用方退回本地规则。
struct APIClient {
    enum Mode: String { case llm, rules, local }

    struct UnderstandResult {
        let need: Need
        let mode: Mode
    }

    enum UnderstandOutcome {
        case ok(UnderstandResult)
        case rateLimited(seconds: Int)
        case failed
    }

    private let session: URLSession = {
        let cfg = URLSessionConfiguration.default
        cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
        return URLSession(configuration: cfg)
    }()

    private func url(_ path: String) -> URL {
        path.split(separator: "/").reduce(AppConfig.apiBase.appendingPathComponent("api")) { $0.appendingPathComponent(String($1)) }
    }

    private func send(_ path: String, body: Encodable? = nil, timeout: TimeInterval) async -> (Data, HTTPURLResponse)? {
        var req = URLRequest(url: url(path), timeoutInterval: timeout)
        if let body {
            req.httpMethod = "POST"
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            guard let data = try? JSONEncoder().encode(AnyEncodable(body)) else { return nil }
            req.httpBody = data
        }
        guard let (data, resp) = try? await session.data(for: req), let http = resp as? HTTPURLResponse else { return nil }
        return (data, http)
    }

    /// GET /api/health → llm 是否配置、模型 B（tagger）能不能用；连不上返回 nil
    /// catalog：服务器有没有公共曲库（旧版服务器没有这个字段）
    func health() async -> (llm: String, tagger: Bool, catalog: Bool)? {
        struct H: Decodable { let status: String; let llm: String?; let tagger: String?; let catalog: Int? }
        guard let (d, r) = await send("health", timeout: AppConfig.healthTimeout), r.statusCode == 200,
              let h = try? JSONDecoder().decode(H.self, from: d), h.status == "ok" else { return nil }
        return (h.llm ?? "missing", h.tagger == "configured", h.catalog != nil)
    }

    /// POST /api/work-title：请服务器上的 AI 把影视作品的中文名翻成官方英文名。服务器没有这个接口时返回 nil
    func workTitle(_ title: String) async -> String? {
        struct Body: Encodable { let title: String }
        struct R: Decodable { let en: String? }
        guard let (d, r) = await send("work-title", body: Body(title: title), timeout: 10), r.statusCode == 200,
              let x = try? JSONDecoder().decode(R.self, from: d), let en = x.en?.trimmingCharacters(in: .whitespacesAndNewlines),
              !en.isEmpty, en.count <= 100 else { return nil }
        return en
    }

    struct TagSong: Encodable {
        let id: String
        let title: String
        let artist: String
        var album: String? = nil
        var genre_hint: String? = nil
        // 公共曲库用：别人的 App 下载后能直接播放试听、显示封面
        var preview_url: String? = nil
        var artwork: String? = nil
        var duration_ms: Int? = nil
        var storefront: String? = nil
    }

    /// POST /api/tag：交给模型 B 打标签（一次最多 20 首）。服务器已经打过的直接返回保存的结果。
    /// 返回成功打好的标签；连不上、限流或出错返回 nil
    func tag(_ songs: [TagSong]) async -> [String: SongTags]? { await tagWithStatus(songs).tags }

    /// 同上，另外返回失败原因（排查用）
    func tagWithStatus(_ songs: [TagSong]) async -> (tags: [String: SongTags]?, why: String) {
        struct Body: Encodable { let songs: [TagSong] }
        struct R: Decodable { let tags: [String: Lenient<SongTags>]? }
        guard !songs.isEmpty else { return (nil, "没有歌") }
        guard let (d, r) = await send("tag", body: Body(songs: Array(songs.prefix(20))), timeout: 25) else { return (nil, "连不上服务器") }
        guard r.statusCode == 200 else { return (nil, "服务器返回 \(r.statusCode)") }
        guard let x = try? JSONDecoder().decode(R.self, from: d) else { return (nil, "返回内容看不懂") }
        return ((x.tags ?? [:]).compactMapValues(\.value), "")
    }

    /// GET /api/tags?ids=…：只读服务器上已经打好的标签（一次最多 50 首），不调用大模型、不限流等待
    func cachedTags(_ ids: [String]) async -> [String: SongTags]? {
        struct R: Decodable { let tags: [String: Lenient<SongTags>]? }
        guard !ids.isEmpty, var c = URLComponents(url: url("tags"), resolvingAgainstBaseURL: false) else { return nil }
        c.queryItems = [URLQueryItem(name: "ids", value: ids.prefix(50).joined(separator: ","))]
        guard let u = c.url, let (d, resp) = try? await session.data(for: URLRequest(url: u, timeoutInterval: 10)),
              (resp as? HTTPURLResponse)?.statusCode == 200,
              let x = try? JSONDecoder().decode(R.self, from: d) else { return nil }
        return (x.tags ?? [:]).compactMapValues(\.value)
    }

    struct SharedSong: Decodable {
        let id: String
        let title: String
        let artist: String
        let album: String?
        let preview_url: String?
        let artwork: String?
        let duration_ms: Int?
        let storefront: String?
        let tags: Lenient<SongTags>?
    }

    /// GET /api/catalog?since=…：公共曲库里 since 之后新增的歌（带标签）。连不上或服务器没有这个接口返回 nil
    func catalog(since: Double) async -> (songs: [SharedSong], next: Double, more: Bool)? {
        struct Entry: Decodable { let value: SharedSong?; init(from d: Decoder) throws { value = try? SharedSong(from: d) } }
        struct R: Decodable { let songs: [Entry]?; let next_since: Double?; let has_more: Bool? }
        guard var c = URLComponents(url: url("catalog"), resolvingAgainstBaseURL: false) else { return nil }
        c.queryItems = [URLQueryItem(name: "since", value: String(Int(since)))]
        guard let u = c.url, let (d, resp) = try? await session.data(for: URLRequest(url: u, timeoutInterval: 15)),
              (resp as? HTTPURLResponse)?.statusCode == 200,
              let x = try? JSONDecoder().decode(R.self, from: d) else { return nil }
        return ((x.songs ?? []).compactMap(\.value), x.next_since ?? since, x.has_more ?? false)
    }

    /// GET /api/songs
    func songs() async -> [Song]? {
        guard let (d, r) = await send("songs", timeout: AppConfig.defaultTimeout), r.statusCode == 200 else { return nil }
        // 逐条解码，坏数据跳过
        guard let arr = try? JSONSerialization.jsonObject(with: d) as? [Any] else { return nil }
        return arr.compactMap { item in
            guard let data = try? JSONSerialization.data(withJSONObject: item) else { return nil }
            return try? JSONDecoder().decode(Song.self, from: data)
        }
    }

    /// GET /api/sources/{id} → {"provider":"synth"} 或 {"provider":"file","url":"/audio/r001.mp3"}
    func source(_ id: String) async -> SongSource? {
        guard let (d, r) = await send("sources/\(id)", timeout: AppConfig.defaultTimeout), r.statusCode == 200,
              let s = try? JSONDecoder().decode(SongSource.self, from: d) else { return nil }
        return s
    }

    /// 把 /audio/xxx.mp3 这样的相对地址补全成完整网址
    static func absolute(_ url: String) -> URL? {
        if url.hasPrefix("http://") || url.hasPrefix("https://") { return URL(string: url) }
        return URL(string: url, relativeTo: AppConfig.apiBase)?.absoluteURL
    }

    /// POST /api/understand
    func understand(text: String, chip: SceneChip?, time: String) async -> UnderstandOutcome {
        struct ChipBody: Encodable {
            let id: String, label: String, current: String?
            func encode(to e: Encoder) throws {
                var c = e.container(keyedBy: K.self)
                try c.encode(id, forKey: .id); try c.encode(label, forKey: .label); try c.encode(current, forKey: .current)
            }
            enum K: String, CodingKey { case id, label, current }
        }
        struct Body: Encodable {
            let text: String, chip: ChipBody?, time: String
            func encode(to e: Encoder) throws {
                var c = e.container(keyedBy: K.self)
                try c.encode(text, forKey: .text); try c.encode(chip, forKey: .chip); try c.encode(time, forKey: .time)
            }
            enum K: String, CodingKey { case text, chip, time }
        }
        let body = Body(text: text, chip: chip.map { ChipBody(id: $0.id, label: $0.label, current: $0.current) }, time: time)
        guard let (d, r) = await send("understand", body: body, timeout: AppConfig.understandTimeout) else { return .failed }
        if r.statusCode == 429 {
            struct RL: Decodable { let retry_after: Int? }
            let sec = (try? JSONDecoder().decode(RL.self, from: d))?.retry_after
                ?? Int(r.value(forHTTPHeaderField: "Retry-After") ?? "") ?? 60
            return .rateLimited(seconds: sec)
        }
        guard r.statusCode == 200, var need = try? JSONDecoder().decode(Need.self, from: d) else { return .failed }
        if need.text.isEmpty { need.text = text }
        if need.chip == nil { need.chip = chip?.label }
        if need.time == nil { need.time = time }
        let mode: Mode = r.value(forHTTPHeaderField: "X-MoodMusic-Mode") == "llm" ? .llm : .rules
        return .ok(UnderstandResult(need: need, mode: mode))
    }
}

/// 让 any Encodable 能交给 JSONEncoder
private struct AnyEncodable: Encodable {
    let value: Encodable
    init(_ v: Encodable) { value = v }
    func encode(to encoder: Encoder) throws { try value.encode(to: encoder) }
}
