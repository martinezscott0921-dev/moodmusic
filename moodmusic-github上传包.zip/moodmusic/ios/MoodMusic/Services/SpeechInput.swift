import AVFoundation
import Speech

/// 语音输入：说完自动停（约 1.6 秒没有新内容），也可以再点一次手动停。
/// 支持的设备优先用"设备端识别"，录音不出手机。
@MainActor
final class SpeechInput {
    /// 识别到的文字（实时更新）
    var onText: ((String) -> Void)?
    /// 结束；带提示文字表示出错
    var onEnd: ((String?) -> Void)?
    /// 音频会话被改动过（通知播放器重新设置）
    var onSessionChanged: (() -> Void)?

    private(set) var isRunning = false
    private let engine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var silenceTimer: Timer?
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN"))

    func start() async {
        guard !isRunning else { return }
        let speechOK = await withCheckedContinuation { (c: CheckedContinuation<Bool, Never>) in
            SFSpeechRecognizer.requestAuthorization { c.resume(returning: $0 == .authorized) }
        }
        guard speechOK else { onEnd?("没有语音识别权限，可以在“设置”里打开，或直接打字"); return }
        let micOK = await AVAudioApplication.requestRecordPermission()
        guard micOK else { onEnd?("没有麦克风权限，已切换为文字输入"); return }
        guard let recognizer, recognizer.isAvailable else { onEnd?("语音识别暂时不可用，请直接打字"); return }

        // 音频会话设置放到后台线程，避免主线程卡顿
        let sessionOK = await Task.detached(priority: .userInitiated) { () -> Bool in
            let session = AVAudioSession.sharedInstance()
            do {
                try session.setCategory(.playAndRecord, mode: .measurement, options: [.duckOthers, .defaultToSpeaker])
                try session.setActive(true, options: .notifyOthersOnDeactivation)
                return true
            } catch { return false }
        }.value
        guard sessionOK else { onEnd?("语音识别启动失败，请直接打字"); return }

        let req = SFSpeechAudioBufferRecognitionRequest()
        req.shouldReportPartialResults = true
        if recognizer.supportsOnDeviceRecognition { req.requiresOnDeviceRecognition = true }
        request = req

        let input = engine.inputNode
        let fmt = input.outputFormat(forBus: 0)
        guard fmt.sampleRate > 0 else { finish("没有找到可用的麦克风，请直接打字"); return }
        input.installTap(onBus: 0, bufferSize: 1024, format: fmt, block: Self.tap(req))
        engine.prepare()
        do { try engine.start() } catch { finish("语音识别启动失败，请直接打字"); return }

        isRunning = true
        let deliver: (String?, Bool, Bool) -> Void = { [weak self] text, final, failed in
            MainActor.assumeIsolated { self?.handle(text: text, final: final, failed: failed) }
        }
        task = recognizer.recognitionTask(with: req, resultHandler: Self.resultHandler(deliver))
        armSilenceTimer(seconds: 6)   // 一直不说话也会自动停
    }

    func stop() { finish(nil) }

    private var gotText = false

    private func handle(text: String?, final: Bool, failed: Bool) {
        guard isRunning else { return }
        if let text, !text.isEmpty {
            gotText = true
            onText?(text)
            armSilenceTimer(seconds: 1.6)
        }
        if final { finish(nil) }
        else if failed { finish(gotText ? nil : "没有听到声音，可以再试一次或直接打字") }
    }

    private func armSilenceTimer(seconds: Double) {
        silenceTimer?.invalidate()
        silenceTimer = Timer.scheduledTimer(withTimeInterval: seconds, repeats: false) { [weak self] _ in
            DispatchQueue.main.async { MainActor.assumeIsolated { self?.finish(nil) } }
        }
    }

    private func finish(_ message: String?) {
        silenceTimer?.invalidate()
        silenceTimer = nil
        if engine.isRunning { engine.stop() }
        engine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        task?.finish()
        task = nil
        request = nil
        let wasRunning = isRunning
        isRunning = false
        gotText = false
        // 还原成播放模式
        DispatchQueue.global(qos: .userInitiated).async {
            try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        }
        onSessionChanged?()
        if wasRunning || message != nil { onEnd?(message) }
    }

    // 录音回调在音频线程，识别回调在后台线程：放在主线程隔离之外，再切回主线程
    nonisolated private static func tap(_ req: SFSpeechAudioBufferRecognitionRequest) -> AVAudioNodeTapBlock {
        return { buffer, _ in req.append(buffer) }
    }

    nonisolated private static func resultHandler(_ deliver: @escaping (String?, Bool, Bool) -> Void) -> (SFSpeechRecognitionResult?, Error?) -> Void {
        return { result, error in
            let text = result?.bestTranscription.formattedString
            let final = result?.isFinal ?? false
            let failed = error != nil
            DispatchQueue.main.async { deliver(text, final, failed) }
        }
    }
}
