import Foundation
import MediaPlayer
import Observation
import StoreKit

/// 在 Apple Music 里查到的曲目
struct AMTrack: Codable, Hashable, Sendable {
    var storeId: String
    var name: String
    var artist: String
    var previewUrl: String?
    var artwork: String?
    var durationMs: Int?

    var preview: URL? { previewUrl.flatMap(URL.init(string:)) }
    var artworkURL: URL? { artwork.flatMap(URL.init(string:)) }
    var seconds: Double? { durationMs.map { Double($0) / 1000 } }
}

/// Apple Music 适配（试听版）：
/// - 权限和订阅状态用系统的媒体资料库授权 + StoreKit 查询，不需要付费开发者账号
/// - 歌曲 ID 用公开的 iTunes 搜索接口按"歌名 + 歌手"在手机上实时查，查到后存在本机
/// - 有订阅：用系统音乐播放器放完整歌曲；没订阅：放 30 秒试听片段
@MainActor
@Observable
final class AppleMusic {
    enum Access: Equatable { case unknown, notAuthorized, noSubscription, subscriber }

    private(set) var access: Access = .unknown
    /// 歌曲 ID → 查到的曲目（封面也从这里取）
    private(set) var tracks: [String: AMTrack] = [:]
    private var misses: Set<String> = []
    private var pending: [String: Task<Outcome, Never>] = [:]
    private var queueTail: Task<Void, Never>?
    /// 最近一次查歌的情况（显示在“我的”页，方便排查）
    private(set) var lastLookup = "还没有查过歌"
    private var storefront = "cn"
    private static let cacheKey = "moodmusic.am.tracks.v1"

    init() {
        if let d = UserDefaults.standard.data(forKey: Self.cacheKey),
           let t = try? JSONDecoder().decode([String: AMTrack].self, from: d) { tracks = t }
        // 已经授权过的话，静默刷新一次订阅状态（不会弹窗）
        if MPMediaLibrary.authorizationStatus() == .authorized { Task { await refreshAccess() } }
    }

    var statusText: String {
        switch access {
        case .unknown: return "还没连接 Apple Music。第一次播放时会请求权限。"
        case .notAuthorized: return "没有 Apple Music 权限，现在只能放 30 秒试听。可以在“设置 › MoodMusic AI”里打开“媒体与 Apple Music”。"
        case .noSubscription: return "这个 Apple ID 没有 Apple Music 订阅，现在放的是 30 秒试听片段。"
        case .subscriber: return "已连接 Apple Music，推荐的歌会完整播放。"
        }
    }

    /// 请求权限（第一次会弹系统窗口）并查询订阅状态
    func refreshAccess() async {
        var status = MPMediaLibrary.authorizationStatus()
        if status == .notDetermined {
            status = await withCheckedContinuation { c in MPMediaLibrary.requestAuthorization(Self.statusCallback(c)) }
        }
        guard status == .authorized else { access = .notAuthorized; return }
        let controller = SKCloudServiceController()
        let caps = await withCheckedContinuation { c in controller.requestCapabilities(completionHandler: Self.capsCallback(c)) }
        access = caps.contains(.musicCatalogPlayback) ? .subscriber : .noSubscription
        if let code = await withCheckedContinuation({ c in controller.requestStorefrontCountryCode(completionHandler: Self.codeCallback(c)) }) {
            storefront = code.lowercased()
        }
    }

    enum Outcome: Sendable { case found(AMTrack), notFound, failed(String) }

    /// 查歌：先看本机缓存，没有再联网查；一次只查一首（查太快苹果会拒绝）
    func track(for song: Song) async -> AMTrack? {
        if let t = tracks[song.id] { return t }
        if misses.contains(song.id) { return nil }
        let outcome: Outcome
        if let p = pending[song.id] {
            outcome = await p.value
        } else {
            let country = storefront, title = song.title, artist = song.artist, prev = queueTail
            let task = Task { () -> Outcome in
                await prev?.value
                return await Self.lookup(title: title, artist: artist, country: country)
            }
            pending[song.id] = task
            queueTail = Task { _ = await task.value }
            outcome = await task.value
            pending[song.id] = nil
        }
        switch outcome {
        case .found(let t):
            tracks[song.id] = t
            if let d = try? JSONEncoder().encode(tracks) { UserDefaults.standard.set(d, forKey: Self.cacheKey) }
            lastLookup = "《\(song.title)》：找到了（\(t.artist)）"
            return t
        case .notFound:
            misses.insert(song.id)   // 确实没有：本次打开 App 不再重复查
            lastLookup = "《\(song.title)》：Apple Music（\(storefront)）里没搜到"
            return nil
        case .failed(let why):
            lastLookup = "《\(song.title)》：查询失败（\(why)）"   // 网络问题：下次还会再查
            return nil
        }
    }

    /// 提前查好一批（结果页能显示真实封面，点播放时不用等）
    func prefetch(_ songs: [Song]) {
        for s in songs where tracks[s.id] == nil { Task { _ = await track(for: s) } }
    }

    /// 把搜索找到的歌登记进来，播放器就能按歌曲 ID 找到它
    func register(_ songId: String, _ t: AMTrack) { tracks[songId] = t }

    // MARK: 找指定歌曲（2.0：用户说"我想听周杰伦的晴天"）

    struct Hit: Equatable, Identifiable {
        let trackId: Int
        let trackName: String
        let artistName: String
        let collectionName: String?
        let trackViewUrl: String?
        let previewUrl: String?
        let artwork: String?
        let durationMs: Int?
        let storefront: String
        var id: Int { trackId }

        var libItem: LibItem {
            LibItem(kind: "apple", id: String(trackId), title: trackName, artist: artistName, collectionName: collectionName,
                    storefront: storefront, trackViewUrl: trackViewUrl, previewUrl: previewUrl, artwork: artwork, durationMs: durationMs)
        }
    }

    struct SearchResult: Equatable {
        /// found / empty / no_match / ambiguous / upstream_error
        var reason: String
        var hit: Hit?
        var candidates: [Hit] = []
        var found: Bool { hit != nil && reason == "found" }
        /// 页面上可以操作的全部歌曲（命中的在最前）
        var all: [Hit] { (hit.map { [$0] } ?? []) + candidates }
    }

    /// 和网页 2.0 的 /api/search 同样的判定：歌名对上、歌手也对上才算找到；同名不同歌手时不替用户决定
    func searchSong(_ song: String, artist: String?) async -> SearchResult {
        let country = storefront
        var r = await Self.findSong(song, artist: artist, country: country)
        if r.reason == "empty" && country != "us" {
            let us = await Self.findSong(song, artist: artist, country: "us")
            if us.reason != "upstream_error" { r = us }
        }
        return r
    }

    /// 调 iTunes 搜索，返回歌曲列表；连不上时返回 nil
    nonisolated private static func fetchHits(_ term: String, country: String, limit: Int = 25, attribute: String? = nil) async -> [Hit]? {
        var c = URLComponents(string: "https://itunes.apple.com/search")!
        c.queryItems = [
            URLQueryItem(name: "term", value: term.trimmingCharacters(in: .whitespaces)),
            URLQueryItem(name: "country", value: country),
            URLQueryItem(name: "media", value: "music"),
            URLQueryItem(name: "entity", value: "song"),
            URLQueryItem(name: "limit", value: String(limit)),
        ]
        if let attribute { c.queryItems?.append(URLQueryItem(name: "attribute", value: attribute)) }
        guard let url = c.url else { return nil }
        let got: (Data, URLResponse)
        do { got = try await URLSession.shared.data(for: URLRequest(url: url, timeoutInterval: 10)) }
        catch { return nil }
        guard (got.1 as? HTTPURLResponse)?.statusCode == 200,
              let resp = try? JSONDecoder().decode(SearchResponse.self, from: got.0) else { return nil }
        return hits(resp, country: country)
    }

    nonisolated private static func hits(_ resp: SearchResponse, country: String) -> [Hit] {
        resp.results.compactMap { i in
            guard let id = i.trackId, let n = i.trackName, let a = i.artistName, !n.isEmpty, !a.isEmpty else { return nil }
            let link = i.trackViewUrl.flatMap { $0.hasPrefix("https://") && ($0.contains(".apple.com/") || $0.contains("//apple.com/")) ? $0 : nil }
            return Hit(trackId: id, trackName: n, artistName: a, collectionName: i.collectionName, trackViewUrl: link,
                       previewUrl: i.previewUrl, artwork: i.artworkUrl100?.replacingOccurrences(of: "100x100bb", with: "600x600bb"),
                       durationMs: i.trackTimeMillis, storefront: country)
        }
    }

    // MARK: 热门榜（推荐曲库每天自动补充）

    private struct ChartFeed: Decodable {
        struct Feed: Decodable { let results: [Entry] }
        struct Entry: Decodable { let id: String }
        let feed: Feed
    }

    /// Apple Music 某个地区的热门歌曲榜：先从榜单拿到歌曲编号，再一次性查出歌曲信息（含试听地址）
    nonisolated static func fetchChart(country: String, limit: Int = 100) async -> [Hit] {
        guard let feedURL = URL(string: "https://rss.applemarketingtools.com/api/v2/\(country)/music/most-played/\(limit)/songs.json"),
              let got = try? await URLSession.shared.data(for: URLRequest(url: feedURL, timeoutInterval: 10)),
              (got.1 as? HTTPURLResponse)?.statusCode == 200,
              let feed = try? JSONDecoder().decode(ChartFeed.self, from: got.0) else { return [] }
        let ids = feed.feed.results.map(\.id).filter { !$0.isEmpty && $0.allSatisfy(\.isNumber) }
        guard !ids.isEmpty else { return [] }
        var c = URLComponents(string: "https://itunes.apple.com/lookup")!
        c.queryItems = [URLQueryItem(name: "id", value: ids.joined(separator: ",")), URLQueryItem(name: "country", value: country)]
        guard let url = c.url,
              let res = try? await URLSession.shared.data(for: URLRequest(url: url, timeoutInterval: 15)),
              (res.1 as? HTTPURLResponse)?.statusCode == 200,
              let resp = try? JSONDecoder().decode(SearchResponse.self, from: res.0) else { return [] }
        return hits(resp, country: country)
    }

    /// 当前使用的 Apple Music 地区
    var country: String { storefront }

    nonisolated private static func findSong(_ song: String, artist: String?, country: String) async -> SearchResult {
        guard let hits = await fetchHits([song, artist ?? ""].joined(separator: " "), country: country) else { return SearchResult(reason: "upstream_error") }
        if hits.isEmpty { return SearchResult(reason: "empty") }
        let t = norm(song)
        func titleOK(_ h: Hit) -> Bool { let n = norm(h.trackName); return n == t || n.hasPrefix(t) || (!n.isEmpty && t.hasPrefix(n)) }
        func artistOK(_ h: Hit, _ a: String) -> Bool { let n = norm(h.artistName), x = norm(a); return n.contains(x) || (!n.isEmpty && x.contains(n)) }
        // 去掉同一首歌的重复版本（同歌名同歌手只留第一个）
        func distinct(_ list: [Hit]) -> [Hit] {
            var seen = Set<String>()
            return list.filter { seen.insert(norm($0.trackName) + "|" + norm($0.artistName)).inserted }
        }
        let titled = hits.filter(titleOK)
        if let a = artist, !a.isEmpty {
            if let best = titled.first(where: { artistOK($0, a) }) {
                return SearchResult(reason: "found", hit: best, candidates: Array(distinct(titled.filter { $0.trackId != best.trackId && !artistOK($0, a) }).prefix(4)))
            }
            return SearchResult(reason: "no_match", candidates: Array(distinct(titled.isEmpty ? hits : titled).prefix(5)))
        }
        if titled.isEmpty { return SearchResult(reason: "no_match", candidates: Array(distinct(hits).prefix(5))) }
        let artists = Set(titled.map { norm($0.artistName) })
        if artists.count == 1 { return SearchResult(reason: "found", hit: titled[0]) }
        return SearchResult(reason: "ambiguous", candidates: Array(distinct(titled).prefix(5)))
    }

    // MARK: 找某位歌手的歌（“我想听王菲的歌”）
    // 内置曲库只有 50 首，没有的歌手就去 Apple Music 搜，只留歌手名对得上的歌。

    func searchArtist(_ name: String) async -> SearchResult {
        var r = await Self.findArtist(name, country: storefront)
        if r.candidates.isEmpty && r.reason != "upstream_error" && storefront != "us" {
            let us = await Self.findArtist(name, country: "us")
            if !us.candidates.isEmpty { r = us }
        }
        return r
    }

    /// 先按“歌手名”字段搜（attribute=artistTerm），再普通搜。
    /// Apple Music 里中文歌手常用英文名登记（王菲 = Faye Wong），所以名字对不上时，
    /// 如果搜出来的歌大多数是同一位歌手，就认定是这位歌手。
    nonisolated private static func findArtist(_ name: String, country: String) async -> SearchResult {
        let x = norm(name)
        guard !x.isEmpty else { return SearchResult(reason: "artist_empty") }
        var anyOK = false
        for attr in ["artistTerm", nil] as [String?] {
            guard let hits = await fetchHits(name, country: country, limit: 50, attribute: attr) else { continue }
            anyOK = true
            guard !hits.isEmpty else { continue }
            func nameOK(_ h: Hit) -> Bool { let n = norm(h.artistName); return n == x || n.contains(x) || (!n.isEmpty && x.contains(n)) }
            var mine = hits.filter(nameOK)
            if mine.isEmpty {
                // 名字对不上：看有没有一位歌手占了一半以上
                let counts = Dictionary(grouping: hits, by: { norm($0.artistName) }).mapValues(\.count)
                if let top = counts.max(by: { $0.value < $1.value }), top.value * 2 >= hits.count, top.value >= 3 {
                    mine = hits.filter { norm($0.artistName) == top.key }
                }
            }
            var seen = Set<String>()
            mine = mine.filter { seen.insert(norm($0.trackName)).inserted }
            if !mine.isEmpty { return SearchResult(reason: "artist", candidates: Array(mine.prefix(12))) }
        }
        return SearchResult(reason: anyOK ? "artist_empty" : "upstream_error")
    }

    // MARK: 找影视作品的歌（“我想听怪奇物语的歌”）
    // 用“作品名 + 原声 / 主题曲”去搜，只留专辑名或歌名里带作品名、或明显是原声专辑的歌。
    // 我们没法确认哪一首就是主题曲，所以只列候选（reason = "soundtrack"），让用户自己选。

    /// titles：作品名的几种写法（中文名、英文名），按顺序都试
    func searchSoundtrack(titles: [String], role: String?) async -> SearchResult {
        var r = await Self.findSoundtrack(titles, role: role, country: storefront)
        if r.candidates.isEmpty && r.reason != "upstream_error" && storefront != "us" {
            let us = await Self.findSoundtrack(titles, role: role, country: "us")
            if !us.candidates.isEmpty { r = us }
        }
        return r
    }

    nonisolated private static let soundtrackWords = ["原声", "主题曲", "片头曲", "片尾曲", "插曲", "配乐", "电视剧", "电影", "影视", "サウンドトラック",
                                          "soundtrack", "ost", "original score", "music from", "theme", "netflix", "series", "motion picture"]

    /// 只留专辑名或歌名里带作品名的歌；原声专辑里的排在前面
    nonisolated private static func findSoundtrack(_ titles: [String], role: String?, country: String) async -> SearchResult {
        var seenTitle = Set<String>()
        let names = titles.filter { !norm($0).isEmpty && seenTitle.insert(norm($0)).inserted }
        guard !names.isEmpty else { return SearchResult(reason: "soundtrack_empty") }
        var strong: [Hit] = [], weak: [Hit] = []
        var seen = Set<String>()
        var anyOK = false
        for work in names {
            let w = norm(work)
            let cjk = WorkTitles.hasCJK(work)
            var terms = cjk ? ["\(work) 原声", "\(work) 主题曲", work] : ["\(work) soundtrack", "\(work) theme", work]
            if let role, !role.isEmpty, cjk { terms.insert("\(work) \(role)", at: 0) }
            for t in terms {
                guard let hits = await fetchHits(t, country: country, limit: 25) else { continue }
                anyOK = true
                for h in hits {
                    let album = (h.collectionName ?? "").lowercased()
                    let inAlbum = norm(h.collectionName ?? "").contains(w)
                    let inTrack = norm(h.trackName).contains(w)
                    guard inAlbum || inTrack else { continue }
                    guard seen.insert(norm(h.trackName) + "|" + norm(h.artistName)).inserted else { continue }
                    let ost = soundtrackWords.contains { album.contains($0) || h.trackName.lowercased().contains($0) }
                    if inAlbum && ost { strong.append(h) } else { weak.append(h) }
                }
                if strong.count >= 8 { break }
            }
            if strong.count >= 8 { break }
        }
        if !anyOK { return SearchResult(reason: "upstream_error") }
        let picked = Array((strong + weak).prefix(8))
        return SearchResult(reason: picked.isEmpty ? "soundtrack_empty" : "soundtrack", candidates: picked)
    }

    func clearCache() {
        tracks = [:]
        misses = []
        UserDefaults.standard.removeObject(forKey: Self.cacheKey)
    }

    // MARK: iTunes 搜索接口（公开接口，不需要开发者令牌）

    private struct SearchResponse: Decodable { let results: [Item] }
    private struct Item: Decodable {
        let trackId: Int?
        let trackName: String?
        let artistName: String?
        let previewUrl: String?
        let artworkUrl100: String?
        let trackTimeMillis: Int?
        let collectionName: String?
        let trackViewUrl: String?
    }

    /// 依次尝试：本区"歌名+歌手" → 本区只搜歌名 → 美区"歌名+歌手"（美区查到的至少能放试听）
    nonisolated private static func lookup(title: String, artist: String, country: String) async -> Outcome {
        var firstError: String?
        let tries = [("\(title) \(artist)", country), (title, country)] + (country == "us" ? [] : [("\(title) \(artist)", "us")])
        for (term, cc) in tries {
            switch await search(term: term, title: title, artist: artist, country: cc) {
            case .found(let t): return .found(t)
            case .notFound: continue
            case .failed(let why):
                if firstError == nil { firstError = why }
            }
        }
        return firstError.map { .failed($0) } ?? .notFound
    }

    nonisolated private static func search(term: String, title: String, artist: String, country: String) async -> Outcome {
        var c = URLComponents(string: "https://itunes.apple.com/search")!
        c.queryItems = [
            URLQueryItem(name: "term", value: term),
            URLQueryItem(name: "country", value: country),
            URLQueryItem(name: "media", value: "music"),
            URLQueryItem(name: "entity", value: "song"),
            URLQueryItem(name: "limit", value: "15"),
        ]
        guard let url = c.url else { return .failed("地址错误") }
        var req = URLRequest(url: url, timeoutInterval: 10)
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let got: (Data, URLResponse)
        do { got = try await URLSession.shared.data(for: req) }
        catch { return .failed("网络：\((error as NSError).code) \(error.localizedDescription)") }
        let data = got.0
        let code = (got.1 as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200 else { return .failed("HTTP \(code)") }
        guard let r = try? JSONDecoder().decode(SearchResponse.self, from: data) else {
            return .failed("返回内容看不懂：" + String(decoding: data.prefix(60), as: UTF8.self))
        }
        let items = r.results.filter { $0.trackId != nil }
        let t = norm(title), a = norm(artist)
        func titleOK(_ i: Item) -> Bool { let n = norm(i.trackName ?? ""); return n.contains(t) || (!n.isEmpty && t.contains(n)) }
        func artistOK(_ i: Item) -> Bool { let n = norm(i.artistName ?? ""); return n.contains(a) || (!n.isEmpty && a.contains(n)) }
        // 歌名和歌手都对上最好；其次只对上歌名；都不对就当没找到，免得放错歌
        guard let best = items.first(where: { titleOK($0) && artistOK($0) }) ?? items.first(where: titleOK) else { return .notFound }
        return .found(AMTrack(storeId: String(best.trackId!), name: best.trackName ?? title, artist: best.artistName ?? artist,
                              previewUrl: best.previewUrl,
                              artwork: best.artworkUrl100?.replacingOccurrences(of: "100x100bb", with: "600x600bb"),
                              durationMs: best.trackTimeMillis))
    }

    /// 比较用：小写、去掉空格和标点
    nonisolated private static func norm(_ s: String) -> String {
        String(s.lowercased().unicodeScalars.filter { CharacterSet.alphanumerics.contains($0) }.map(Character.init))
    }

    // 系统回调可能在任意线程：放在主线程隔离之外
    nonisolated private static func statusCallback(_ c: CheckedContinuation<MPMediaLibraryAuthorizationStatus, Never>) -> @Sendable (MPMediaLibraryAuthorizationStatus) -> Void {
        return { c.resume(returning: $0) }
    }

    nonisolated private static func capsCallback(_ c: CheckedContinuation<SKCloudServiceCapability, Never>) -> @Sendable (SKCloudServiceCapability, Error?) -> Void {
        return { caps, _ in c.resume(returning: caps) }
    }

    nonisolated private static func codeCallback(_ c: CheckedContinuation<String?, Never>) -> @Sendable (String?, Error?) -> Void {
        return { code, _ in c.resume(returning: code) }
    }
}
